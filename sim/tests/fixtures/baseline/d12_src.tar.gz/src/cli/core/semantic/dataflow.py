# ==============================================================================
# dataflow.py - dataflow path analysis subcommand
# ==============================================================================

import sys
from pathlib import Path

import typer

from cli._common import _build_tracer, handle_compilation_error
from cli.core.semantic.trace_common import _load_tracer_from_snapshot  # [ADD 2026-06-11 Req-9]
from cli.core.semantic._bit_args import normalize_endpoint, parse_bits  # [iter_309 P15]
from sv_query.trace.core.compiler import CompilationError  # [ADD 2026-06-11 任务3]

from cli._paths import ensure_on_path, PROJECT_ROOT  # noqa: E402
ensure_on_path(PROJECT_ROOT)

from cli._evidence_helpers import (
    evidence_summary_indented,
    evidence_to_dict,
)
from cli._evidence_helpers import (
    format_dataflow_human as _format_dataflow_human,
)

# [Stage 5] evidence helper (可选 --evidence flag)
from cli._evidence_helpers import (  # noqa: E402
    make_resolver as _make_evidence_resolver,
)
from sv_query.trace.core.graph.dataflow import DataFlowGraph
from cli._output import emit_json


def output_text(data: dict, human: bool = False, tree: bool = False) -> None:
    """纯文本输出 - 与 trace.py 保持一致格式

    Args:
        data: 命令返回的 dict
        human: True 时用人类友好箭头格式 (--human flag)
    """
    command = data.get("command", "")
    result = data.get("result", {})

    if command == "dataflow":
        if human:
            print(_format_dataflow_human(
                result.get("from_signal", ""),
                result.get("to_signal", ""),
                result.get("paths", []),
                tree=tree,
            ))
            return
        from_sig = result.get("from_signal", "")
        to_sig = result.get("to_signal", "")
        is_reachable = result.get("is_reachable", False)
        paths_count = result.get("paths_count", 0)
        clock_domain = result.get("clock_domain") or "(none)"
        timing_risk = result.get("timing_risk", "safe")
        intermediate = result.get("intermediate_signals", [])

        print(f"DataFlow: {from_sig} → {to_sig}")
        if is_reachable is None:
            print("  Reachable: unknown (search budget exhausted)"
                  f" [{result.get('truncation_reason', '')}]")
        else:
            print(f"  Reachable: {is_reachable}")
        if result.get("truncated"):
            print(f"  Truncated: {result.get('truncation_reason', '')}"
                  f" (expansions={result.get('expansions')})")
        print(f"  Paths: {paths_count}")
        print(f"  Clock Domain: {clock_domain}")
        print(f"  Timing Risk: {timing_risk} ({result.get('risk_model', 'unlabeled')})")

        if intermediate:
            print(f"  Intermediate Signals ({len(intermediate)}):")
            for sig in sorted(intermediate)[:10]:
                print(f"    - {sig}")
            if len(intermediate) > 10:
                print(f"    ... and {len(intermediate) - 10} more")

        paths = result.get("paths", [])
        if paths:
            print("\n  Path Details:")
            for path in paths[:5]:
                path_id = path.get("path_id", 0)
                distance = path.get("distance", 0)
                has_cond = path.get("has_conditional", False)
                cond_str = " [conditional]" if has_cond else ""
                print(f"\n    Path {path_id}: distance={distance}{cond_str}")

                segments = path.get("segments", [])
                for seg in segments:
                    from_s = seg.get("from_signal", "")
                    to_s = seg.get("to_signal", "")
                    driver = seg.get("driver") or "(none)"
                    condition = seg.get("condition")
                    timing = seg.get("timing") or "(none)"
                    assign_type = seg.get("assign_type", "continuous")

                    print(f"      {from_s} → {to_s}")
                    if driver and driver != "(none)":
                        print(f"        driver: {driver}")
                    if condition:
                        cond_short = condition[:60] + "..." if len(condition) > 60 else condition
                        print(f"        condition: {cond_short}")
                    print(f"        timing: {timing}")
                    print(f"        assign: {assign_type}")
                    # [Stage 5] 可选 evidence 1 行摘要 (贴在 assign 下方)
                    if data.get("params", {}).get("evidence"):
                        summary = evidence_summary_indented(seg.get("evidence"))
                        if summary:
                            print(summary)

                if len(segments) > 5:
                    print(f"      ... and {len(segments) - 5} more segments")

            if len(paths) > 5:
                print(f"\n    ... and {len(paths) - 5} more paths")


dataflow_app = typer.Typer(help="Analyze dataflow paths between signals")


def _fail_analyze(message: str, json_output: bool, pretty: bool, code: int = 1) -> None:
    data = {"ok": False, "command": "dataflow_analyze", "error": message,
            "errors": [message]}
    if json_output:
        emit_json(data, pretty)
    else:
        typer.echo(f"Error: {message}", err=True)
    raise typer.Exit(code=code)


@dataflow_app.command("analyze")
def analyze(
    from_signal: str = typer.Argument(..., help="Source signal (e.g., top.clk)"),
    to_signal: str = typer.Argument(..., help="Target signal (e.g., top.data_out)"),
    file: Path = typer.Option(None, "--file", "-f", help="SystemVerilog source file (单文件模式)"),
    filelist: str = typer.Option(None, "--filelist", help="Path to filelist (.f/.fl) for multi-file projects (项目模式)"),
    from_snapshot: str = typer.Option(None, "--from-snapshot",
                                      help="load graph/MIG from snapshot tag (skip parse)"),
    preprocess_macros: bool = typer.Option(True, "--preprocess/--no-preprocess", help="Preprocess macros (default): 跨文件 `MACRO 展开, 避免 TooFewArguments. Use --no-preprocess 退回 pyslang 内置处理 (供不跨文件 define 的小项目用)"),

    log_level: str = typer.Option("WARNING", "--log-level", help="Compiler log level (DEBUG/INFO/WARNING/ERROR)"),
    max_paths: int = typer.Option(100, "--max-paths", "-n", help="Maximum number of paths to return"),
    max_expansions: int = typer.Option(
        200_000, "--max-expansions",
        help="[P158.11.2b] 搜索 work budget (考察的出边数); 耗尽时返回 truncated, 无路径时为 unknown"),
    timeout_s: float = typer.Option(
        None, "--timeout",
        help="[P158.11.2b] wall-clock 秒数上限; 超时返回 truncated, 无路径时为 unknown"),
    bits: str = typer.Option(
        None, "--bits",
        help="[iter_309 P15] 位级端点: src_bit,dst_bit；位节点缺失时回落总线并标 coarse_fallback"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output JSON format"),
    pretty: bool = typer.Option(False, "--pretty", "-p", help="Pretty-print JSON"),
    evidence: bool = typer.Option(False, "--evidence", "-e", help="Include source evidence for each segment (optional)"),
    human: bool = typer.Option(False, "--human", "-H", help="Human-friendly arrow output (default off)"),
    tree: bool = typer.Option(False, "--tree", "-T", help="Tree-style vertical output (default off; auto for chains > 6)"),
) -> None:
    """Analyze dataflow path from source signal to target signal"""
    if from_snapshot and (file or filelist):
        _fail_analyze("--from-snapshot is mutually exclusive with --file/--filelist",
                      json_output, pretty)
        return
    if not from_snapshot and not file and not filelist:
        _fail_analyze("--file, --filelist, or --from-snapshot is required",
                      json_output, pretty)
        return
    if from_snapshot and evidence:
        _fail_analyze("--evidence is not supported with --from-snapshot",
                      json_output, pretty)
        return

    try:
        tracer = (_load_tracer_from_snapshot(from_snapshot) if from_snapshot
                  else _build_tracer(
                      file=file, filelist=filelist, log_level=log_level,
                      preprocess_macros=preprocess_macros,
                  ))
        _ = tracer.build_graph()
    except CompilationError as e:
        handle_compilation_error(e)
        return
    except ValueError as e:
        _fail_analyze(str(e), json_output, pretty)
        return

    try:
        spec = parse_bits(bits, names=("src", "dst"))
        if not spec.named and spec.positional and len(spec.positional) != 2:
            raise ValueError("--bits 需要两个值（src,dst；示例 --bits 1,5 或 7:4,3:0）")
        src_info = normalize_endpoint(tracer.get_graph(), from_signal, spec.get(0, "src"))
        dst_info = normalize_endpoint(tracer.get_graph(), to_signal, spec.get(1, "dst"))
    except ValueError as e:
        _fail_analyze(str(e), json_output, pretty, code=2)
    from_id, to_id = src_info["resolved"], dst_info["resolved"]

    dfg = DataFlowGraph(tracer._graph, tracer._module_graph)
    try:
        result = dfg.analyze(from_id, to_id, max_paths=max_paths,
                             max_expansions=max_expansions, timeout_s=timeout_s)
    except ValueError as e:
        # [ADD 2026-06-11 Req-11] 信号名不存在的友好错误 (Issue 20)
        # ValueError 已含 hint 和 available signals, 不暴露 traceback
        _fail_analyze(str(e), json_output, pretty)

    # [Stage 5] (可选) evidence 召回 - 每个 segment 的 to_signal 独立解析
    evidence_resolver = None
    if evidence:
        evidence_resolver = _make_evidence_resolver(tracer._graph, tracer._get_adapter())

    paths_data = []
    for path in result.paths:
        segments_data = []
        for seg in path.segments:
            seg_dict = {
                "from_signal": seg.from_signal,
                "to_signal": seg.to_signal,
                "driver": seg.driver,
                "condition": seg.condition,
                "timing": seg.timing,
                "assign_type": seg.assign_type,
                "distance": seg.distance,
            }
            if evidence_resolver is not None:
                seg_dict["evidence"] = evidence_to_dict(evidence_resolver.resolve(seg.to_signal))
            segments_data.append(seg_dict)
        paths_data.append(
            {
                "path_id": path.path_id,
                "segments": segments_data,
                "distance": path.distance,
                "has_conditional": path.has_conditional,
                # [ADD 2026-07-04] latency fields
                "latency_cycles": path.latency_cycles,
                "is_async_crossing": path.is_async_crossing,
                "latency_note": path.latency_note,
                # [ADD 2026-07-04] stage breakdown
                "stage_breakdown": getattr(path, "stage_breakdown", []),
            }
        )

    data = {
        "ok": True,
        "command": "dataflow",
        "params": {"from_signal": from_signal, "to_signal": to_signal, "bits": bits,
                   "file": str(file) if file else None, "filelist": filelist,
                   "from_snapshot": from_snapshot,
                   "max_paths": max_paths, "max_expansions": max_expansions,
                   "timeout": timeout_s, "evidence": evidence},
        "result": {
            "from_signal": result.from_signal,
            "to_signal": result.to_signal,
            "from_resolved": from_id,
            "to_resolved": to_id,
            "bits": {"src": src_info, "dst": dst_info,
                     "coarse_fallback": bool(src_info["coarse_fallback"]
                                             or dst_info["coarse_fallback"])},
            # [P158.11.2b] is_reachable 三态: true / false / null(未查完)
            "is_reachable": result.is_reachable,
            "search_status": result.search_status,
            "truncated": result.truncated,
            "truncation_reason": result.truncation_reason,
            "expansions": result.expansions,
            "elapsed_s": result.elapsed_s,
            "paths_count": result.paths_count,
            "intermediate_signals": sorted(result.intermediate_signals),
            # [ADD 2026-07-04] latency summary at top level
            "primary_latency_cycles": result.primary_latency_cycles,
            "primary_is_async": result.primary_is_async,
            "all_conditions": result.all_conditions,
            "clock_domain": result.clock_domain,
            "timing_risk": result.timing_risk,
            "risk_model": result.risk_model,
            "paths": paths_data,
        },
        "errors": [],
    }

    if result.search_status == "unknown":
        # [P158.11.2b] 预算/超时耗尽 ≠ 不可达 (SEMANTIC_CONTRACTS §3.3):
        # is_reachable=null 且显式标 unknown，不要把"没查完"当成 found:false。
        data["result"]["machine"] = {
            "unknown_kind": "search_budget_exhausted",
            "truncation_reason": result.truncation_reason,
        }

    if json_output:
        emit_json(data, pretty)
    else:
        output_text(data, human=human, tree=tree)
