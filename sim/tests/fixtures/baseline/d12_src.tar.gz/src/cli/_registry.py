"""
cli/_registry.py — CLI 分层注册表 (单一真相源)

[iter_230 P0 2026-09-09] 背景: CLI 长到 21 组 / 64 叶子命令平铺在一个命名空间里,
agent (主消费者) 无法从命令名判断该用哪个, 也不知道哪些是稳定契约、哪些只是试验。

本模块只做一件事: **把"每个命令属于哪一层、什么承诺等级"变成代码里的数据**,
供三处消费:
  1. `sv_query capabilities --json`  — agent 的工具面真相源
  2. `tools/gen_cli_surface.py` — 生成 docs/CLI_SURFACE.md (可重生成, 不手写)
  3. `tools/check_cli_layers.py` — 机械校验分层/只读/反向依赖

设计原则 (与 AGENTS 纪律一致):
  - **目录体现承诺等级与消费者; 属性体现副作用/成本/输出形态。**
    不为每个属性建目录 (会组合爆炸), 而是用 LayerSpec + CommandSpec 声明。
  - 注册表是**声明式**的: 某个命令没被登记 → `check_cli_layers.py` 报错, 不允许"忘了分层"。
  - P0 阶段**不改命令行为**: 本表只描述现状 + 记录已定的改名计划 (planned_name)。

层级 (2026-09-09 方豆拍板):
  core  : agent 一等公民 —— 只读 + JSON + 稳定 schema
  view  : 人眼面 —— 图与叙述, 默认含于 capabilities, 后续重点开发
  exp   : 降级区 —— 无 schema 承诺, 只修 bug 不加功能 (总线域 + 验证域 + 待定算法)
  dev   : 开发者内部调试, 不进用户文档
  out   : 移出 CLI (会写文件) → 交给 tools/
"""
from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# 1. 层规范 (承诺等级 + 消费者)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class LayerSpec:
    """一层的契约。改这里 = 改对外的承诺。"""
    name: str
    consumer: str            # agent / human / dev / none
    stability: str           # stable / unstable / none
    readonly: bool           # 是否禁止任何文件写入
    json_required: bool      # 是否要求所有命令支持 --json
    in_capabilities: bool    # 是否出现在 capabilities 默认输出
    schema_version: str | None = None   # 非 None = 输出 schema 有版本承诺
    note: str = ""


LAYERS: dict[str, LayerSpec] = {
    "core": LayerSpec(
        name="core", consumer="agent", stability="stable", readonly=True,
        json_required=True, in_capabilities=True, schema_version="1",
        note="agent 一等公民: 只读 + JSON + 稳定 schema; readonly = 不改 RTL/项目文件, "
             "cache/output 由 write_scope 标记",
    ),
    "view": LayerSpec(
        name="view", consumer="human", stability="stable", readonly=True,
        json_required=False, in_capabilities=True, schema_version=None,
        note="人眼面 (历史): 当前无注册命令; 全设计图已退役",
    ),
    "exp": LayerSpec(
        name="exp", consumer="none", stability="unstable", readonly=True,
        json_required=False, in_capabilities=False, schema_version=None,
        note="降级区: 直接命令 (hidden, 无统一 exp 命名空间入口); 无 schema 承诺, 只修 bug; --include-exp 才列出",
    ),
    "dev": LayerSpec(
        name="dev", consumer="dev", stability="none", readonly=True,
        json_required=False, in_capabilities=False, schema_version=None,
        note="开发者内部调试 (当前无命令; expression 已于 iter_252 归档)",
    ),
    "out": LayerSpec(
        name="out", consumer="none", stability="none", readonly=True,
        json_required=False, in_capabilities=False, schema_version=None,
        note="移出 CLI (会写 RTL/项目文件) → tools/; 不算产品命令",
    ),
}

# core 内部三段: 语义 (agent 主力) / 定位原语 / 状态 / 诊断
CORE_GROUPS = {
    "semantic": "语义事实: 关系查询 (drivers/loads/conditions/path) —— agent 推理链主力",
    "locate": "定位原语: 枚举与统计 (search/stats/graph) —— 低层但 agent 需要",
    "verify": "验证: claim/consistency/structural —— 结论可反驳",
    "scope": "作用域/清单: scope/instances/ports/params/connections/class",
    "state": "状态: graph 快照与比较 (写自有状态, 不碰项目文件)",
}


# ---------------------------------------------------------------------------
# 2. 命令规格 + 分类表 (现状 = 真相; planned_name = 已定的改名)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CommandSpec:
    key: str                 # 现状命令路径 ("trace fanin" / "stats")
    layer: str               # core / view / exp / dev / out
    group: str               # 层内分组 (core: semantic/locate/state/diagnose)
    kind: str                # fact / primitive / presentation / diagnosis / state / debug
    cost: str                # cheap / medium / expensive
    json: bool               # 是否已有 --json
    stateful: bool = False
    recommended: bool = False   # agent 默认优先使用 (capabilities --recommended)
    planned_name: str | None = None   # 已定的改名 (P1 执行, 老名保留 alias)
    envelope: str = "standard"       # standard | direct
    write_scope: str = "none"        # none | cache | output
    note: str = ""


def _c(key, group, kind="fact", cost="medium", json=True, *, stateful=False,
       recommended=False, planned=None, envelope="standard", write_scope="none",
       note="") -> CommandSpec:
    return CommandSpec(key=key, layer="core", group=group, kind=kind, cost=cost,
                       json=json, stateful=stateful, recommended=recommended,
                       planned_name=planned, envelope=envelope,
                       write_scope=write_scope, note=note)


def _v(key, kind="presentation", cost="expensive", json=False, note="") -> CommandSpec:
    """[iter_327 / PLAN P31] 人眼/展示能力统一降级到 exp（默认隐藏、不进 capabilities）。"""
    return CommandSpec(key=key, layer="exp", group="render", kind="experimental",
                       cost=cost, json=json,
                       note=(note + " ; [exp] experimental, hidden by default"))


def _e(key, group, cost="medium", note="") -> CommandSpec:
    return CommandSpec(key=key, layer="exp", group=group, kind="experimental",
                       cost=cost, json=False, note=note)


def _d(key) -> CommandSpec:
    return CommandSpec(key=key, layer="dev", group="internal", kind="debug",
                       cost="cheap", json=True)


def _o(key, note="") -> CommandSpec:
    return CommandSpec(key=key, layer="out", group="mutating", kind="mutating",
                       cost="cheap", json=False, note=note)


COMMANDS: list[CommandSpec] = [
    # ---- core / semantic (agent 主力) ----
    _c("drivers", "semantic", recommended=True, cost="medium",
       note="[规范入口] 谁驱动这个信号 (上游; DRIVER 边反向遍历); 兼容别名 trace fanin"),
    _c("loads", "semantic", recommended=True, cost="medium",
       note="[规范入口] 这个信号被谁使用 (下游; DRIVER 边正向遍历); 兼容别名 trace fanout"),
    _c("trace evidence", "semantic", recommended=True, note="源码证据 (always/if 块原文)"),
    _c("trace profile", "semantic", recommended=True, cost="cheap",
       note="信号 profile: canonical/aliases/位映射/clock/reset/sequential/source (波形关联)"),
    _c("trace lookup", "semantic", recommended=True, cost="cheap",
       note="完整 RTL hier path → canonical id (严格; $root/位父回退/aliases; 不做模糊后缀)"),
    _c("trace manifest", "semantic", recommended=True, cost="medium",
       note="批量 waveform manifest: full path → canonical + profile (type/bit/clock/reset/stage)"),
    _c("trace constraints", "semantic", cost="cheap",
       note="[P63] 属性受哪些 constraint 约束 (类型/实例; 独立语义域, 不走 fanin)"),
    _c("trace constraint-neighborhood", "semantic", cost="medium",
       note="一次查询跨多个 constraint block 的 random 变量关系图 "
            "(co-constraint, 非 fanin; 含重要性指标, 启发式)"),
    _c("trace tb-join", "semantic", cost="cheap",
       note="TB random field → RTL snapshot candidate join "
            "(name-based; single_candidate 不是连接证明)"),
    _c("trace frontier", "semantic", cost="cheap",
       note="结构 trace 的边界/断点 + 下一步 probe；不分类 FIFO"),
    _c("trace constraint-chain", "semantic", cost="cheap",
       note="两个 random 变量之间的最短 constraint 链 (co-membership; 非 solver 证明)"),
    _c("trace covergroups", "semantic", cost="cheap",
       note="[P63] 列出 covergroup 定义 (可按 class 过滤)"),
    _c("trace coverpoints", "semantic", cost="cheap",
       note="[P63] 反向查询: 信号被哪些 covergroup/coverpoint 采样"),
    _c("trace covergroup", "semantic", cost="medium",
       note="[P63] covergroup 采样链; --rand 查属性→约束链"),
    _c("controlflow analyze", "semantic", cost="medium", recommended=True,
       note="信号的驱动条件分析; --conditions-only 只要扁平条件列表 (原 controlflow conditions)"),
    _c("controlflow list-conditioned", "semantic", cost="expensive",
       note="列出所有带条件驱动的信号 (枚举, 用于找入口)"),
    _c("dataflow analyze", "semantic", recommended=True,
       note="源→目标路径 (有向, 跨模块; 实例级 id; 与 paths --directed 结论一致)"),
    # [iter_330 / PLAN P34.1] 客观检查: 双向一致性 + claim verification
    _c("verify consistency", "verify", kind="fact", cost="medium", recommended=True,
       note="双向一致性: fanin/fanout、bit parent/bit_range、connection port↔internal"),
    _c("verify claim", "verify", kind="fact", cost="medium", recommended=True,
       note="验证 claim: driver/path/connection/bit → verified|contradicted|unknown"),
    _c("verify structural", "verify", kind="fact", cost="medium",
       note="[P61] 结构审查: sibling 端口集合对称性 → findings + evidence + subgraph spec"),
    # [iter_236 1a] 实例/层级查询 (补 agent 理解架构的第一步; 复用 get_instances/MIG)
    _c("scope", "scope", kind="fact", cost="cheap", recommended=True,
       note="[规范入口] scope 聚合: 类型/父/子/端口/参数 (入口层, 不做因果追踪)"),
    _c("instances", "semantic", cost="cheap", recommended=True,
       envelope="direct",
       note="列出实例; 给实例路径 → 详情 (类型/父/子/端口); 支持 --filelist"),
    _c("connections", "semantic", cost="medium", recommended=True,
       envelope="direct",
       note="[规范入口] 连接: 仅接受实例路径 → 端口↔内部信号 (输出带 resolved_as; 模块类型明确报错)"),
    _c("hierarchy", "semantic", cost="medium", recommended=True,
       envelope="direct",
       note="[规范入口] 实例层级树 (机器可读版 arch show)"),
    # [iter_237] 语义查询补全 (参数 override / 端口总览 / 跨模块路径 / class)
    _c("params", "semantic", cost="cheap", recommended=True,
       envelope="direct",
       note="[规范入口] 实例的**生效**参数值 (含 is_overridden: 区分 override 与默认)"),
    _c("ports", "semantic", cost="cheap", recommended=True,
       envelope="direct",
       note="[规范入口] 模块端口总览 (方向/位宽/入边数/出边数)"),
    _c("paths", "semantic", cost="medium", recommended=True,
       note="[规范入口] 图上路径 (实例级 id; --all 枚举; "
            "--directed 只沿数据流方向, 与 dataflow analyze 结论一致)"),
    _c("class", "semantic", cost="medium", envelope="direct",
       note="不给 name → 列出所有 class; 给了 → 成员(类型级)+实例(实例级); --member 查某成员实例"),
    CommandSpec(key="audit", layer="exp", group="semantic", kind="experimental",
                cost="medium", json=True, recommended=False,
                note="[exp] 设计审计; 启发式/完成度低, 默认不提供, 仅 --include-exp 列出"),
    CommandSpec(key="trace impact", layer="exp", group="semantic", kind="experimental",
                cost="expensive", json=True, recommended=False,
                note="[exp] 传递影响 + 启发式风险分 (未标定, 仅同一图内相对排序; 见 KNOWN_LIMITATIONS §3.4); "
                     "[P158.12/R-025 2026-11-11] 未标定启发式按铁律 9 降级 exp, 不伪装稳定"),

    # ---- core / locate (枚举与统计) ----
    _c("stats", "locate", kind="primitive", cost="cheap", recommended=True),
    _c("search", "locate", kind="primitive", cost="cheap",
       envelope="direct", note="文本/正则搜索; [iter_231] 已补 --json"),
    _c("graph nodes", "locate", kind="primitive", cost="cheap",
       note="列图节点 (kind/module/--match 过滤; --detail 给表达式等富字段); 支持 --file / --filelist"),
    _c("graph edges", "locate", kind="primitive", cost="cheap",
       note="列出图边; 支持 --file / --filelist (iter_236 补)"),
    _c("filelist prune", "locate", kind="primitive", cost="cheap",
       write_scope="output",
       note="[P91/P158.5] top-aware 保守 filelist 裁剪; 默认 dry-run; --apply 才写; 只允许 .f/.fl; 覆盖需 --force + .bak"),
    _c("graph subgraph", "locate", kind="primitive", cost="cheap",
       note="[P60] seed 的 k-hop 局部子图; depth/direction/edge-kinds/budget; JSON boundary/truncated"),
    CommandSpec(key="diagnose", layer="exp", group="diagnose", kind="experimental",
                cost="cheap", json=True, recommended=False,
                note="[exp] 只读诊断; --json 干净路径不稳定, 默认不提供, 仅 --include-exp 列出"),
    _c("capabilities", "locate", kind="primitive", cost="cheap", recommended=True,
       envelope="direct",
       note="本清单自身 (agent 应先读它再决定调什么)"),

    # ---- core / state (你已定: graph 比较算 core) ----
    _c("snapshot save", "state", kind="state", cost="medium", stateful=True,
       envelope="direct", write_scope="cache",
       note="[iter_239 1b] 默认写缓存目录 (~/.svq/cache/snapshots; 可用 SVQ_SNAPSHOT_DIR 覆盖)"),
    _c("snapshot list", "state", kind="state", cost="cheap", stateful=True,
       envelope="direct",
       note="列出快照; 给 tag → 该快照详情 (原 snapshot show)"),
    _c("snapshot compare", "state", kind="state", cost="medium", recommended=True,
       envelope="direct",
       note="比较两个快照, 或两个 SV 文件 (文件模式 = 原 diff compare; --signal 看可达性差异)"),
    _c("snapshot delete", "state", kind="state", cost="cheap", stateful=True,
       envelope="direct", write_scope="cache",
       note="[iter_231] 已补 --json"),

    # ---- core / diagnose (原 fix 只读部分) ----

    # ---- view (人眼面, 默认含于 capabilities) ----
    _v("trace overview", kind="presentation", cost="expensive",
       note="两个信号之间的综合叙述 (dataflow + controlflow + evidence)"),
    _v("review render", cost="cheap",
       note="[P62] 单个 structural finding 的局部 SVG/HTML; 只消费 subgraph"),
    _v("architecture graph", kind="presentation", cost="medium", json=True,
       note="[P133] module/instance architecture graph from real net connections; "
            "not the retired full signal graph"),
    # ---- dev (内部调试) ----


    # ---- out: CLI 内已无会写文件的命令 (2026-09-09 方豆: sv_query 不改 RTL) ----
    # 写入能力现在只在 tools/: fix_timescale.py --apply (改 .sv) / fix_imports.py --write (写 filelist)
    # 若将来再加会写文件的命令 → 归入本层, 并由 R3 检查器拦截。
]

COMMANDS_BY_KEY: dict[str, CommandSpec] = {c.key: c for c in COMMANDS}

# ---------------------------------------------------------------------------
# 兼容别名 (老命令名 → 规范名)
#   [iter_231 P1] 方豆决定方案 (a): 语义 core 的规范入口是**顶层关系名**
#   (`sv_query drivers` / `sv_query loads`), 老名在 `trace` 组内保留为兼容别名。
#   别名与规范名是**同一个函数对象** (无第二份实现/签名) → 输出必然一致。
# ---------------------------------------------------------------------------
ALIASES: dict[str, str] = {
    "trace fanin": "drivers",
    "trace fanout": "loads",
    # [iter_248 T2] fix <x> 别名已删除: 诊断统一为 `diagnose <check>`, 只读
    # [iter_235 P3] exp 降级区收进 `sv_query exp ...` 前缀; 老路径保留为兼容别名
}


def canonical(key: str) -> str:
    """别名 → 规范名; 规范名原样返回。"""
    return ALIASES.get(key, key)


_SCOPE_KEYS = {
    "scope", "instances", "hierarchy", "ports", "params", "connections", "class",
}
_TRACE_KEYS = {
    "drivers", "loads", "trace fanin", "trace fanout", "trace impact",
    "trace evidence", "trace profile", "trace lookup", "trace manifest",
    "trace constraints", "trace constraint-neighborhood", "trace constraint-chain",
    "trace tb-join", "trace frontier", "trace covergroups", "trace coverpoints", "trace covergroup",
    "paths", "dataflow analyze", "controlflow analyze", "controlflow list-conditioned",
}
_VERIFY_KEYS = {"verify consistency", "verify claim", "verify structural"}
_STATE_KEYS = {"snapshot save", "snapshot list", "snapshot compare", "snapshot delete"}


def mode_of(key: str, layer: str = "core") -> str:
    """[iter_344 / PLAN P44.2] agent 工作流模式: scope|trace|verify|locate|state|exp."""
    if layer != "core":
        return "exp"
    if key in _SCOPE_KEYS:
        return "scope"
    if key in _TRACE_KEYS:
        return "trace"
    if key in _VERIFY_KEYS:
        return "verify"
    if key in _STATE_KEYS:
        return "state"
    return "locate"


def aliases_of(canonical_key: str) -> list[str]:
    return sorted(a for a, c in ALIASES.items() if c == canonical_key)

# 计划新增 (P1+, 语义 core 缺口): instance 查询
NEW_PLANNED: list[dict] = [
    # [iter_236 1a] instances / instance / connections / hierarchy 已落地 (core/semantic)。
    # 候选 (未拍板): 参数/端口 override 查询; class 实例成员 (trace_member_instances 仍未暴露)。
]


# ---------------------------------------------------------------------------
# 3. 查询辅助 (供 capabilities / 生成器 / 检查器共用)
# ---------------------------------------------------------------------------
def spec_for(key: str) -> CommandSpec | None:
    return COMMANDS_BY_KEY.get(key)


def layer_of(key: str) -> str | None:
    s = spec_for(key)
    return s.layer if s else None


def counts() -> dict:
    """按层/组统计 (生成器与检查器共用, 避免两处各算一遍)。"""
    by_layer: dict[str, int] = {}
    by_group: dict[str, int] = {}
    for c in COMMANDS:
        by_layer[c.layer] = by_layer.get(c.layer, 0) + 1
        if c.layer == "core":
            by_group[c.group] = by_group.get(c.group, 0) + 1
    return {"total": len(COMMANDS), "by_layer": by_layer, "core_by_group": by_group}


# ---------------------------------------------------------------------------
# 位精确性契约 (agent 可发现性; 与 docs/architecture/trace_capability_review 同步)
# 只描述"静态可判定"部分, 运行期相关形态明确列为 coarse。
# ---------------------------------------------------------------------------
JSON_CONTRACT = {
    "schema_version": "1",
    "policy": (
        "v1 allows additive optional fields; removing/renaming a field, changing a "
        "field type, or adding a required field requires a schema_version bump. "
        "Nullable values use JSON null when the field is present; optional fields "
        "may be omitted only when the command schema marks them optional. Absence "
        "is not false/zero."
    ),
    "scope": (
        "Core commands are readonly with respect to project/RTL files. Standard "
        "envelope applies unless the command is explicitly marked envelope=direct "
        "in capabilities; direct commands document their own success/error shape."
    ),
    "envelope_policy": {
        "standard": "ok/command/params/result/errors",
        "direct": "command-specific top-level object or array; may omit result/errors",
        "exceptions": ["capabilities", "search", "instances", "hierarchy", "ports",
                       "params", "connections", "class", "snapshot save",
                       "snapshot list", "snapshot compare", "snapshot delete"],
        "rule": "capabilities.commands[].envelope is the machine-readable source of truth",
    },
    "nullable_policy": {
        "present_null": "known-but-empty value is JSON null",
        "optional_omission": "not-applicable optional fields may be omitted when "
                             "documented in the command schema",
        "absence_is_not_false": True,
    },
    "errors_policy": {
        "union": "array<string|error_entry>",
        "error_entry_required": ["error"],
        "trace_entry_fields": ["signal", "index", "error", "error_code",
                               "resolution", "candidates"],
        "direct_error_fields": ["error", "path", "hint"],
        "rule": "consumers must accept strings and objects; error is always present "
                "on an error_entry; error_code is optional outside trace commands",
    },
    "write_scope_policy": {
        "none": "no disk writes",
        "cache": "writes only the sv_query cache/snapshot directory",
        "output": "writes only a caller-specified output file, never source RTL",
        "contract": "core.readonly means no project/RTL mutation; write_scope labels "
                    "the explicit cache/output exceptions",
    },
    "top_level": {
        "ok": {"type": "boolean", "desc": "false if any per-signal error was recorded"},
        "command": {"type": "string", "desc": "command name, e.g. trace_fanin"},
        "params": {"type": "object", "desc": "echo of resolved request parameters"},
        "result": {"type": "object", "desc": "command-specific result payload"},
        "errors": {"type": "array<string|error_entry>", "desc": "errors; empty when ok=true; trace commands use error_entry objects, overview/legacy may use strings"},
    },
    "trace_signal": {
        "signal": {"type": "string", "desc": "queried signal id (as requested)"},
        "index": {"type": "integer", "desc": "position in the batch/signals request"},
        "resolved_signal": {"type": "string|null", "desc": "canonical graph id after resolution"},
        "resolution": {"type": "string", "enum": ["exact", "relative", "bit_base_fallback",
                                                  "not_found", "ambiguous", "internal"],
                       "desc": "how the requested signal resolved"},
        "candidates": {"type": "array<string>", "desc": "ambiguous candidate ids"},
        "suggestions": {"type": "array<string>", "desc": "not_found suggestions"},
        "error": {"type": "string", "desc": "per-signal resolution/query error"},
        "precision": {
            "type": "string", "enum": ["bit", "bus", "unknown"],
            "desc": "answer granularity; unknown means runtime/opaque dependency",
        },
        "coarse_fallback": {
            "type": "boolean",
            "desc": "bit query mixed with bus/constant fallback; downgrade to bus",
        },
        "top_modules": {
            "type": "array<string>",
            "desc": "compiled top modules (requires --top if multiple for bit fallback)",
        },
        "top_ambiguous": {
            "type": "boolean",
            "desc": "multiple tops and no --top; use --top for an explicit scope",
        },
        "bit_fallback": {
            "type": "boolean",
            "desc": "requested bit had no node; answer uses parent bus",
        },
        "dynamic_index": {
            "type": "boolean",
            "desc": "runtime index (mem[i]) affects this query -> precision=unknown",
        },
        "function_call": {
            "type": "boolean",
            "desc": "function call result/condition affects this query (not inlined) -> unknown",
        },
        "runtime_system_call": {
            "type": "boolean",
            "desc": "runtime system call ($random/$urandom/...) affects this query -> unknown",
        },
        "conditions": {
            "type": "array<string>",
            "desc": "per-path condition expressions (direct edge or multi-path OR components)",
        },
        "condition_truncated": {
            "type": "boolean",
            "desc": "condition path enumeration hit caps; conditions may be incomplete",
        },
        "truncated_by_depth": {
            "type": "boolean",
            "desc": "a node at the depth boundary still has unexpanded edges",
        },
        "cycles_detected": {
            "type": "boolean|null",
            "desc": "reachable cycle in traversal direction; null = analysis cap reached",
        },
        "count": {"type": "integer", "desc": "returned item count after filters"},
        "pre_filter_count": {"type": "integer", "desc": "item count before filters"},
        "truncated": {"type": "boolean", "desc": "max_results cap applied (independent of depth)"},
    },
    "trace_node": {
        "id": {"type": "string", "desc": "graph node id"},
        "module": {"type": "string", "desc": "instance/module path"},
        "kind": {"type": "string", "desc": "NodeKind name (SIGNAL/PORT_IN/...)"},
        "width": {"type": "integer", "desc": "bit width (0 if unknown)"},
        "width_msb": {"type": "integer|null", "desc": "declared MSB"},
        "width_lsb": {"type": "integer|null", "desc": "declared LSB"},
        "distance": {"type": "integer", "desc": "hops from query signal; 1 = direct"},
        "precision": {
            "type": "string", "enum": ["bit", "bus", "constant", "unknown"],
            "desc": "node granularity",
        },
        "is_signed": {"type": "boolean|null", "desc": "declared signedness, null if unknown"},
        "parent": {"type": "string|null", "desc": "parent bus/member node id"},
        "bit_range": {"type": "array|null", "desc": "[hi, lo] for slice/bit nodes"},
        "dynamic_index": {"type": "boolean", "desc": "runtime index affects node"},
        "function_call": {"type": "boolean", "desc": "function call result/condition node"},
        "runtime_system_call": {"type": "boolean", "desc": "runtime system call node"},
        "condition": {
            "type": "string",
            "desc": "direct-edge OR or multi-path OR for this node; empty = unconditional",
        },
        "conditions": {
            "type": "array<string>",
            "desc": "preserved per-edge/per-path conditions (not flattened)",
        },
        "condition_path": {
            "type": "array<string>",
            "desc": "first path's raw conditions (compat with P23)",
        },
        "condition_paths": {
            "type": "array<object>",
            "item": {"condition": "string", "path": "array<string>",
                     "simplified": "string", "analysis": "object"},
            "desc": "each path: raw condition + raw sequence + L1 simplified/analysis",
        },
        "condition_unconditional": {
            "type": "boolean",
            "desc": "at least one path has no condition -> condition is empty",
        },
        "condition_truncated": {
            "type": "boolean",
            "desc": "path enumeration hit caps for this node",
        },
        "condition_simplified": {
            "type": "string",
            "desc": "L1 simplified OR; empty = unconditional; original preserved",
        },
        "conditions_simplified": {
            "type": "array<string>",
            "desc": "per-condition L1 simplified forms (original still in conditions)",
        },
        "condition_analysis": {
            "type": "object",
            "desc": "changed/method/confidence/four_state_safe/tautology/unsat/analysis_incomplete",
        },
        "condition_analysis_incomplete": {
            "type": "boolean",
            "desc": "at least one condition parse failed; simplified not authoritative",
        },
    },
    "condition_analysis": {
        "changed": {"type": "boolean", "desc": "simplified differs from canonical original"},
        "method": {"type": "string", "desc": "local_bool_v1|parse_failed|empty"},
        "confidence": {"type": "string", "desc": "atom_identity|unknown"},
        "four_state_safe": {"type": "boolean", "desc": "identities sound under X/Z"},
        "tautology": {"type": "boolean", "desc": "simplified to true"},
        "unsat": {"type": "boolean", "desc": "simplified to false"},
        "analysis_incomplete": {"type": "boolean", "desc": "parse failed / incomplete"},
        "error": {"type": "string|null", "desc": "parse error if any"},
    },
    "commands": {
        "trace fanin": {
            "result_fields": ["drivers"],
            "signal_fields": ["driver_count", "multi_driver", "conditional_drivers",
                              "driver_conflict", "driver_conflict_analysis"],
            "node_array": "drivers",
        },
        "trace fanout": {
            "result_fields": ["loads"],
            "signal_fields": [],
            "node_array": "loads",
        },
        "paths": {
            "envelope": "direct",
            "optional_fields": ["edge_evidence"],
            "base_fields": ["ok", "src", "dst", "src_resolved", "dst_resolved",
                            "bits", "directed", "mode"],
            "modes": {"one": ["found", "hop_count", "path"],
                      "all": ["count", "truncated", "truncation_reason",
                              "expansions", "all_paths"],
                      "canonical": ["canonical", "canonical_policy",
                                    "candidate_count", "candidate_truncated",
                                    "truncated", "truncation_reason",
                                    "expansions", "found", "hop_count", "path"]},
            "node_array": "path",
        },
        "dataflow analyze": {
            "result_fields": ["from_signal", "to_signal", "from_resolved",
                              "to_resolved", "bits", "is_reachable",
                              "search_status", "truncated", "truncation_reason",
                              "expansions", "elapsed_s", "paths_count",
                              "intermediate_signals", "primary_latency_cycles",
                              "primary_is_async", "all_conditions", "clock_domain",
                              "timing_risk", "risk_model", "paths"],
            "path_fields": "dataflow_path",
            "segment_fields": "dataflow_segment",
        },
        "trace impact": {
            "result_fields": ["signals", "total_signals", "total_paths",
                              "total_high_risk_count", "failed_signals", "risk_model"],
            "signal_fields": "impact_signal",
            "path_fields": "impact_path",
        },
        "graph nodes": {
            "result_fields": ["nodes", "total"],
            "node_fields": "graph_node",
            "detail_fields": "graph_node_detail",
        },
        "graph edges": {
            "result_fields": ["edges", "total"],
            "edge_fields": "graph_edge",
        },
        "graph subgraph": {
            "optional_top_level": ["seeds"],
            "result_fields": ["nodes", "edges", "boundary", "truncated", "stats"],
            "node_fields": "subgraph_node",
            "edge_fields": "subgraph_edge",
        },
        "search": {
            "envelope": "direct",
            "fields": "search_result",
            "file_fields": "search_file",
            "line_fields": "search_line",
        },
        "stats": {
            "result_fields": ["total_nodes", "total_edges", "nodes", "edges",
                              "modules", "elaboration_errors"],
        },
        "trace evidence": {
            "optional_top_level": ["evidence"],
            "result_fields": ["signals", "total_signals", "failed_signals"],
            "signal_fields": "evidence_signal",
            "payload_fields": "evidence_payload",
        },
        "trace profile": {
            "result_fields": ["signals", "total_signals", "failed_signals"],
            "signal_fields": "profile_signal",
        },
        "trace lookup": {
            "result_fields": ["paths", "total", "found", "failed"],
            "path_fields": "lookup_path",
        },
        "trace manifest": {
            "result_fields": ["entries", "total", "found", "failed"],
            "entry_fields": "manifest_entry",
        },
        "trace constraints": {
            "result_fields": ["property", "resolved", "count", "constraints"],
            "constraint_fields": "constraint_block",
        },
        "trace constraint-neighborhood": {
            "result_fields": ["root", "nodes", "relations", "paths", "summary"],
        },
        "trace tb-join": {
            "result_fields": ["tb_field", "leaf", "constraints", "join_status",
                              "rtl_candidates", "note"],
        },
        "trace frontier": {
            "result_fields": ["signal", "frontier", "summary", "note"],
        },
        "trace constraint-chain": {
            "result_fields": ["found", "source", "target", "rand", "hop_count",
                              "chain", "segments", "blocks", "summary", "note"],
        },
        "trace covergroups": {
            "result_fields": ["count", "covergroups", "complete", "reason"],
            "covergroup_fields": "class_covergroup",
        },
        "trace coverpoints": {
            "result_fields": ["signal", "count", "matches", "complete", "reason"],
            "match_fields": "coverpoint_ref",
        },
        "trace covergroup": {
            "result_fields": ["mode", "covergroup", "count", "links", "samples",
                              "complete", "reason"],
            "sample_fields": "covergroup_sampling",
            "link_fields": "covergroup_rand",
        },
        "controlflow analyze": {
            "result_fields": ["signal", "conditioned_drivers", "condition_status", "warnings"],
            "driver_fields": "controlflow_driver",
            "condition_fields": "controlflow_condition",
            "edge_fields": "controlflow_edge",
        },
        "controlflow list-conditioned": {
            "optional_top_level": ["subcommand"],
            "result_fields": ["signals", "count"],
        },
        "verify consistency": {
            "result_fields": ["verified", "coverage_complete", "partial_checks",
                              "total_violations", "unknown_checks", "checks"],
            "check_fields": "verify_check",
        },
        "verify claim": {
            "result_fields": ["claim", "status", "reason", "evidence", "counterevidence"],
        },
        "verify structural": {
            "result_fields": ["findings", "total", "truncated", "checks"],
            "finding_fields": "structural_finding",
        },
        "scope": {
            "result_fields": ["scope", "canonical_id", "kind", "module_type", "parent",
                              "children", "ports", "parameters", "signals",
                              "members", "instances"],
            "port_fields": "scope_port",
            "signal_fields": "scope_signal",
            "param_fields": "scope_param",
            "child_fields": "scope_child",
        },
        "instances": {
            "envelope": "direct",
            "fields": "instances_result",
            "item_fields": "instance_item",
            "error_fields": "direct_error",
        },
        "hierarchy": {
            "envelope": "direct",
            "fields": "hierarchy_result",
            "node_fields": "hierarchy_node",
        },
        "ports": {
            "envelope": "direct",
            "fields": "ports_result",
            "item_fields": "port_item",
        },
        "params": {
            "envelope": "direct",
            "fields": "params_result",
            "item_fields": "param_item",
            "error_fields": "direct_error",
        },
        "connections": {
            "envelope": "direct",
            "fields": "connections_result",
            "item_fields": "connection_port",
            "error_fields": "direct_error",
        },
        "class": {
            "envelope": "direct",
            "fields": "class_result",
            "member_fields": "class_member",
            "instance_fields": "class_instance",
            "relations_fields": "class_relations",
        },
        "filelist prune": {
            "result_fields": ["top", "total_files", "selected_files",
                              "selected_count", "dropped", "reason",
                              "declarations", "output", "written", "dry_run",
                              "backup", "requires_apply"],
        },
        "capabilities": {
            "result_fields": ["version", "layers", "core_groups", "counts",
                              "planned_new", "bit_precision", "json_contract",
                              "commands"],
        },
        "snapshot save": {
            "result_fields": ["ok", "tag", "path", "files", "node_count",
                              "edge_count", "elaboration_errors", "failed_files"],
        },
        "snapshot list": {
            "result_fields": ["tag", "file", "created_at", "git_commit", "files",
                              "node_count", "edge_count", "module_graph_present",
                              "module_graph_instances", "module_graph_ports",
                              "tag_mismatch", "error"],
        },
        "snapshot compare": {
            "result_fields": ["tag1", "tag2", "stable_core", "health_score_old",
                              "health_score_new", "health_delta",
                              "coupling_warning", "added_nodes", "removed_nodes",
                              "added_edges", "removed_edges", "identical"],
        },
        "snapshot delete": {
            "result_fields": ["ok", "tag", "deleted", "error"],
        },
    },
    "bit_endpoint": {
        "requested_bit": {"type": "integer|null", "desc": "requested single bit, if any"},
        "requested_range": {"type": "string|null", "desc": "requested range hi:lo, if any"},
        "resolved": {"type": "string", "desc": "resolved graph node id (bit/slice/bus)"},
        "precision": {"type": "string", "enum": ["bit", "bus", "unknown"],
                      "desc": "resolution granularity"},
        "coarse_fallback": {"type": "boolean",
                            "desc": "requested bit/range node absent; fell back to bus"},
        "kind": {"type": "string",
                 "desc": "bit|range|bus|bit_fallback|range_fallback|... diagnostic kind"},
    },
    "bit_normalization": {
        "src": "bit_endpoint", "dst": "bit_endpoint",
        "coarse_fallback": {"type": "boolean", "desc": "either endpoint fell back"},
    },
    "paths_result": {
        "ok": {"type": "boolean", "desc": "path search executed"},
        "src": {"type": "string", "desc": "requested source"},
        "dst": {"type": "string", "desc": "requested destination"},
        "src_resolved": {"type": "string", "desc": "resolved source node"},
        "dst_resolved": {"type": "string", "desc": "resolved destination node"},
        "bits": "bit_normalization",
        "directed": {"type": "boolean", "desc": "directed vs undirected search"},
    },
    "paths_modes": {
        "one": {
            "found": {"type": "boolean", "desc": "at least one path found"},
            "hop_count": {"type": "integer|null", "desc": "edges in the path"},
            "path": {"type": "array<string>|null", "desc": "one node-id path"},
        },
        "all": {
            "count": {"type": "integer", "desc": "returned path count"},
            "truncated": {"type": "boolean", "desc": "max path cap applied"},
            "all_paths": {"type": "array<array<string>>", "desc": "node-id paths"},
        },
    },
    "dataflow_result": {
        "from_signal": {"type": "string", "desc": "resolved source used by analysis"},
        "to_signal": {"type": "string", "desc": "resolved destination"},
        "from_resolved": {"type": "string", "desc": "source resolution echo"},
        "to_resolved": {"type": "string", "desc": "destination resolution echo"},
        "bits": "bit_normalization",
        "is_reachable": {"type": "boolean|null", "desc": "true/false; null = search budget exhausted (未查完)"},
        # [P158.11.2b] 有界搜索的显式状态
        "search_status": {"type": "string", "desc": "complete|truncated|unknown"},
        "truncated": {"type": "boolean", "desc": "search incomplete (budget/deadline/cap)"},
        "truncation_reason": {"type": "string", "desc": "max_expansions_reached|deadline_reached|max_paths_reached|max_depth_reached; '' = complete"},
        "expansions": {"type": "integer", "desc": "work budget consumed (edges examined)"},
        "elapsed_s": {"type": "number", "desc": "search wall-clock seconds"},
        "paths_count": {"type": "integer", "desc": "returned path count"},
        "intermediate_signals": {"type": "array<string>", "desc": "sorted intermediate nodes"},
        "primary_latency_cycles": {"type": "integer", "desc": "best path latency"},
        "primary_is_async": {"type": "boolean", "desc": "async crossing on best path"},
        "all_conditions": {"type": "array<string>", "desc": "distinct conditions across paths"},
        "clock_domain": {"type": "string|null", "desc": "detected clock domain"},
        "timing_risk": {"type": "string", "desc": "safe|warning|critical model output"},
        "paths": {"type": "array<dataflow_path>", "desc": "dataflow paths"},
    },
    "dataflow_path": {
        "path_id": {"type": "integer", "desc": "index within result"},
        "segments": {"type": "array<dataflow_segment>", "desc": "ordered segments"},
        "distance": {"type": "integer", "desc": "path length (edges)"},
        "has_conditional": {"type": "boolean", "desc": "any segment conditioned"},
        "latency_cycles": {"type": "integer", "desc": "register-boundary latency"},
        "is_async_crossing": {"type": "boolean", "desc": "async crossing detected"},
        "latency_note": {"type": "string", "desc": "human-readable latency explanation"},
        "stage_breakdown": {"type": "array", "desc": "optional pipeline stage breakdown"},
    },
    "dataflow_segment": {
        "from_signal": {"type": "string", "desc": "segment source"},
        "to_signal": {"type": "string", "desc": "segment destination"},
        "driver": {"type": "string", "desc": "driver expression/signal"},
        "condition": {"type": "string", "desc": "condition text (empty = unconditional)"},
        "timing": {"type": "string", "desc": "timing classification"},
        "assign_type": {"type": "string", "desc": "continuous/always_ff/..."},
        "distance": {"type": "integer", "desc": "hops between endpoints"},
        "evidence": {"type": "object", "desc": "optional; only with --evidence"},
    },
    "impact_signal": {
        "signal": {"type": "string", "desc": "requested signal"},
        "index": {"type": "integer", "desc": "batch position"},
        "resolved_signal": {"type": "string", "desc": "resolved bit/slice/bus id"},
        "resolution": {"type": "string", "desc": "exact|relative|bit_base_fallback|not_found|ambiguous|internal"},
        "candidates": {"type": "array<string>", "desc": "ambiguous candidate ids"},
        "suggestions": {"type": "array<string>", "desc": "not_found suggestions"},
        "error": {"type": "string", "desc": "per-signal resolution/query error"},
        "requested_bit": {"type": "integer|null", "desc": "requested bit (legacy field)"},
        "precision": {"type": "string", "enum": ["bit", "bus", "unknown"],
                      "desc": "resolution granularity"},
        "coarse_fallback": {"type": "boolean", "desc": "fell back to bus"},
        "total_paths": {"type": "integer", "desc": "impact paths"},
        "high_risk_count": {"type": "integer", "desc": "paths marked HIGH"},
        "modules": {"type": "array<string>", "desc": "modules touched"},
        "paths": {"type": "array<impact_path>", "desc": "impact paths"},
    },
    "impact_path": {
        "path": {"type": "array<string>", "desc": "node-id path"},
        "path_type": {"type": "string", "desc": "combinational/sequential"},
        "risk": {"type": "string", "desc": "HIGH|MEDIUM|LOW"},
        "risk_score": {"type": "number", "desc": "heuristic risk score"},
        "fanout": {"type": "integer", "desc": "fanout count"},
        "coverage": {"type": "object", "desc": "sva/covergroup coverage tags"},
        "condition": {"type": "string", "desc": "path condition text"},
        "clock_domain": {"type": "string", "desc": "clock domain"},
        "suggestion": {"type": "string", "desc": "human suggestion"},
    },
    "graph_node": {
        "id": {"type": "string", "desc": "node id"},
        "name": {"type": "string", "desc": "short name"},
        "kind": {"type": "string", "desc": "node kind"},
        "module": {"type": "string", "desc": "module path"},
    },
    "graph_node_detail": {
        "width": {"type": "array", "desc": "[msb, lsb]"},
        "expression": {"type": "string", "desc": "expression text"},
        "operands": {"type": "array", "desc": "expression operands"},
        "signals": {"type": "array", "desc": "referenced signals"},
        "function_name": {"type": "string", "desc": "function name if call node"},
        "condition": {"type": "string", "desc": "condition text"},
        "true_branch": {"type": "string", "desc": "ternary true branch"},
        "false_branch": {"type": "string", "desc": "ternary false branch"},
    },
    "graph_nodes_result": {
        "nodes": {"type": "array", "desc": "node list (graph_node or graph_node_detail)"},
        "total": {"type": "integer", "desc": "returned node count"},
    },
    "error_entry": {
        "signal": {"type": "string", "desc": "failed signal"},
        "index": {"type": "integer", "desc": "batch position"},
        "error": {"type": "string", "desc": "human-readable error"},
        "error_code": {"type": "string", "desc": "stable error code"},
    },
    "graph_edge": {
        "src": {"type": "string", "desc": "edge source node id"},
        "dst": {"type": "string", "desc": "edge destination node id"},
        "kind": {"type": "string", "desc": "EdgeKind name (DRIVER/CLOCK/...)"},
    },
    "graph_edges_result": {
        "edges": {"type": "array<graph_edge>", "desc": "filtered edge list"},
        "total": {"type": "integer", "desc": "returned edge count"},
    },
    "subgraph_node": {
        "id": {"type": "string", "desc": "canonical node id"},
        "kind": {"type": "string", "desc": "NodeKind name"},
        "module": {"type": "string", "desc": "instance/module path"},
        "width_msb": {"type": "integer", "desc": "declared msb"},
        "width_lsb": {"type": "integer", "desc": "declared lsb"},
        "width": {"type": "integer", "desc": "bit width"},
        "precision": {"type": "string", "desc": "bit|bus|constant|unknown"},
        "parent": {"type": "string|null", "desc": "parent bus/member id"},
        "bit_range": {"type": "string|null", "desc": "select range"},
        "is_signed": {"type": "boolean|null", "desc": "declared signedness"},
        "file": {"type": "string", "desc": "source file when --evidence"},
        "line": {"type": "integer", "desc": "source line when --evidence"},
    },
    "subgraph_edge": {
        "src": {"type": "string", "desc": "edge source"},
        "dst": {"type": "string", "desc": "edge destination"},
        "kind": {"type": "string", "desc": "EdgeKind name"},
        "expression": {"type": "string", "desc": "driver expression"},
        "condition": {"type": "string", "desc": "edge condition"},
        "bit_slice": {"type": "string", "desc": "bit slice"},
        "assign_type": {"type": "string", "desc": "continuous/nonblocking/..."},
        "file": {"type": "string", "desc": "source file when --evidence"},
        "line": {"type": "integer", "desc": "source line when --evidence"},
    },
    "subgraph_result": {
        "nodes": {"type": "array<subgraph_node>", "desc": "local nodes"},
        "edges": {"type": "array<subgraph_edge>", "desc": "edges inside nodes"},
        "boundary": {"type": "array<string>", "desc": "stubs beyond depth/budget"},
        "truncated": {"type": "object", "desc": "nodes/edges/depth booleans"},
        "stats": {"type": "object", "desc": "visited/returned/max_depth"},
    },
    "search_result": {
        "keyword": {"type": "string", "desc": "search keyword"},
        "target": {"type": "string", "desc": "resolved search target"},
        "regex": {"type": "boolean", "desc": "regex mode"},
        "case_insensitive": {"type": "boolean", "desc": "case-insensitive mode"},
        "total_matches": {"type": "integer", "desc": "total matches"},
        "file_count": {"type": "integer", "desc": "files with matches"},
        "files": {"type": "array<search_file>", "desc": "per-file matches"},
    },
    "search_file": {
        "file": {"type": "string", "desc": "file path/id"},
        "match_count": {"type": "integer", "desc": "matches in file"},
        "lines": {"type": "array<search_line>", "desc": "matched lines"},
        "truncated": {"type": "boolean", "desc": "per-file max results cap applied"},
    },
    "search_line": {
        "line": {"type": "integer", "desc": "1-based line number"},
        "text": {"type": "string", "desc": "line text"},
    },
    "stats_result": {
        "total_nodes": {"type": "integer", "desc": "node count"},
        "total_edges": {"type": "integer", "desc": "edge count"},
        "nodes": {"type": "object", "desc": "node count by kind"},
        "edges": {"type": "object", "desc": "edge count by kind"},
        "modules": {"type": "array", "desc": "module list/info"},
        "elaboration_errors": {"type": "array", "desc": "elaboration issues"},
    },
    "evidence_payload": {
        "signal": {"type": "string", "desc": "signal id"},
        "source_location": {"type": "object|null", "desc": "file/line span"},
        "source_text": {"type": "string", "desc": "enclosing source snippet"},
        "enclosing_always": {"type": "string|null", "desc": "always block kind"},
        "enclosing_always_comb": {"type": "string|null", "desc": "always_comb marker"},
        "enclosing_if": {"type": "string|null", "desc": "if condition"},
        "enclosing_assign": {"type": "string|null", "desc": "assign statement"},
        "enclosing_class": {"type": "string|null", "desc": "class context"},
        "enclosing_constraint": {"type": "string|null", "desc": "constraint context"},
        "enclosing_chain": {"type": "array<string>", "desc": "enclosing chain"},
        "is_verified": {"type": "boolean", "desc": "evidence verified flag"},
        "credibility_score": {"type": "number", "desc": "0..1 heuristic score"},
    },
    "evidence_signal": {
        "signal": {"type": "string", "desc": "signal id"},
        "index": {"type": "integer", "desc": "batch position"},
        "resolved_signal": {"type": "string|null", "desc": "canonical graph id after resolution"},
        "resolution": {"type": "string", "desc": "exact|relative|bit_base_fallback|not_found|ambiguous|internal"},
        "candidates": {"type": "array<string>", "desc": "ambiguous candidate ids"},
        "suggestions": {"type": "array<string>", "desc": "not_found suggestions"},
        "error": {"type": "string", "desc": "per-signal resolution error"},
        "evidence": "evidence_payload",
    },
    "evidence_result": {
        "signals": {"type": "array<evidence_signal>", "desc": "per-signal evidence"},
        "total_signals": {"type": "integer", "desc": "requested signals"},
        "failed_signals": {"type": "integer", "desc": "evidence failures"},
    },
    "controlflow_edge": {
        "src": {"type": "string", "desc": "edge source"},
        "dst": {"type": "string", "desc": "edge destination"},
        "kind": {"type": "string", "desc": "edge kind"},
        "condition": {"type": "string", "desc": "edge condition text"},
    },
    "controlflow_condition": {
        "expr": {"type": "string", "desc": "condition expression"},
        "edge": "controlflow_edge",
    },
    "controlflow_driver": {
        "to_node": {"type": "string", "desc": "conditioned destination"},
        "conditions": {"type": "array<controlflow_condition>",
                       "desc": "conditions on this driver"},
    },
    "controlflow_result": {
        "signal": {"type": "string", "desc": "queried signal"},
        "conditioned_drivers": {"type": "array<controlflow_driver>",
                                 "desc": "drivers with conditions"},
        "warnings": {"type": "array<string>", "desc": "analysis warnings"},
    },
    "controlflow_list_result": {
        "signals": {"type": "array<string>", "desc": "signals with conditioned drivers"},
        "count": {"type": "integer", "desc": "signal count"},
    },
    "class_call": {
        "receiver": {"type": "string|null", "desc": "receiver object/member; null = bare call"},
        "method": {"type": "string", "desc": "called method"},
        "target_class": {"type": "string|null", "desc": "resolved owner class; null = unknown"},
    },
    "class_method": {
        "name": {"type": "string", "desc": "method name"},
        "kind": {"type": "string", "desc": "function|task"},
        "file": {"type": "string", "desc": "definition file"},
        "line": {"type": "integer", "desc": "definition line"},
        "calls": {"type": "array<class_call>", "desc": "calls inside body"},
    },
    "class_member_instances": {
        "member": {"type": "string", "desc": "member name"},
        "count": {"type": "integer", "desc": "graph instance-member nodes"},
        "instances": {"type": "array<class_instance>", "desc": "instance nodes"},
    },
    "class_constraint": {
        "target": {"type": "string", "desc": "constraint/member target id"},
        "kind": {"type": "string", "desc": "CONSTRAINS/HAS_* edge"},
    },
    "class_member_candidate": {
        "canonical_id": {"type": "string", "desc": "semantic instance member path"},
        "member": {"type": "string", "desc": "member name"},
        "class_instance": {"type": "string", "desc": "containing class instance path"},
        "in_graph": {"type": "boolean", "desc": "node exists in graph"},
        "kind": {"type": "string", "desc": "type-level member kind"},
        "width": {"type": "array|null", "desc": "[msb,lsb]"},
        "is_rand": {"type": "boolean", "desc": "rand/randc property"},
        "rand_mode": {"type": "string|null", "desc": "Rand|RandC|None"},
        "type": {"type": "string|null", "desc": "declared data type"},
    },
    "constraint_block": {
        "id": {"type": "string", "desc": "constraint block node id (canonical)"},
        "block": {"type": "string", "desc": "legacy alias of id (additive, v1)"},
        "vars": {"type": "array<string>", "desc": "constrained properties"},
        "conditions": {"type": "array<string>", "desc": "if/cover conditions"},
        "expr_count": {"type": "integer", "desc": "expressions in block"},
        "defined_in": {"type": "string", "desc": "defining class (base for inherited)"},
        "inherited": {"type": "boolean", "desc": "block comes from an ancestor"},
        "rand_vars": {"type": "array<string>", "desc": "constrained rand properties"},
        "solve_before": {"type": "array<object>",
                         "desc": "solve a before b nodes (before vars)"},
        "dist": {"type": "array<object>",
                 "desc": "dist weights text per expression constraint"},
    },
    "class_uvm": {
        "role": {"type": "string|null", "desc": "sequence|sequence_item|component|object|null"},
        "base_kind": {"type": "string|null", "desc": "matched UVM base class"},
        "is_uvm": {"type": "boolean", "desc": "has a UVM ancestor"},
        "factory_registration": {"type": "object|null", "desc": "registration macro/type/line"},
        "factory_creates": {"type": "array<object>", "desc": "type_id/create_by_name calls"},
        "sequence_calls": {"type": "array<object>", "desc": "uvm_do/start_item/finish_item"},
        "p_sequencer": {"type": "string|null", "desc": "uvm_declare_p_sequencer type"},
        "source": {"type": "object", "desc": "class source file/line"},
    },
    "class_covergroup": {
        "name": {"type": "string", "desc": "covergroup name"},
        "in_class": {"type": "string", "desc": "defining class"},
        "clock": {"type": "string", "desc": "sampling clock"},
        "coverpoints": {"type": "array<object>", "desc": "coverpoints with bins/bin_details"},
        "crosses": {"type": "array<object>", "desc": "cross objects with items/iff"},
        "instance_rule": {"type": "string", "desc": "ctor_new|uninstantiated|module_scope"},
        "file": {"type": "string", "desc": "source file"},
        "line": {"type": "integer", "desc": "source line"},
    },
    "coverpoint_ref": {
        "covergroup": {"type": "string", "desc": "covergroup name"},
        "coverpoint": {"type": "string", "desc": "coverpoint name"},
        "in_class": {"type": "string", "desc": "defining class"},
        "host_module": {"type": "string", "desc": "module host"},
        "ref_name": {"type": "string", "desc": "sampled reference"},
        "select": {"type": "string", "desc": "bit select"},
        "instance": {"type": "string", "desc": "class instance path"},
    },
    "covergroup_sampling": {
        "coverpoint": {"type": "string", "desc": "coverpoint name"},
        "signal_raw": {"type": "string", "desc": "raw sampled signal"},
        "sampled": {"type": "array<string>", "desc": "graph signal ids"},
        "drivers": {"type": "array<string>", "desc": "fanin drivers"},
        "missing": {"type": "array<string>", "desc": "unresolved refs"},
    },
    "covergroup_rand": {
        "covergroup": {"type": "string", "desc": "covergroup name"},
        "coverpoint": {"type": "string", "desc": "coverpoint name"},
        "property": {"type": "string", "desc": "sampled property id"},
        "constraints": {"type": "array<constraint_block>", "desc": "constraints on property"},
    },
    "class_relations": {
        "class": {"type": "string", "desc": "class name"},
        "extends": {"type": "string|null", "desc": "direct parent"},
        "ancestors": {"type": "array<string>", "desc": "parent chain"},
        "subclasses": {"type": "array<string>", "desc": "direct children"},
        "descendants": {"type": "array<string>", "desc": "all descendants"},
        "members": {"type": "array<class_member>", "desc": "type-level members"},
        "instances": {"type": "array<class_instance>", "desc": "class instances"},
        "member_instances": {"type": "array<class_member_instances>", "desc": "per-member instances"},
        "constraints": {"type": "array<class_constraint>", "desc": "graph constraint edges"},
        "constraint_blocks": {"type": "array<constraint_block>", "desc": "constraint block details"},
        "covergroups": {"type": "array<class_covergroup>", "desc": "covergroups owned by class/ancestors"},
        "uvm": "class_uvm",
        "methods": {"type": "array<class_method>", "desc": "method definitions + calls"},
    },
    "instance_item": {
        "full_path": {"type": "string", "desc": "instance path"},
        "name": {"type": "string", "desc": "instance name"},
        "module_type": {"type": "string", "desc": "module/interface type"},
        "parent": {"type": "string|null", "desc": "parent instance path"},
    },
    "instances_result": {
        "ok": {"type": "boolean", "desc": "query succeeded"},
        "count": {"type": "integer", "desc": "instance count"},
        "module": {"type": "string|null", "desc": "filter/detail instance path"},
        "instances": {"type": "array<instance_item>", "desc": "instance list"},
    },
    "hierarchy_node": {
        "full_path": {"type": "string", "desc": "instance path"},
        "module_type": {"type": "string|null", "desc": "module type; null for synthetic root"},
        "children": {"type": "array<hierarchy_node>", "desc": "child nodes"},
        "synthetic": {"type": "boolean", "desc": "synthetic root wrapper"},
    },
    "hierarchy_result": {
        "ok": {"type": "boolean", "desc": "query succeeded"},
        "root_count": {"type": "integer", "desc": "root count"},
        "instance_count": {"type": "integer", "desc": "non-root instances"},
        "tree_node_count": {"type": "integer", "desc": "tree nodes incl roots"},
        "root": {"type": "string|null", "desc": "requested root"},
        "depth": {"type": "integer|null", "desc": "requested depth"},
        "tree": {"type": "array<hierarchy_node>", "desc": "hierarchy tree"},
    },
    "port_item": {
        "port": {"type": "string", "desc": "port name"},
        "id": {"type": "string", "desc": "graph node id"},
        "direction": {"type": "string", "desc": "input/output/inout"},
        "width": {"type": "array", "desc": "[msb, lsb]"},
        "in_edges": {"type": "integer", "desc": "incoming edge count"},
        "out_edges": {"type": "integer", "desc": "outgoing edge count"},
    },
    "ports_result": {
        "ok": {"type": "boolean", "desc": "query succeeded"},
        "module": {"type": "string", "desc": "instance path"},
        "count": {"type": "integer", "desc": "port count"},
        "by_direction": {"type": "object", "desc": "direction -> count"},
        "ports": {"type": "array<port_item>", "desc": "port list"},
    },
    "param_item": {
        "name": {"type": "string", "desc": "parameter name"},
        "value": {"type": "string", "desc": "effective value"},
        "is_overridden": {"type": "boolean", "desc": "overridden at instantiation"},
        "is_local_param": {"type": "boolean", "desc": "localparam"},
    },
    "params_result": {
        "ok": {"type": "boolean", "desc": "query succeeded"},
        "instance": {"type": "string", "desc": "instance path"},
        "module_type": {"type": "string", "desc": "module type"},
        "count": {"type": "integer", "desc": "parameter count"},
        "parameters": {"type": "array<param_item>", "desc": "parameters"},
    },
    "connection_port": {
        "port": {"type": "string", "desc": "port name"},
        "direction": {"type": "string", "desc": "input/output/inout"},
        "width": {"type": "array", "desc": "[msb, lsb]"},
        "internal_signal": {"type": "string", "desc": "internal signal id"},
    },
    "connections_result": {
        "ok": {"type": "boolean", "desc": "query succeeded"},
        "resolved_as": {"type": "string", "desc": "instance|unknown"},
        "instance": {"type": "string", "desc": "instance path"},
        "module_type": {"type": "string", "desc": "module type"},
        "parent": {"type": "string|null", "desc": "parent instance"},
        "port_count": {"type": "integer", "desc": "connected port count"},
        "ports": {"type": "array<connection_port>", "desc": "port connections"},
    },
    "class_member": {
        "id": {"type": "string", "desc": "member node id"},
        "name": {"type": "string", "desc": "member name"},
        "kind": {"type": "string", "desc": "node kind"},
        "module": {"type": "string", "desc": "class/module path"},
        "width": {"type": "array", "desc": "[msb, lsb]"},
        "is_rand": {"type": "boolean", "desc": "rand/randc property"},
        "rand_mode": {"type": "string|null", "desc": "Rand|RandC|None"},
        "type": {"type": "string|null", "desc": "declared data type"},
    },
    "class_instance": {
        "id": {"type": "string", "desc": "instance node id"},
        "name": {"type": "string", "desc": "instance name"},
        "kind": {"type": "string", "desc": "node kind"},
        "module": {"type": "string", "desc": "module path"},
        "width": {"type": "array", "desc": "[msb, lsb]"},
    },
    "class_result": {
        "ok": {"type": "boolean", "desc": "query succeeded"},
        "count": {"type": "integer", "desc": "class or instance count"},
        "classes": {"type": "array<string>", "desc": "class names (no-name mode)"},
        "class": {"type": "string", "desc": "class name (detail mode)"},
        "member_count": {"type": "integer", "desc": "member count"},
        "members": {"type": "array<class_member>", "desc": "type-level members"},
        "instance_count": {"type": "integer", "desc": "instance count"},
        "instances": {"type": "array<class_instance>", "desc": "instance-level nodes"},
        "member": {"type": "string", "desc": "requested member (member mode)"},
        "candidate_count": {"type": "integer", "desc": "semantic member candidates"},
        "candidates": {"type": "array<class_member_candidate>", "desc": "all instance paths"},
        "note": {"type": "string", "desc": "member-mode note"},
        "relations": "class_relations",
    },
    "direct_error": {
        "ok": {"type": "boolean", "desc": "always false"},
        "error": {"type": "string", "desc": "error message"},
        "hint": {"type": "string", "desc": "recovery hint"},
        "path": {"type": "string", "desc": "requested path (instances/params)"},
        "target": {"type": "string", "desc": "requested target (connections)"},
        "resolved_as": {"type": "string", "desc": "connection target resolution kind"},
    },
    "manifest_entry": {
        "waveform_path": {"type": "string", "desc": "requested waveform path"},
        "index": {"type": "integer", "desc": "batch position"},
        "found": {"type": "boolean", "desc": "strict lookup succeeded"},
        "lookup": "lookup_path",
        "profile": "profile_signal",
        "error": {"type": "string", "desc": "profile error (optional)"},
    },
    "manifest_result": {
        "entries": {"type": "array<manifest_entry>", "desc": "per-path manifest"},
        "total": {"type": "integer", "desc": "requested paths"},
        "found": {"type": "integer", "desc": "resolved paths"},
        "failed": {"type": "integer", "desc": "unresolved paths"},
    },
    "lookup_path": {
        "requested": {"type": "string", "desc": "full waveform path as requested"},
        "found": {"type": "boolean", "desc": "strictly resolved to a graph node"},
        "canonical": {"type": "string|null", "desc": "canonical graph id"},
        "resolution": {"type": "string", "desc": "exact|alias|bit_parent|ambiguous|not_found"},
        "matched_via": {"type": "string|null", "desc": "exact|alias|bit_parent"},
        "bit_suffix": {"type": "string|null", "desc": "bit/part-select suffix for bit_parent"},
        "aliases": {"type": "array<string>", "desc": "port/internal aliases"},
        "suggestions": {"type": "array<string>", "desc": "not_found candidates"},
        "width": {"type": "array|null", "desc": "[msb,lsb]"},
        "kind": {"type": "string", "desc": "NodeKind name"},
        "module": {"type": "string", "desc": "module/instance path"},
    },
    "lookup_result": {
        "paths": {"type": "array<lookup_path>", "desc": "per-path lookups"},
        "total": {"type": "integer", "desc": "requested paths"},
        "found": {"type": "integer", "desc": "resolved paths"},
        "failed": {"type": "integer", "desc": "not_found paths"},
    },
    "edge_evidence": {
        "kind": {"type": "string", "desc": "edge kind"},
        "assign_type": {"type": "string", "desc": "continuous/always_ff/..."},
        "condition": {"type": "string", "desc": "edge condition (empty = unconditional)"},
        "expression": {"type": "string", "desc": "driver expression"},
        "file": {"type": "string|null", "desc": "edge source file"},
        "line": {"type": "integer|null", "desc": "edge source line"},
    },
    "scope_child": {
        "full_path": {"type": "string", "desc": "child instance path"},
        "name": {"type": "string", "desc": "child instance name"},
        "module_type": {"type": "string", "desc": "child module type"},
        "canonical_id": {"type": "string", "desc": "canonical child scope id"},
    },
    "scope_port": {
        "name": {"type": "string", "desc": "port name"},
        "direction": {"type": "string", "desc": "input/output/inout/unknown"},
        "width": {"type": "array|null", "desc": "[msb,lsb]"},
        "canonical_id": {"type": "string", "desc": "canonical port id"},
        "internal_signal": {"type": "string|null", "desc": "internal net id"},
    },
    "scope_param": {
        "name": {"type": "string", "desc": "parameter name"},
        "value": {"type": "string|null", "desc": "effective value"},
        "is_overridden": {"type": "boolean", "desc": "overridden at instantiation"},
        "is_local_param": {"type": "boolean", "desc": "localparam"},
    },
    "scope_signal": {
        "name": {"type": "string", "desc": "direct child signal/port name"},
        "canonical_id": {"type": "string", "desc": "canonical signal id"},
        "kind": {"type": "string", "desc": "NodeKind name"},
        "width": {"type": "array|null", "desc": "[msb,lsb]"},
        "is_port": {"type": "boolean", "desc": "port node"},
        "direction": {"type": "string", "desc": "input/output/inout or empty"},
    },
    "scope_result": {
        "scope": {"type": "string", "desc": "scope path"},
        "canonical_id": {"type": "string", "desc": "canonical scope id"},
        "kind": {"type": "string", "desc": "instance|generate|class"},
        "module_type": {"type": "string", "desc": "module/interface type"},
        "parent": {"type": "string|null", "desc": "parent scope"},
        "children": {"type": "array<scope_child>", "desc": "direct children"},
        "ports": {"type": "array<scope_port>", "desc": "ports + canonical ids"},
        "parameters": {"type": "array<scope_param>", "desc": "effective parameters"},
        "signals": {"type": "array<scope_signal>", "desc": "direct child signals"},
        "members": {"type": "array<class_member>", "desc": "class members (class scope)"},
        "instances": {"type": "array<class_instance>", "desc": "class instances (class scope)"},
    },
    "profile_clock": {
        "signal": {"type": "string", "desc": "CLOCK edge source"},
        "condition": {"type": "string", "desc": "clock edge condition"},
        "clock_domain": {"type": "string", "desc": "declared/derived domain"},
        "edge": {"type": "string|null", "desc": "posedge/negedge (from always block)"},
    },
    "profile_reset": {
        "signal": {"type": "string", "desc": "RESET edge source"},
        "condition": {"type": "string", "desc": "reset condition"},
        "edge": {"type": "string|null", "desc": "posedge/negedge (async reset)"},
        "async": {"type": "boolean", "desc": "reset appears in sensitivity list"},
        "active_low": {"type": "boolean|null", "desc": "active-low (condition/name)"},
    },
    "enum_value": {
        "name": {"type": "string", "desc": "enum member name"},
        "value": {"type": "string", "desc": "enum value literal"},
    },
    "packed_member": {
        "name": {"type": "string", "desc": "struct member name"},
        "width": {"type": "integer", "desc": "member bit width"},
        "offset": {"type": "integer", "desc": "LSB offset in aggregate"},
        "signed": {"type": "boolean", "desc": "member signedness"},
    },
    "profile_type": {
        "kind": {"type": "string", "desc": "NodeKind name"},
        "known": {"type": "boolean", "desc": "semantic type resolved? (false = kind only)"},
        "name": {"type": "string|null", "desc": "declared type name"},
        "canonical": {"type": "string|null", "desc": "canonical semantic type"},
        "is_enum": {"type": "boolean", "desc": "enum type"},
        "is_struct": {"type": "boolean", "desc": "packed struct"},
        "is_union": {"type": "boolean", "desc": "packed union"},
        "is_unpacked_array": {"type": "boolean", "desc": "unpacked array"},
        "is_packed_array": {"type": "boolean", "desc": "packed vector"},
        "is_array": {"type": "boolean", "desc": "unpacked/dynamic/assoc array"},
        "array_element": {"type": "string|null", "desc": "array element type"},
        "bit_width": {"type": "integer|null", "desc": "semantic bit width"},
        "is_signed": {"type": "boolean|null", "desc": "semantic signedness"},
        "member_of": {"type": "string|null", "desc": "parent struct type for member"},
        "member_offset": {"type": "integer|null", "desc": "member LSB offset"},
        "enum_values": {"type": "array<enum_value>", "desc": "enum members"},
        "packed_members": {"type": "array<packed_member>", "desc": "struct member layout"},
    },
    "profile_bit": {
        "bit_range": {"type": "string|null", "desc": "source bit range"},
        "parent": {"type": "string|null", "desc": "parent bus id"},
        "parent_bit_start": {"type": "integer|null", "desc": "bit offset start"},
        "parent_bit_end": {"type": "integer|null", "desc": "bit offset end"},
        "select": {"type": "string|null", "desc": "bit/part-select suffix"},
        "kind": {"type": "string|null", "desc": "bit|range|dynamic|null"},
        "offset": {"type": "integer|null", "desc": "LSB offset in parent"},
        "parent_width": {"type": "array|null", "desc": "parent [msb,lsb]"},
    },
    "profile_source": {
        "file": {"type": "string", "desc": "declaration file"},
        "line": {"type": "integer", "desc": "declaration line"},
        "declaration": {"type": "string", "desc": "file:line"},
        "driver": {"type": "object|null", "desc": "{file,line} of driver assignment"},
    },
    "profile_role": {
        "is_clock": {"type": "boolean", "desc": "clock role"},
        "is_reset": {"type": "boolean", "desc": "reset role"},
        "is_enable": {"type": "boolean", "desc": "enable role"},
        "is_port": {"type": "boolean", "desc": "port node"},
        "modport_dir": {"type": "string|null", "desc": "modport direction"},
    },
    "profile_sequential": {
        "is_sequential": {"type": "boolean", "desc": "clock/reset/nonblocking evidence"},
        "assign_types": {"type": "array<string>", "desc": "driver assign types"},
        "stage": {"type": "integer|null", "desc": "pipeline stage (null=unknown)"},
        "stage_known": {"type": "boolean", "desc": "stage computed?"},
        "stage_source": {"type": "string|null", "desc": "pipeline_detect|null"},
        "stage_unknown_reason": {"type": "string|null", "desc": "combinational|not_pipeline_reg|no_pipeline_detected|null"},
        "sample": {"type": "string|null", "desc": "sample edge, e.g. posedge top.clk"},
        "sample_unknown_reason": {"type": "string|null", "desc": "combinational|multi_clock|clock_edge_unknown|null"},
        "always": {"type": "object|null", "desc": "{file,line} enclosing always"},
    },
    "profile_signal": {
        "signal": {"type": "string", "desc": "requested signal"},
        "index": {"type": "integer", "desc": "batch position"},
        "resolved_signal": {"type": "string|null", "desc": "canonical graph id"},
        "resolution": {"type": "string", "desc": "exact|relative|bit_base_fallback|not_found|ambiguous|internal"},
        "aliases": {"type": "array<string>", "desc": "canonical/leaf/relative aliases"},
        "width": {"type": "array|null", "desc": "[msb,lsb]"},
        "is_signed": {"type": "boolean|null", "desc": "signedness (null unknown)"},
        "kind": {"type": "string", "desc": "NodeKind name"},
        "module": {"type": "string", "desc": "module/instance path"},
        "type": "profile_type",
        "bit": "profile_bit",
        "source": "profile_source",
        "role": "profile_role",
        "clock_domains": {"type": "array<string>", "desc": "unique clock domains"},
        "clocks": {"type": "array<profile_clock>", "desc": "CLOCK edges"},
        "resets": {"type": "array<profile_reset>", "desc": "RESET edges"},
        "sequential": "profile_sequential",
        "driver_count": {"type": "integer", "desc": "direct drivers"},
        "load_count": {"type": "integer", "desc": "direct loads"},
        "error": {"type": "string", "desc": "per-signal error (empty on success)"},
    },
    "profile_result": {
        "signals": {"type": "array<profile_signal>", "desc": "per-signal profiles"},
        "total_signals": {"type": "integer", "desc": "requested signals"},
        "failed_signals": {"type": "integer", "desc": "profile failures"},
    },
    "verify_check": {
        "check": {"type": "string", "desc": "reciprocity|bit_mapping|connection"},
        "status": {"type": "string", "enum": ["pass", "fail", "unknown"],
                   "desc": "pass/fail/unknown (insufficient metadata)"},
        "checked": {"type": "integer", "desc": "items checked"},
        "skipped": {"type": "integer", "desc": "unknown/insufficient metadata"},
        "violations": {"type": "array<object>", "desc": "violation records"},
        "truncated": {"type": "boolean", "desc": "sample cap reached"},
        "mode": {"type": "string", "desc": "signal|sample|full"},
        "excluded": {"type": "object", "desc": "non_signal/bit_like/constant counts"},
        "bit_select_checked": {"type": "integer", "desc": "bit/range selects checked"},
        "index_like": {"type": "integer", "desc": "array/dynamic element nodes skipped"},
        "coverage": {"type": "object", "desc": "scope/checked/excluded/bit_level_reciprocity/note"},
        "error": {"type": "string", "desc": "check unavailable reason"},
    },
    "verify_consistency_result": {
        "verified": {"type": "boolean", "desc": "all checks pass and none unknown"},
        "total_violations": {"type": "integer", "desc": "sum of check violations"},
        "unknown_checks": {"type": "array<string>", "desc": "checks that could not run"},
        "checks": {"type": "array<verify_check>", "desc": "per-check results"},
    },
    "structural_finding": {
        "id": {"type": "string", "desc": "stable finding id"},
        "check": {"type": "string", "desc": "symmetry.port_set"},
        "severity": {"type": "string", "desc": "warning|error"},
        "confidence": {"type": "string", "desc": "high|medium|low"},
        "message": {"type": "string", "desc": "human summary"},
        "seeds": {"type": "array<string>", "desc": "instance seeds"},
        "expected": {"type": "object", "desc": "expected structure"},
        "actual": {"type": "object", "desc": "actual deviation"},
        "evidence": {"type": "array<object>", "desc": "edge evidence"},
        "subgraph": {"type": "object", "desc": "seeds/depth/direction/edge_kinds"},
    },

    "structural_finding": {
        "id": {"type": "string", "desc": "stable finding id"},
        "check": {"type": "string", "desc": "symmetry.port_set"},
        "severity": {"type": "string", "desc": "warning|error"},
        "confidence": {"type": "string", "desc": "high|medium|low"},
        "message": {"type": "string", "desc": "human summary"},
        "seeds": {"type": "array<string>", "desc": "instance seeds"},
        "expected": {"type": "object", "desc": "expected structure"},
        "actual": {"type": "object", "desc": "actual deviation"},
        "evidence": {"type": "array<object>", "desc": "edge evidence"},
        "subgraph": {"type": "object", "desc": "seeds/depth/direction/edge_kinds"},
    },

    "verify_claim_result": {
        "claim": {"type": "object", "desc": "original claim object"},
        "status": {"type": "string", "enum": ["verified", "contradicted", "unknown"],
                   "desc": "claim verdict; unknown = insufficient evidence"},
        "reason": {"type": "string", "desc": "why status was chosen"},
        "evidence": {"type": "array<object>", "desc": "supporting graph evidence"},
        "counterevidence": {"type": "array<object>", "desc": "counterexamples"},
    },
    "precision_values": ["bit", "bus", "unknown"],
    "notes": (
        "null != false: cycles_detected=null means the analysis cap was hit. "
        "condition fields are display strings, not a normalized boolean AST. "
        "unknown/coarse_fallback are intentional downgrades, not failures."
    ),
}

# [P146] canonical command names are the agent-facing keys; aliases remain for
# older consumers that index json_contract.commands by `trace fanin`/`trace fanout`.
JSON_CONTRACT["commands"]["drivers"] = JSON_CONTRACT["commands"]["trace fanin"]
JSON_CONTRACT["commands"]["loads"] = JSON_CONTRACT["commands"]["trace fanout"]


BIT_PRECISION = {
    "schema_version": "1",
    "modes": {
        "one": "默认: 只为'一侧已有位节点'的连接补位桥；纯总线保持总线粒度",
        "full": "SVQ_BIT_BRIDGE=full: 纯总线连接也按同索引合成位节点（图更大）",
    },
    "precise_forms": [
        "explicit bit select/assignment (y[3], y[3]=a[7])",
        "slice (y[7:4]=a, y=a[7:4], offsets, slice-to-slice)",
        "register bit / always_ff bit assignment",
        "generate per-entry bit",
        "bus<->bus connection (one: one side already has bits; full: pure bus)",
        "direct copy assign y=a (source bit nodes exist)",
        "expressions: bitwise (& | ^ ~), add/sub/mul, constant shift, slice",
        "concatenation {a,b} (signal operands and literal segments)",
        "constants (sized N'b/o/d/h, unsized, concat literal; unsigned extension)",
        "signed literal/signal extension (sign bit vs zero extend)",
        "integer/int/byte/shortint/longint/time widths",
        "packed struct/union aggregate + member layout + member bit bridge",
        "static-indexed memory element bits (mem[1][3])",
    ],
    "coarse_forms": [
        "comparison / logical / reduction (all bits may participate)",
        "variable shift / dynamic part-select / dynamic memory index",
        "function/task return values",
        "deep packed members (o.inner.a) not materialized",
        "non-packed struct",
        "source bit node absent -> falls back to bus",
    ],
    "markers": {
        "node.precision": "bit | bus | constant",
        "signal.precision": "bit | bus | unknown",
        "signal.coarse_fallback": "true when a packed bit query mixes bit with bus/constant results; unpacked array elements are element-level (false)",
        "signal.dynamic_index": "true when runtime index (mem[i]) affects the query; propagated through data, conditions, clock/reset, dynamic writes -> precision=unknown",
        "signal.function_call": "true when the query passes through a function call (result or condition/clock; not inlined) -> precision=unknown",
        "signal.conditions": "edge/path conditions on the queried signal; deeper nodes get multi-path OR with per-path condition_paths",
        "signal.condition_truncated": "true when condition path enumeration hit caps (max 8 paths/depth 20/5000 expansions)",
        "signal.runtime_system_call": "true when the query passes through a runtime system call ($random/$urandom/...) -> precision=unknown",
    },
    "notes": "precision markers describe granularity, not a proof of bit-exact dependency; "
             "coarse_fallback=true means the answer should be downgraded to bus level.",
}


def to_json(*, include_exp: bool = False, recommended_only: bool = False) -> dict:
    """capabilities / 生成器共用的结构 (agent 的工具面真相源)。"""
    cmds = []
    for c in COMMANDS:
        lay = LAYERS[c.layer]
        if not lay.in_capabilities and not include_exp:
            continue
        if recommended_only and not c.recommended:
            continue
        cmds.append({
            "name": c.key,
            "planned_name": c.planned_name,
            "aliases": aliases_of(c.key),
            "layer": c.layer,
            "group": c.group,
            "mode": mode_of(c.key, c.layer),
            "kind": c.kind,
            "cost": c.cost,
            "json": c.json,
            "stateful": c.stateful,
            "readonly": lay.readonly,
            "stability": lay.stability,
            "schema_version": lay.schema_version,
            "recommended": c.recommended,
            "envelope": c.envelope,
            "write_scope": c.write_scope,
            "note": c.note,
        })
    return {
        "schema_version": "1",
        "layers": {
            n: {"consumer": l.consumer, "stability": l.stability,
                "readonly": l.readonly, "json_required": l.json_required,
                "schema_version": l.schema_version, "note": l.note}
            for n, l in LAYERS.items()
        },
        "core_groups": CORE_GROUPS,
        "counts": counts(),
        "planned_new": NEW_PLANNED,
        "bit_precision": BIT_PRECISION,
        "json_contract": JSON_CONTRACT,
        "commands": cmds,
    }


def walk_app(app) -> list[str]:
    """遍历 typer app, 返回所有叶子命令的现状路径 (如 "trace fanin")。"""
    import typer

    root = app if hasattr(app, "commands") else typer.main.get_command(app)
    out: list[str] = []

    def _walk(cmd, prefix: str) -> None:
        import click
        if isinstance(cmd, click.Group):
            for name, sub in cmd.commands.items():
                _walk(sub, f"{prefix}{name} ")
        else:
            out.append(prefix.strip())

    _walk(root, "")
    return sorted(out)
