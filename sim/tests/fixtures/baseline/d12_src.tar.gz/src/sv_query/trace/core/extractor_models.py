# ==============================================================================
# extractor_models.py - ExtractorResult 共享数据类 (P1 cycle 9 解决循环 import)
#
# 之前 ExtractorResult 在 graph_builder.py, DriverExtractor 在 driver_extractor.py
# 都定义一份. 循环 import 出现: graph_builder → driver_extractor → graph_builder
# (通过 ExtractorResult 引用).
#
# 修复: ExtractorResult 独立成文件, 所有 Extractor (Driver/Load/Connection/Clock)
# 从这里 import.
# ==============================================================================

from dataclasses import dataclass, field

from .graph.models import TraceEdge, TraceNode


@dataclass
class ExtractorResult:
    """提取器统一结果 - 5 个 Extractor 共享

    Attributes:
        nodes: 提取的 TraceNode 列表
        edges: 提取的 TraceEdge 列表
        errors: 错误信息
            e.g. 'top.u_dut.clk' → 'dut.clk'
    """
    nodes: list[TraceNode] = field(default_factory=list)
    edges: list[TraceEdge] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    # [REFACTOR 2026-08-07 A计划] 表达式树/常量/函数信息 — 全部从 semantic AST 构建，消灭 viz 层源码重读
    expr_trees: dict[str, dict] = field(default_factory=dict)   # {dst_key → tree_dict} (含多分支 max 合并)
    const_map: dict[str, list] = field(default_factory=dict)    # {dst_short → [const_str,...]} 从 expr_trees 树遍历提取
    func_info: dict[str, tuple | None] = field(default_factory=dict)  # {func_name → (msb,lsb)|None} 从 semantic function symbol 提取
    # [iter_129] interface 端口连接信息: (inst_path, port_name, interface_def_name,
    # members, parent_member_prefix) — graph_builder 后处理据此建成员级桥。
    # 例: writer u_w(.b(bf)) → ('top.u_w', 'b', 'bus_if', ['addr','data'], 'top.bf')
    interface_links: list[tuple] = field(default_factory=list)
