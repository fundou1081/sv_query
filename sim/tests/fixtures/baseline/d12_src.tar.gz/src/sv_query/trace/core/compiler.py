# ruff: noqa: E402
# ==============================================================================
# compiler.py - Semantic AST 编译入口
#
# 统一管理所有源文件的 Compilation 和 Semantic AST 获取
# 遵循铁律1: 必须使用 Semantic AST (Compilation + getRoot())
# ==============================================================================

import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

# [A1 + A3 2026-06-28] Global quiet flag for LLM-friendly output.
# When True, all diagnostic output (warnings, info, errors) goes to /dev/null.
# Without --quiet, all non-JSON output still goes to stderr (Unix convention).
_QUIET = False
# [ADD 2026-07-10] Global flag: 是否在本次 elaboration 中遇到内存压力 (SWAP > 2GB).
#   anomaly 检测应该读这个 flag, 如果为 True, 把 anomalies 标为 "low confidence" (可能是误报)。
_ELABORATION_INCOMPLETE = False


def is_quiet() -> bool:
    """[iter_202] 查询 quiet 模式 (供诊断性 stderr 输出自行门控)。

    背景: `--quiet` 的契约是"抑制所有 stderr 输出"(给 LLM 消费方), 但实测
    `visualize pipeline --quiet` 仍会泄漏 Phase 3/4 进度与 pipeline 摘要 6 行
    (iter_202 对抗测试发现) → 这些点必须自己查 quiet 状态。
    """
    return _QUIET


def set_quiet(quiet: bool = True) -> None:
    """Set global quiet mode for LLM consumption.

    When quiet=True, all diagnostic messages (SWAP warning, INFO logs,
    ERROR messages) are suppressed. JSON output via stdout is unaffected.

    Usage:
        from sv_query.trace.core.compiler import set_quiet
        set_quiet(True)  # suppress all stderr noise
    """
    global _QUIET
    _QUIET = quiet

# [iter_186] pyslang bindings 覆盖路径 (仅当**存在**时才插入 sys.path)。
# 原实现把开发机绝对路径无条件插进 sys.path — 该目录在正常安装环境并不存在,
# 属于死路径 + 个人路径硬编码 (换机器/开源环境会误导排查)。只有当用户自己
# clone 了 slang 并构建了 bindings 时才生效。
PYSLLANG_BINDINGS_PATH = os.path.expanduser("~/my_dv_proj/slang/build/bindings")
if os.path.isdir(PYSLLANG_BINDINGS_PATH) and PYSLLANG_BINDINGS_PATH not in sys.path:
    sys.path.insert(0, PYSLLANG_BINDINGS_PATH)

# UVM 源码路径 (自动检测)
DEFAULT_UVM_SRC = None
for candidate in [
    os.path.expanduser("~/my_dv_proj/openrtl/uvm-1.2/src"),
    os.path.expanduser("~/uvm-1.2/src"),
    "/usr/local/uvm-1.2/src",
]:
    if os.path.isfile(os.path.join(candidate, "uvm_pkg.sv")):
        DEFAULT_UVM_SRC = candidate
        break

import pyslang
from pyslang import DiagnosticEngine


class CompilationError(Exception):
    """编译错误异常；显式分类供 CLI/agent 区分 filelist 与 elaboration。"""

    def __init__(self, message: str, error_code: str = "E_ELABORATION_FAILED",
                 errors: list[dict] | None = None):
        super().__init__(message)
        self.error_code = error_code
        # structured diagnostics (file/line/column/code/message), when available
        self.errors = list(errors or [])


# ---------------------------------------------------------------------------
# 内存检测
# ---------------------------------------------------------------------------

def is_elaboration_incomplete() -> bool:
    """[ADD 2026-07-10] 方豆 feedback: elaboration 不完整时 anomaly 检测不可信.

    Returns True if the last compilation encountered memory pressure (SWAP > 2GB).
    In that case, the SignalGraph is likely missing edges due to OOM, and any
    "anomaly" detected (X_DRIVER, DANGLING) is probably a false positive.

    Use this to add a "low confidence" warning to anomaly reports.
    """
    return _ELABORATION_INCOMPLETE


def _check_memory_pressure():
    """检测系统内存压力, 如果不足输出告警.

    pyslang elaboration 在内存不足时静默失败:
      - 不报错, 不抛异常
      - 返回部分 AST (缺 module, 缺 port)
      - 部分对象 name 变为 binary garbage

    这个函数检测 swap 使用情况, 如果超过阈值就 warn.
    """
    import sys as _sys
    if _QUIET:  # [A3 2026-06-28] quiet 模式下不输出任何警告
        return
    try:
        import resource
        # 检查进程级 RSS (实际物理内存使用)，不是系统级 swap 总量
        # macOS 系统 swap 是预分配的全局值，跟 sv_query 进程无关
        rss_mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0 / 1024.0  # macOS: bytes→GiB→MB
        if rss_mb > 1536:  # > 1.5GB 进程实际内存
            global _ELABORATION_INCOMPLETE
            _ELABORATION_INCOMPLETE = True
            print(
                f"[sv_query] ⚠️  进程内存 {rss_mb:.0f}MB (高负载, 可能影响 elaboration)",
                file=_sys.stderr,
            )
            print(
                "[sv_query] → pyslang 在内存不足时**不会报错**, 但 elaboration",
                file=_sys.stderr,
            )
            print(
                "           可能不完整 (缺 module, binary 名字)。",
                file=_sys.stderr,
            )
            print(
                "           建议: (1) 关闭浏览器/IDE 释放内存。",
                file=_sys.stderr,
            )
            print(
                "                 (2) 用更小 filelist 按模块逐个分析。",
                file=_sys.stderr,
            )
            print(
                "                 (3) 在 16GB+ RAM 的机器上重跑。",
                file=_sys.stderr,
            )
    except Exception as e:
        logger.debug("%s: 忽略 Exception: %s", __name__, e)  # 检测失败不影响正常编译


def _reject_non_design_unit(tree: object, fname: str, source: str = "") -> None:
    """[iter_189] 拒绝"非设计单元"的语法树 — 否则 pyslang 会**原生崩溃**。

    pyslang/slang 的 `Compilation.addSyntaxTree()` 在语法树根节点是**表达式**时
    `SIGTRAP` (无输出、无异常、Python 侧无法捕获)。触发条件 (实测): 输入文本不是
    SystemVerilog 设计单元时, slang 走 script 模式把它解析成一个表达式, 例如把
    **filelist 当源码传进来**:

        content "/path/to/mod.sv\\n"  → 根节点 SyntaxKind.DivideExpression → trap
        content "1 + 2"              → 根节点 SyntaxKind.AddExpression    → trap

    合法输入 (实测) 的根节点是:`CompilationUnit` (多成员文件/空文件/仅注释/
    仅 `define`)、`ModuleDeclaration` (单 module 文件)、`ClassDeclaration` 等
    单个设计单元。因此这里只拒绝**表达式根** (范围最小, 不误伤设计单元),
    并抛出可行动的 `CompilationError` (而不是让进程被信号打死)。

    最小复现 (纯 pyslang, 不需要本项目代码):
        tree = pyslang.syntax.SyntaxTree.fromText(open("filelist.f").read(), name="x.sv")
        comp.addSyntaxTree(tree)   # ← SIGTRAP (exit 133)
    """
    try:
        kind = str(getattr(getattr(tree, "root", None), "kind", ""))
    except (UnicodeDecodeError, TypeError):
        return  # 读不出 kind 就不在这里判断 (后续 addSyntaxTree 自己会报错)
    if "Expression" in kind:
        raise CompilationError(
            f"{fname}: 解析结果的根节点是 {kind} (SystemVerilog 表达式), 不是设计"
            f"单元 — pyslang 在此情况会原生 SIGTRAP (addSyntaxTree)。"
            f"常见原因: 把 filelist/文本文件当源码传入 (请用 --filelist 传 .f)。",
            error_code="E_FILELIST_INVALID",
        )

    # [iter_209 R4-1] filelist 内容识别: 非 .f 扩展名的 filelist 经 `-f` 传入时,
    # CLI 的"后缀提升"不生效 → 被当源码解析 → 用户只看到下游 elaboration 错误。
    # 判据 (最小, 两条经验教训): ① 扫描**前若干有效行**而非只看首行 —— 预处理器
    # 会在文件顶部注入 `` `timescale ``; ② "裸路径"必须是**无空白且无分号**,
    # 否则 `endmodule // top.v` 这类行尾注释会被误判 (iter_208 实测误报)。
    _MARKERS = ("+incdir+", "+define+", "+libext+", "-f ", "-F ", "-y ", "-v ")
    checked = 0
    for raw in source.splitlines():
        line = raw.strip()
        if not line or line.startswith(("//", "#", "`")):
            continue                      # 空 / 注释 / 编译器指令 (`timescale 等)
        checked += 1
        _is_bare_path = (
            not any(ch.isspace() for ch in line)
            and ";" not in line
            and line.endswith((".sv", ".svh", ".v", ".f", ".fl", ".filelist"))
        )
        if line.startswith(_MARKERS) or _is_bare_path:
            raise CompilationError(
                f"{fname}: 内容看起来是 filelist (特征行 {line[:60]!r}), "
                f"不是 SystemVerilog 源码 — 请用 --filelist 传入该文件",
                error_code="E_FILELIST_INVALID",
            )
        if checked >= 20:
            break


class SVCompiler:
    """
    SystemVerilog 编译器 - 提供 Semantic AST 访问

    使用方式:
        compiler = SVCompiler({'module.sv': 'module ...'})
        root = compiler.get_root()  # Semantic AST root
        comp = compiler.get_compilation()  # Compilation 对象
    """

    def __init__(self, sources: dict[str, str] | None = None, log_level: str = "WARNING",
                 top_modules: list[str] | None = None):
        """
        初始化编译器

        Args:
            sources: {filename: source_code} 字典
            log_level: 诊断输出级别 (DEBUG/INFO/WARNING/ERROR/NONE)
            top_modules: [iter_145] 指定 top module 列表 → pyslang options.topModules,
                    只 elaborate 这些 top 的实例树。None (默认) = 现状: pyslang 预
                    elaborate 所有 free-floating 模块 — 含 type-param (axi_req_t =
                    logic) 成员访问的 free-floating 会报 InvalidMemberAccess (CVA6
                    cvxif / axi_demux 同款, iter_140/145)。设 top 后 free-floating
                    被忽略 — 是 "库 filelist + 显式 top" 场景 (benchmark/CVA6) 的正解。
        """
        self._sources = sources or {}
        self._comp: pyslang.Compilation | None = None
        # [iter_185] SourceManager 必须活到 Compilation 生命周期结束 — 它持有
        # 所有源文件 buffer, 而符号名/ token 文本都是指向 buffer 的 string_view。
        # 只在 parse 循环里持有局部变量 = 循环结束后 manager 被 GC → buffer 释放
        # → 符号名变成释放内存的垃圾字节 (iter_185 最小复现: 症状是随机的
        # UnicodeDecodeError / 乱码 instance 名 / partial elaboration)。
        self._source_manager: pyslang.SourceManager | None = None
        # [iter_185] 同理: options.topModules/paramOverrides 是 slang 侧的
        # string_view 容器, view 指向 Python str 的 buffer — 必须保证 str 活到
        # Compilation 生命周期结束。
        self._param_overrides: list[str] = []
        self._root = None
        self._diagnostics = []
        self._elaboration_errors = []  # [FIX 2026-06-11 Issue 17] 存解析出的错误, 供 UnifiedTracer / snapshot 读取
        self._log_level = self._parse_log_level(log_level)
        self._include_dirs: list[str] = []  # [铁律1] include 搜索路径
        self._top_modules = list(top_modules) if top_modules else None  # [iter_145]
        # [iter_140] paramOverride orphan 假错重试计数 (见 _do_compile)
        self._override_orphan_retry = 0
        # [iter_140] 已确认 drop 的 override 模块 (重建时不再注入, 避免假错循环)
        self._override_orphan_modules: set[str] = set()

    def _parse_log_level(self, level: str) -> int:
        """将日志级别字符串转换为 logging 常量"""
        level_map = {
            "DEBUG": 10,
            "INFO": 20,
            "WARNING": 30,
            "ERROR": 40,
            "NONE": 100,
        }
        return level_map.get(level.upper(), 30)

    def _log(self, level: str, msg: str):
        """内部日志输出. [A1 2026-06-28] 全部走 stderr (LLM-friendly)."""
        if _QUIET:
            return
        level_val = self._parse_log_level(level)
        if level_val >= self._log_level:
            # [A1 fix 2026-06-28] 所有 level 都走 stderr, 避免污染 stdout JSON
            print(f"[{level}] {msg}", file=sys.stderr)

    def add_source(self, filename: str, source: str) -> None:
        """添加源文件"""
        self._sources[filename] = source
        self._comp = None  # 需要重新编译

    def add_sources(self, sources: dict[str, str]) -> None:
        """批量添加源文件"""
        self._sources.update(sources)
        self._comp = None

    def add_include_dir(self, dir_path: str) -> None:
        """添加 include 搜索路径 [铁律1]"""
        if dir_path not in self._include_dirs:
            self._include_dirs.append(dir_path)
            self._comp = None

    def add_include_dirs(self, dir_paths: list[str]) -> None:
        """批量添加 include 搜索路径"""
        for d in dir_paths:
            self.add_include_dir(d)

    def add_files(self, file_paths: list[str]) -> None:
        """添加文件列表

        Args:
            file_paths: SV 源文件路径列表
        """
        for path in file_paths:
            with open(path, encoding="utf-8", errors="replace") as f:
                self._sources[os.path.basename(path)] = f.read()
        self._comp = None

    def add_filelist(self, filelist_path: str, env: dict[str, str] | None = None,
                     already_loaded: set | None = None,
                     missing_entries: list | None = None) -> None:
        """从 filelist 加载源文件 (解析统一走 `sv_query.trace.core.filelist.parse_filelist`)。

        [iter_193] 本方法过去自带一套解析实现 (与 `cli._common._read_filelist`
        规则不一致: 相对路径基准/嵌套解析不同) → 现在只做**应用**:
          - `+incdir+` → `add_include_dir`
          - 文件 → `add_files`
          - 缺失条目 → 汇总告警 (调用方也可通过 missing_entries 取走)

        支持语法与相对路径候选规则见 `trace/core/filelist.py` 模块文档。
        """
        from .filelist import parse_filelist

        spec = parse_filelist(filelist_path, base_dirs=[Path.cwd()],
                              env=env, already_loaded=already_loaded)
        # [iter_194] filelist 一个文件都没解析出来 → 明确报错 (过去是静默编译出空图 /
        # 报一个与根因无关的下游错误)。这不是 fallback: 只是把"输入无效"讲清楚。
        if not spec.files:
            raise CompilationError(
                f"filelist {filelist_path} 没有解析到任何源文件 "
                f"({len(spec.missing)} 个条目缺失/不可解析) — 请检查路径与基准目录",
                error_code="E_FILELIST_INCOMPLETE",
            )
        for d in spec.include_dirs:
            # 一个 +incdir+ 行可能含逗号分隔的多目录 (parse_filelist 已展开为逗号串)
            for one in d.split(","):
                if one:
                    self.add_include_dir(one)
        for f in spec.files:
            self.add_files([f])
        spec.warn_missing(filelist_path)
        if missing_entries is not None:
            missing_entries.extend(spec.missing)
        self._comp = None

    def _expand_env(self, text: str, env: dict[str, str]) -> str:
        """展开 ${VAR} 或 $VAR 形式的环境变量"""
        import re

        # 先展开 ${VAR} 形式
        def replace_braced(match: object) -> str:
            var = match.group(1)
            return env.get(var, match.group(0))

        text = re.sub(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", replace_braced, text)

        # 再展开 $VAR 形式（避免匹配 $xxxx 中的 $xxxx 是普通字符）
        def replace_simple(match: object) -> str:
            var = match.group(1)
            return env.get(var, match.group(0))

        text = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)", replace_simple, text)
        return text

    def _do_compile(self):
        """执行编译 [铁律1] 使用 Semantic AST"""
        if self._comp is not None:
            return

        self._comp = pyslang.Compilation()
        # [iter_145] 显式 top: 只 elaborate 指定 top 的实例树, free-floating
        # (未被实例化) 模块忽略 — 避免 type-param free-floating 预 elab
        # InvalidMemberAccess (CVA6 cvxif / axi_demux 同款)
        if self._top_modules:
            self._comp.options.topModules = set(self._top_modules)
        # [PR1 2026-06-14] 提高 generate loop step 限制 (默认 64 不够 lzc/rr_arb_tree)
        # lzc.sv 用 `for (level = 0; level < NumLevels; level++)` 加嵌套循环
        # NumLevels = 2**WIDTH, lzc WIDTH 默认 2 → 4 levels, 但 lzc 还嵌套 g_index_lut
        # 总步数 = 2 * 4 * 2 = 16 阶 → 超过默认 64 (应该是嵌套 deep 触发)
        self._comp.options.maxGenerateSteps = 1024 * 1024
        # [PR1 2026-06-14] 这些限制是 default, 增至 4M 避免模块多时触发
        self._comp.options.maxInstanceArray = 1024 * 1024
        self._comp.options.maxInstanceDepth = 1024 * 1024

        # [PR1 2026-06-14] 为 pulp axi typedef interface modules 设默认 param
        # axi_mux_intf/axi_id_remap/id_queue 默认所有 param=0 → $clog2(0) / lzc 触发 MaxGenerateStepsExceeded
        # pyslang 会预 elabor 所有 top-level modules, 所以必须设默认值
        # 注: 这些值只用于 free-floating elaboration, 实际实例化时会被覆盖
        # 注意: paramOverrides 必须重新赋值 (extend 不生效)
        # 格式: 'MODULE.PARAM=VALUE', 用 defparam 语法
        # 只在源文件包含对应模块时才设 (避免 UndeclaredIdentifier 误报)
        _has_axi_mux_intf = any('axi_mux.sv' in f for f in self._sources.keys())
        _has_id_queue = any('id_queue.sv' in f for f in self._sources.keys())
        _overrides = []
        if _has_axi_mux_intf:
            _overrides.extend([
                'axi_mux_intf.SLV_AXI_ID_WIDTH=4',
                'axi_mux_intf.MST_AXI_ID_WIDTH=4',
                'axi_mux_intf.AXI_ADDR_WIDTH=32',
                'axi_mux_intf.AXI_DATA_WIDTH=64',
                'axi_mux_intf.AXI_USER_WIDTH=0',
                'axi_mux_intf.NO_SLV_PORTS=2',
            ])
        if _has_id_queue:
            # CAPACITY=0 触发 HtCapacity=$clog2(0) → lzc WIDTH=0 → infinite loop
            _overrides.extend([
                'id_queue.ID_WIDTH=4',
                'id_queue.CAPACITY=4',
            ])
        # 注: rr_arb_tree 在全集上下文被 pyslang drop, override 会 CouldNotResolveHierarchicalPath
        # pre-elab 错误不影响实际 elaboration (使用 axi_demux_simple 的实际实例), 跳过
        # stream_arbiter/stream_arbiter_flushable N_INP=-1 → $clog2(-1) 错误
        if any('stream_arbiter.sv' in f for f in self._sources.keys()):
            _overrides.append('stream_arbiter.N_INP=4')
        if _overrides:
            # [iter_140] 排除已确认 drop 的 override 模块 (free-floating pre-elab
            # 被 pyslang drop, override 指向它只会产生 CouldNotResolveHierarchicalPath 假错)
            if self._override_orphan_modules:
                _overrides = [o for o in _overrides
                              if o.split('.', 1)[0] not in self._override_orphan_modules]
            # [iter_185] slang 侧 `paramOverrides` 是 `vector<string_view>` — view
            # 指向 Python str 的 buffer。当前全是字面量 (常驻, 不会死), 但持有
            # 一份引用 = 未来动态拼 override 时不会变成悬垂 view (同类事故见
            # iter_185 SourceManager 生命周期)。
            self._param_overrides = list(_overrides)
            self._comp.options.paramOverrides = self._comp.options.paramOverrides + _overrides

        # 设置 include 搜索路径
        sm = None
        include_dirs = list(self._include_dirs)

        # 检测是否需要 UVM (源码中有 uvm_pkg 或 uvm_ 相关引用)
        needs_uvm = False
        for source in self._sources.values():
            if "uvm_pkg" in source or "uvm_sequence" in source or "uvm_driver" in source:
                needs_uvm = True
                break

        if needs_uvm and DEFAULT_UVM_SRC and DEFAULT_UVM_SRC not in include_dirs:
            include_dirs.append(DEFAULT_UVM_SRC)

        if include_dirs:
            sm = pyslang.SourceManager()
            for d in include_dirs:
                sm.addUserDirectories(d)
            # [iter_185] 关键: 把 manager 的所有权交给 compiler (见 __init__ 注释)。
            # pyslang 的 py::keep_alive<0,2> 只保证 "tree wrapper 活着时 manager 活着",
            # 而下面的 `tree` 是循环内局部变量 (C++ 侧 Compilation 持有 shared_ptr
            # <SyntaxTree>, tree 对象的 C++ 落点存活, 但 Python wrapper 每轮被回收)
            # → 不显式持有 manager, buffer 会在 parse 循环结束后被释放。
            self._source_manager = sm

        for fname, source in self._sources.items():
            try:
                if sm:
                    tree = pyslang.SyntaxTree.fromText(source, sourceManager=sm, name=fname)
                else:
                    tree = pyslang.SyntaxTree.fromText(source, fname)
                _reject_non_design_unit(tree, fname, source)  # [iter_189/209]
                self._comp.addSyntaxTree(tree)
            except CompilationError:
                raise
            except Exception as e:
                raise CompilationError(f"Failed to parse {fname}: {e}") from None

        # 触发 elaboration
        self._diagnostics = self._comp.getSemanticDiagnostics()

        # 输出所有诊断信息
        self._report_diagnostics()

        # 检查错误
        errors = [d for d in self._diagnostics if d.isError()]
        if errors:
            report = DiagnosticEngine.reportAll(self._comp.sourceManager, errors)
            # [FIX 2026-06-11 Issue 17] 把 elaboration 错误存到 self._elaboration_errors
            # 供 UnifiedTracer / snapshot 读取, 标记哪些文件失败
            self._elaboration_errors = self._format_elaboration_errors(errors)
            # [iter_224] 恒定严格: 已删除 "非严格模式返回 partial AST" 的降级分支
            # (过去 strict=False 会打一行后继续, 让上层拿到残缺 AST 却以为成功)
            # [iter_140] paramOverride orphan 假错重试: pyslang 对 free-floating
            # (未被实例化) 参数化模块用默认参数 pre-elab; 某模块在全集上下文被
            # drop (实例化处都带真实参数, 如 CVA6 stream_arbiter) 时, paramOverride
            # 指向它 → <command-line> 位置 CouldNotResolveHierarchicalPath。
            # override 仅为 pre-elab 默认值兜底 (见 _do_compile 中 pulp axi 注释),
            # 模块被 drop = override 无用, 此错无害 (真实实例自带参数) —
            # 恒定严格下也不应 fatal。识别: 全部错误都来自 <command-line> 且
            # identifier 匹配某 override 模块 → 移除该 override 重建重编 (限次)。
            if self._try_retry_override_orphan(errors):
                return
            raise CompilationError(
                f"Elaboration errors:\n{report}",
                errors=self._elaboration_errors,
            ) from None
        else:
            self._elaboration_errors = []

        # 获取 Semantic AST root
        self._root = self._comp.getRoot()

        # [PR1 2026-06-14] 内存不足检测: 8GB 机器上 pyslang elaboration 会因
        # swap 压力静默失败 (返回不完整 AST, 但无报错).
        # 在发现这种情况时输出告警, 提示用户关闭内存占用大的程序.
        _check_memory_pressure()

    def _report_diagnostics(self):
        """输出所有诊断信息（按级别）"""
        if not self._diagnostics:
            self._log("DEBUG", "No diagnostics")
            return

        # 按严重程度分组 (pyslang 只支持 isError)
        errors = [d for d in self._diagnostics if d.isError()]
        others = [d for d in self._diagnostics if not d.isError()]

        if errors:
            self._log("ERROR", f"{len(errors)} error(s) found")
            for d in errors:
                self._log("ERROR", self._format_diagnostic(d))
        if others:
            self._log("WARNING", f"{len(others)} warning(s)/note(s) found")
            for d in others:
                self._log("WARNING", self._format_diagnostic(d))

    def get_elaboration_errors(self) -> list[dict]:
        """[FIX 2026-06-11 Issue 17] 公开 API: 返回 elaboration 错误列表

        Returns:
            list of dict: [
                {
                    "file": "src/foo.sv",  # 源文件相对名
                    "line": 42,
                    "column": 8,
                    "code": "UndeclaredIdentifier",
                    "message": "use of undeclared identifier 'foo'",
                },
                ...
            ]
        """
        return list(self._elaboration_errors)

    def _try_retry_override_orphan(self, errors: list) -> bool:
        """[iter_140] paramOverride orphan 假错 → 移除对应 override 重建重编.

        识别: 所有 error 都来自 '<command-line>' (paramOverride 注入点) 且
        identifier 匹配某个 paramOverrides 的模块前缀。此时 pyslang 因该
        override 模块在 free-floating pre-elab 被 drop 而报假错 — override
        仅兜底 pre-elab 默认参数, 真实实例自带参数, 移除无害。
        """
        if self._override_orphan_retry >= 4:
            return False
        fmt = self._format_elaboration_errors(errors)
        cmdline_only = bool(fmt) and all(
            (er.get('file') or '').startswith('<command-line>') for er in fmt
        )
        if not cmdline_only:
            return False
        overrides = list(getattr(self._comp.options, 'paramOverrides', None) or [])
        if not overrides:
            return False
        # override 模块前缀: 'MODULE.PARAM=VALUE' → 'MODULE'
        override_mods = {o.split('.', 1)[0] for o in overrides if '.' in o}
        orphans = {er.get('identifier') for er in fmt} & override_mods
        if not orphans:
            return False
        self._override_orphan_modules |= orphans
        logger.debug("paramOverride orphan 假错 (%s): 跳过这些 override 模块, 重试", sorted(orphans))
        self._override_orphan_retry += 1
        # 重建编译单元: 置 None 让 _do_compile 重建 (若新建 Compilation() 非 None,
        # _do_compile 开头 `if self._comp is not None: return` 会直接返回 →
        # 0 SyntaxTree 空编译, getRoot=None)
        self._comp = None
        self._root = None
        # [iter_185] 旧 compilation 的 SourceManager 一并释放 (新的一次编译会
        # 在 _do_compile 里重新持有) — 否则旧 buffer 白占内存。
        self._source_manager = None
        self._diagnostics = []
        self._elaboration_errors = []
        self._do_compile()
        return True

    def _format_elaboration_errors(self, errors: list) -> list[dict]:
        """[FIX 2026-06-11 Issue 17] 把 pyslang 诊断转结构化 dict

        pyslang v3 API: loc 是 SourceLocation, .buffer (BufferID) + .offset.
        文件名走 sm.getFileName(loc), 行/列走 sm.getLineNumber(loc)/getColumnNumber(loc).
        """
        out = []
        sm = getattr(self._comp, "sourceManager", None)
        for d in errors:
            loc = getattr(d, "location", None)
            line = col = 0
            fname = ""
            if loc is not None and sm is not None:
                # pyslang v3 getFileName 接受 SourceLocation, 不是 BufferID
                try:
                    fname = sm.getFileName(loc) or ""
                except Exception as e:
                    logger.debug("getFileName 失败: %s", e)
                if not fname:
                    try:
                        fname = sm.getRawFileName(loc) or ""
                    except Exception as e:
                        logger.debug("getRawFileName 失败: %s", e)
                # 行号 / 列号
                try:
                    line = sm.getLineNumber(loc) or 0
                except Exception as e:
                    logger.debug("getLineNumber 失败: %s", e)
                try:
                    col = sm.getColumnNumber(loc) or 0
                except Exception as e:
                    logger.debug("getColumnNumber 失败: %s", e)
            code = getattr(d, "code", None)
            code_str = str(code) if code else "unknown"
            # 提取代码名: "DiagCode(UndeclaredIdentifier)" -> "UndeclaredIdentifier"
            if "(" in code_str and code_str.endswith(")"):
                code_str = code_str.split("(", 1)[1].rstrip(")")
            # [ADD 2026-06-12 Req-18] 从 diag.args 抽未定义名 (e.g. ['undefined_typedef'])
            # 让 fix imports 等工具能精准定位该补哪个 typedef/module
            args = getattr(d, "args", []) or []
            identifier = None
            if args and isinstance(args[0], str):
                identifier = args[0]
            out.append({
                "file": fname,
                "line": line,
                "column": col,
                "code": code_str,
                "message": self._format_diagnostic(d).strip(),
                "identifier": identifier,  # 未定义的标识符名 (e.g. 'service_message_t')
            })
        return out

    def _format_diagnostic(self, diag) -> str:
        """格式化单个诊断信息

        输出格式: <file>:<line>:<col>: [<code>] <message>
        其中 file/line/col 从 diag.location 抽, code 从 diag.code 抽, message 走 DiagCode.formatted.
        """
        args = getattr(diag, "args", [])
        code = getattr(diag, "code", None)
        code_str = str(code) if code else "unknown"
        # 提取代码名称: "DiagCode(WidthExpand)" -> "WidthExpand"
        if "DiagCode(" in code_str:
            code_name = code_str.split("(")[1].rstrip(")")
        else:
            code_name = code_str

        # [FIX 2026-06-11 Req-10] 从 diag.location 抽 file:line:col
        loc = getattr(diag, "location", None)
        loc_str = ""
        if loc is not None and self._comp is not None:
            try:
                sm = self._comp.sourceManager
                fname = sm.getFileName(loc) or sm.getRawFileName(loc) or ""
                line = sm.getLineNumber(loc) or 0
                col = sm.getColumnNumber(loc) or 0
                if fname:
                    loc_str = f"{fname}:{line}:{col}: "
            except Exception as e:
                logger.debug("source_location 组装失败: %s", e)
        if not loc_str and len(args) >= 2:
            # 回退: 从 args 拿 line/col
            loc_str = f"{args[0]}:{args[1]}: "

        return f"{loc_str}[{code_name}]"

    def get_diagnostic_report(self) -> str:
        """获取格式化的完整诊断报告"""
        if not self._diagnostics:
            return "No diagnostics"

        lines = []
        for d in self._diagnostics:
            level = "ERROR" if d.isError() else "WARNING" if d.isWarning() else "INFO"
            lines.append(f"[{level}] {self._format_diagnostic(d)}")
        return "\n".join(lines)

    def get_compilation(self) -> pyslang.Compilation:
        """获取 Compilation 对象"""
        self._do_compile()
        return self._comp

    def get_root(self) -> object:
        """获取 Semantic AST root"""
        self._do_compile()
        return self._root

    def get_diagnostics(self) -> list:
        """获取诊断信息"""
        self._do_compile()
        return self._diagnostics

    @property
    def sources(self) -> dict[str, str]:
        """获取源文件字典"""
        return self._sources.copy()


# ==============================================================================
# 便捷函数
# ==============================================================================


def compile_sources(sources: dict[str, str]) -> tuple[pyslang.Compilation, any]:
    """
    编译源文件并返回 (Compilation, Semantic AST root)

    Args:
        sources: {filename: source_code}

    Returns:
        (Compilation, root) 元组

    Example:
        >>> comp, root = compile_sources({'test.sv': 'module test(); endmodule'})
        >>> root.kind  # Semantic AST 节点
    """
    compiler = SVCompiler(sources)
    return compiler.get_compilation(), compiler.get_root()


# ==============================================================================
# 测试
# ==============================================================================

if __name__ == "__main__":
    # 测试代码
    test_source = """
module test (
    input wire clk,
    input wire rst_n,
    input wire [7:0] data_in,
    output reg [7:0] data_out
);
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            data_out <= 8'b0;
        else
            data_out <= data_in;
    end
endmodule
"""

    print("=== SVCompiler 测试 ===")

    try:
        compiler = SVCompiler({"test.sv": test_source})
        comp = compiler.get_compilation()
        root = compiler.get_root()

        print("✅ Compilation 成功")
        print(f"✅ Root 类型: {type(root).__name__}")
        print(f"✅ Root kind: {root.kind}")

        # 测试遍历 Semantic AST 节点
        nodes = []
        root.visit(lambda n: nodes.append(type(n).__name__) if n else None)

        print(f"✅ 遍历到 {len(nodes)} 个节点")
        print(f"   节点类型: {set(nodes)}")

    except CompilationError as e:
        print(f"❌ 编译错误: {e}")
    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback

        traceback.print_exc()
