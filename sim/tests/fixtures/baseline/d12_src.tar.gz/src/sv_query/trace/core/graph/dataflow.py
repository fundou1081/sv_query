# ==============================================================================
# dataflow.py - DataFlow 分析图
# ==============================================================================
"""
基于 SignalGraph + MIG 的数据流分析图

职责:
1. 路径搜索 - 在数据边子图上做**有界** DFS (work budget + 可选 deadline)
2. 段构建 - 从 SignalGraph edges 获取 driver/condition/timing
3. 跨模块解析 - 直接使用实例级图节点 id
4. 结果缓存 - 按需缓存 DataFlowSegment

使用方式:
  dfg = DataFlowGraph(signal_graph, mig)
  result = dfg.analyze('top.u_dut.data_in', 'top.u_dut.data_out')
"""

import logging
import re
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Iterator

import networkx as nx

from .contracts import data_edge_view, is_data_edge
from .models import SignalGraph
from .search_budget import SearchBudget

if TYPE_CHECKING:
    from ..module_instance_graph import ModuleInstanceGraph

logger = logging.getLogger(__name__)


# ==============================================================================
# Data Structures
# ==============================================================================


@dataclass
class DataFlowSegment:
    """单步驱动关系: from_signal → to_signal

    Attributes:
        from_signal: 起点信号 (完整 hierarchy path)
        to_signal: 终点信号 (完整 hierarchy path)
        driver: 驱动表达式 (如 'sreg_d', '4'b1011')
        condition: 原始驱动条件（包含所有嵌套条件）
        effective_condition: 判断清除后的条件（只保留直接相关的条件）
        timing: 时钟域 (如 'clk_i')
        assign_type: 赋值类型 (continuous/always_ff/always_comb/blocking)
        distance: 驱动距离 (1 = 直接驱动)
    """

    from_signal: str
    to_signal: str
    driver: str | None = None
    condition: str | None = None
    effective_condition: str | None = None
    timing: str | None = None
    assign_type: str = "continuous"
    distance: int = 1


@dataclass
class DataFlowPath:
    """单条完整数据流路径

    Attributes:
        path_id: 路径 ID
        segments: 路径段列表
        distance: 总跳数 (graph hops)
        has_conditional: 是否包含条件分支
        latency_cycles: cycle latency (数 path 上 REG 节点; null if async crossing)
        is_async_crossing: 是否跨时钟域 (路径涉及 2+ clk domains)
        latency_note: latency 备注 (e.g. "2 sync stages" / "async crossing, latency not deterministic")
    """

    path_id: int
    segments: list[DataFlowSegment] = field(default_factory=list)
    distance: int = 0
    has_conditional: bool = False
    # [ADD 2026-07-04] latency 字段
    latency_cycles: int | None = None
    is_async_crossing: bool = False
    latency_note: str = ""


@dataclass
class DataFlowResult:
    """数据流分析完整结果

    Attributes:
        from_signal: 起点信号
        to_signal: 终点信号
        paths: 所有数据流路径
        is_reachable: 是否可达。**None = 未查完**（预算/超时耗尽，不能当成"没有")
        paths_count: 路径数量
        intermediate_signals: 中间信号集合
        all_conditions: 所有条件列表
        clock_domain: 主时钟域
        timing_risk: 路径风险级别 (safe/low/medium/high/critical)
        risk_model: 风险模型标签（当前是未标定启发式，不是测量结论）
        truncated: 搜索是否不完整（硬预算中止 或 结果被上限截断）
        truncation_reason: max_expansions_reached / deadline_reached /
            max_paths_reached / max_depth_reached；空串 = 完整
        expansions: 实际 work 计数（考察过的出边数）
        elapsed_s: 搜索耗时（秒）
    """

    from_signal: str
    to_signal: str
    paths: list[DataFlowPath] = field(default_factory=list)
    is_reachable: bool | None = False
    paths_count: int = 0
    intermediate_signals: set[str] = field(default_factory=set)
    all_conditions: list[str] = field(default_factory=list)
    clock_domain: str | None = None
    timing_risk: str = "safe"
    risk_model: str = "heuristic_v1_uncalibrated"
    # [ADD 2026-07-04] latency summary (从主 path 提取, 给快速 view)
    primary_latency_cycles: int | None = None
    primary_is_async: bool = False
    # [P158.11.2b] 有界搜索的显式状态 (SEMANTIC_CONTRACTS §3)
    truncated: bool = False
    truncation_reason: str = ""
    expansions: int = 0
    elapsed_s: float = 0.0

    @property
    def search_status(self) -> str:
        """complete / truncated / unknown（unknown = 请求没查完，不能当 not_found）。"""
        if self.is_reachable is None:
            return "unknown"
        return "truncated" if self.truncated else "complete"


# ==============================================================================
# DataFlowGraph
# ==============================================================================


class DataFlowGraph:
    """数据流图 - 基于 SignalGraph + MIG

    用于分析信号间的完整数据流路径,支持跨模块边界追踪。

    特性:
    - 按需构建: 不预先解析所有路径,按请求动态计算
    - 段缓存: 缓存已解析的 DataFlowSegment
    - 跨模块: 使用 MIG 映射解析实例端口信号
    """

    def __init__(self, signal_graph: SignalGraph, mig: "ModuleInstanceGraph"):
        """初始化 DataFlowGraph

        Args:
            signal_graph: SignalGraph 实例
            mig: ModuleInstanceGraph 实例
        """
        self.signal_graph = signal_graph
        self.mig = mig

        # 段缓存: (from, to) → DataFlowSegment
        self._segment_cache: dict[tuple[str, str], DataFlowSegment] = {}
        # [P158.1] 只含数据边的图视图缓存 (路径搜索用)
        self._data_graph_cache = None

    def _data_graph(self):
        """返回只含**数据边** (DRIVER / CONNECTION) 的有向图视图。

        [P158.1] SEMANTIC_CONTRACTS §2.2: `dataflow analyze` 的路径只能走
        data 边; CLOCK / RESET 只能作为时序注解, 不能成为路径节点,
        BIT_SELECT 只能作为**位展开** (端点归一化), 不能是路径的一段。

        edge 分类的唯一实现: `sv_query.trace.core.graph.contracts.data_edge_view`。
        """
        if self._data_graph_cache is None:
            self._data_graph_cache = data_edge_view(self.signal_graph)
        return self._data_graph_cache


    def get_segment(self, from_signal: str, to_signal: str) -> DataFlowSegment | None:
        """获取单步驱动信息(带缓存) - 返回优先级最高的边

        [P158.1] 只返回**数据边** (DRIVER / CONNECTION) 的 segment。
        CLOCK / RESET / BIT_SELECT / MEMBER_SELECT 不是数据路径的段 →
        返回 None (端点位的 BIT_SELECT 展开不算一段)。

        Args:
            from_signal: 起点信号
            to_signal: 终点信号

        Returns:
            DataFlowSegment 或 None (如果不存在**数据**驱动关系)
        """
        cache_key = (from_signal, to_signal)
        if cache_key in self._segment_cache:
            return self._segment_cache[cache_key]

        segment = self._build_segment(from_signal, to_signal)
        if segment:
            self._segment_cache[cache_key] = segment
        return segment

    def get_segments(self, from_signal: str, to_signal: str) -> list[DataFlowSegment]:
        """获取所有驱动信息 - 返回所有边对应的 segments

        Args:
            from_signal: 起点信号
            to_signal: 终点信号

        Returns:
            List[DataFlowSegment] (可能有多条边对应同一个驱动关系)
        """
        return self._build_segments(from_signal, to_signal)

    def _first_data_edge(self, src: str, dst: str):
        """取 (src, dst) 之间优先级最高的**数据边** (DRIVER / CONNECTION)。

        [P158.1] edge 分类的唯一实现是 `sv_query.trace.core.graph.contracts`。
        非数据边 (CLOCK / RESET / BIT_SELECT / MEMBER_SELECT) 返回 None ——
        它们不是数据驱动关系。
        """
        for edge in self.signal_graph.get_edges(src, dst):
            if is_data_edge(edge):
                return edge
        return None

    def _edge_condition(self, edge) -> str:
        """从边提取条件文本 (优先 condition, 为空时回退 condition_chain join).

        [FIX 2026-08-13] always 块内 ternary 场景下 edge.condition 为空, 但
        condition_chain 已正确填充 (e.g. ['a']). 回退读 chain 避免条件丢失.
        """
        cond = getattr(edge, "condition", None)
        if cond:
            return cond
        chain = getattr(edge, "condition_chain", None) or []
        return " && ".join([c for c in chain if c])

    def _build_segment(self, from_signal: str, to_signal: str) -> DataFlowSegment | None:
        """构建段信息 - 返回优先级最高的边

        从 SignalGraph 获取边的驱动信息。

        Args:
            from_signal: 起点信号
            to_signal: 终点信号

        Returns:
            DataFlowSegment 或 None
        """
        # 1. 解析跨模块信号
        resolved_from = from_signal
        resolved_to = to_signal

        # 2. 获取所有边（可能有多个不同 condition 的边），取第一条（优先级最高）
        # [P158.1] 只认**数据边** (DRIVER / CONNECTION); CLOCK/RESET/BIT_SELECT
        # 不是数据驱动关系。
        edge = self._first_data_edge(resolved_from, resolved_to)

        if not edge:
            # 尝试原始信号(未解析)
            edge = self._first_data_edge(from_signal, to_signal)

        if not edge:
            return None

        # 3. 构建 DataFlowSegment
        return DataFlowSegment(
            from_signal=from_signal,  # 保持原始 hierarchy path
            to_signal=to_signal,
            driver=edge.expression if hasattr(edge, "expression") else None,
            condition=self._edge_condition(edge),
            effective_condition=edge.effective_condition if hasattr(edge, "effective_condition") else None,
            timing=edge.clock_domain if hasattr(edge, "clock_domain") else None,
            assign_type=edge.assign_type if hasattr(edge, "assign_type") else "continuous",
            distance=1,
        )

    def _build_segments(self, from_signal: str, to_signal: str) -> list[DataFlowSegment]:
        """构建所有段信息 - 返回所有边对应的 segments

        从 SignalGraph 获取所有边的驱动信息。

        Args:
            from_signal: 起点信号
            to_signal: 终点信号

        Returns:
            List[DataFlowSegment]
        """
        # 1. 解析跨模块信号
        resolved_from = from_signal
        resolved_to = to_signal

        # 2. 获取所有边 (只取**数据边** — P158.1)
        edges = [e for e in self.signal_graph.get_edges(resolved_from, resolved_to)
                 if is_data_edge(e)]

        if not edges:
            # 尝试原始信号(未解析)
            edges = [e for e in self.signal_graph.get_edges(from_signal, to_signal)
                     if is_data_edge(e)]

        if not edges:
            return []

        # 3. 为每条边构建 DataFlowSegment
        segments = []
        for edge in edges:
            segments.append(
                DataFlowSegment(
                    from_signal=from_signal,
                    to_signal=to_signal,
                    driver=edge.expression if hasattr(edge, "expression") else None,
                    condition=self._edge_condition(edge),
                    effective_condition=edge.effective_condition if hasattr(edge, "effective_condition") else None,
                    timing=edge.clock_domain if hasattr(edge, "clock_domain") else None,
                    assign_type=edge.assign_type if hasattr(edge, "assign_type") else "continuous",
                    distance=1,
                )
            )

        return segments

    def _bounded_simple_paths(
        self,
        graph: nx.DiGraph,
        source: str,
        target: str,
        cutoff: int,
        state: SearchBudget,
    ) -> Iterator[list[str]]:
        """有界枚举 source → target 的简单路径（与 nx.all_simple_paths 同遍历序）。

        [P158.11.2b] SEMANTIC_CONTRACTS §3: 枚举必须有 work budget。这里
        每次"考察一条出边"记 1 次 `state.expansions`，循环顶端检查
        `state.exhausted`（work budget + deadline）；耗尽即**停止产出**，
        由调用方根据 `state.reason` 返回 truncated/unknown。

        为什么不用 `nx.all_simple_paths`：它会先遍历整棵搜索树才产出结果，
        无法在预算内中止（`list(...)` 更是先物化全部路径）。

        遍历序与 networkx `_all_simple_edge_paths` 一致（栈 + 当前路径字典，
        按插入序扩展），这样路径**顺序**不变，golden 不受影响。
        """
        if source not in graph or target not in graph or cutoff < 0:
            return
        current: dict[str | None, tuple | None] = {None: None}
        stack: list[Iterator] = [iter([(None, source)])]
        while stack:
            if state.exhausted:
                return
            edge = self._next_unvisited_edge(stack[-1], current, state)
            if edge is None:
                # 该节点所有出边已考察完 → 回溯
                stack.pop()
                current.popitem()
                continue
            nxt = edge[1]
            if nxt == target:
                yield list(current.keys())[1:] + [nxt]
            if self._expandable(current, nxt, target, cutoff):
                current[nxt] = edge
                stack.append(iter(graph.edges(nxt)))

    @staticmethod
    def _next_unvisited_edge(
        frontier: Iterator, current: dict, state: SearchBudget
    ) -> tuple | None:
        """取下一条"目标不在当前路径上"的边；没有则返回 None（触发回溯）。

        每考察一条边记 1 次 expansion —— 这是 work budget 的计量单位。
        """
        for e in frontier:
            state.expansions += 1
            if e[1] not in current:
                return e
        return None

    @staticmethod
    def _expandable(current: dict, nxt: str, target: str, cutoff: int) -> bool:
        """与 networkx 一致: 路径边数 (len(current)-1) < cutoff 才继续展开;
        已到 target 或 target 已在路径上时不再展开。"""
        return len(current) - 1 < cutoff and target not in current and nxt != target

    def _first_bounded_path(
        self,
        graph: nx.DiGraph,
        source: str,
        target: str,
        cutoff: int,
        state: SearchBudget,
    ) -> list[str] | None:
        """有界枚举下的第一条路径（struct 兜底只需要一条）。"""
        for path in self._bounded_simple_paths(graph, source, target, cutoff, state):
            if path:
                return path
        return None

    def _find_paths(self, from_signal: str, to_signal: str, cutoff: int = 50,
                    state: SearchBudget | None = None) -> list[list[str]]:
        """查找所有路径(允许循环)

        [P158.11.2b] 用 `_bounded_simple_paths` 做有界枚举 (work budget +
        deadline)，不再 `list(nx.all_simple_paths(...))` 先物化全部路径。
        截断原因记在 `state`，由 `analyze()` 写进结果。

        Args:
            from_signal: 起点信号
            to_signal: 终点信号
            cutoff: 最大深度限制 (边数)
            state: 预算记账器；None 时用默认预算 (供内部/旧调用)

        Returns:
            路径列表,每条路径是信号 ID 列表
        """
        if state is None:
            state = SearchBudget(max_expansions=200_000, deadline=None,
                                 max_paths=1_000_000, max_depth=cutoff)

        # [FIX] 处理位选择信号,如 byte_data[3:0] → byte_data
        def _expand_bit_select(signal):
            """将位选择信号展开为其父信号"""
            match = re.match(r"^(.+)\[([^\]]+)\]$", signal)
            if match:
                return match.group(1), match.group(2)
            return signal, None

        # 获取所有 BIT_SELECT 子节点(如 top.byte_data → top.byte_data[3:0])
        def _get_bit_select_children(signal):
            """获取信号的所有 BIT_SELECT 子节点 (signal 指向这些节点的反向边)

            [P158.1] BIT_SELECT 是**结构边**: 只用于**位展开** (端点归一化),
            不作为数据路径的段。所以这里查的是**全图**, 而不是数据边视图。
            """
            children = []
            # BIT_SELECT 边的方向是: child → parent (如 byte_data[3:0] → byte_data)
            # 所以我们需要找 signal 的前驱中有 BIT_SELECT 边的
            if signal not in full_graph.nodes():
                return children
            for pred in full_graph.predecessors(signal):
                edge = full_graph.get_edge(pred, signal)
                if edge and edge.kind.name == "BIT_SELECT":
                    children.append(pred)
            return children

        # 获取总线的**位成员节点** (如 top.byte_data → top.byte_data[3:0])
        def _get_bit_select_members(signal):
            """获取 signal 的所有 BIT_SELECT **成员**节点 (即 signal 的位切片)。

            [P158.1] BIT_SELECT 边的方向是 **child → parent**
            (top.byte_data[3:0] → top.byte_data), 所以 signal 的位成员在
            signal 的 **predecessor** 里 (child 是 parent 的前驱)。

            用途: **位展开** —— 端点是总线时, 展开成逐位候选,
            让数据路径的**段**全部是数据边 (DRIVER/CONNECTION);
            BIT_SELECT 本身不作为路径的一段 (契约 §2.2)。
            """
            members = []
            if signal not in full_graph.nodes():
                return members
            for pred in full_graph.predecessors(signal):
                edge = full_graph.get_edge(pred, signal)
                if edge and edge.kind.name == "BIT_SELECT":
                    members.append(pred)
            return members

        # [FIX] 处理 struct 成员访问,如 pkt1.data → pkt2.data
        def _get_struct_parent_and_member(signal):
            """解析 struct 成员访问,返回 (parent_struct, member_name) 或 (None, None)

            只识别真正的 struct 成员访问模式,不识别模块.信号形式。
            例如:
                - test_interface.pkt1.data → (test_interface.pkt1, data) 如果 pkt1 是 struct
                - test_interface.data_out → (None, None) 因为 data_out 是模块端口
            """
            # 匹配 xxx.member 形式
            match = re.match(r"^(.+)\.([^.]+)$", signal)
            if match:
                parent = match.group(1)
                member = match.group(2)

                if parent and member:
                    # 如果 parent 在图中,检查它是否是 struct 类型
                    # (通过检查 parent 是否有结构体成员)
                    if parent in full_graph.nodes():
                        # 检查 parent 是否看起来像 struct 变量
                        # struct 变量通常有子成员,如 pkt1.addr, pkt1.data 等
                        has_struct_children = False
                        for succ in full_graph.successors(parent):
                            succ_edge = full_graph.get_edge(parent, succ)
                            if succ_edge and succ_edge.kind.name == "DRIVER":
                                # 检查 succ 是否是 parent.member 形式
                                if succ.startswith(parent + "."):
                                    has_struct_children = True
                                    break
                        if has_struct_children:
                            return parent, member
                    else:
                        # parent 不在图中,可能是简化的 struct 变量名
                        # 只有当 parent 不像是模块名时才返回
                        # 启发式: 如果 parent 首字母大写,可能是模块名
                        if parent and not parent[0].isupper():
                            return parent, member
            return None, None

        def _find_struct_member_paths(from_signal, to_signal):
            """查找 struct 成员的数据流路径(如 pkt1.data → pkt2.data)"""
            # 解析源和目标
            src_parent, src_member = _get_struct_parent_and_member(from_signal)
            dst_parent, dst_member = _get_struct_parent_and_member(to_signal)

            if not src_parent or not dst_parent:
                return []

            # 如果成员名不同,可能不是同一个 struct 的成员传播
            if src_member != dst_member:
                return []

            # 如果父节点相同,无须跨成员传播
            if src_parent == dst_parent:
                return []

            # [FIX] 确保 src_parent 和 dst_parent 都在图中
            if src_parent not in nx_graph.nodes() or dst_parent not in nx_graph.nodes():
                return []

            # 检查 src_parent → dst_parent 的路径
            # [P158.1] 路径存在性只看**数据边**
            if nx.has_path(nx_graph, src_parent, dst_parent):
                # 构造路径: from_signal → src_parent → dst_parent → to_signal
                try:
                    struct_path = [from_signal, src_parent, dst_parent, to_signal]
                    return [struct_path]
                except (nx.NetworkXNoPath, nx.NodeNotFound):
                    return []

            # 也检查反向: 如果 to_signal 是成员,但 dst_parent 被 from_signal 驱动
            # 比如: pkt1 → pkt2, 然后查询 pkt1.data → pkt2.data
            edge = full_graph.get_edge(src_parent, dst_parent)
            if edge and edge.kind.name == "DRIVER":
                # 构造路径
                return [[from_signal, src_parent, dst_parent, to_signal]]

            return []

        def _is_bit_member_of(graph, member: str, bus: str) -> bool:
            """`member` 是否是总线 `bus` 的**位成员** (BIT_SELECT child → parent 边)。

            [P158.1] 用于位展开的端点接回: 数据路径的段全是数据边, 但终点可以是
            总线的某个位成员 —— 这时把总线端点接回去 (作为**端点**, 不是路径的一段)。

            Args:
                graph: 全图 (含 BIT_SELECT 边)
                member: 候选终点 (如 "top.y[0]")
                bus: 用户请求的终点 (如 "top.y")
            """
            if member == bus:
                return True
            try:
                edge = graph.get_edge(member, bus)
            except (KeyError, nx.NetworkXError):
                return False
            return bool(edge) and edge.kind.name == "BIT_SELECT"

        # 解析跨模块信号
        resolved_from = from_signal
        resolved_to = to_signal
        # 展开位选择
        expanded_from, slice_from = _expand_bit_select(resolved_from)
        expanded_to, slice_to = _expand_bit_select(resolved_to)

        # 获取 networkx 图
        try:
            full_graph = self.signal_graph
        except AttributeError:
            logger.warning("SignalGraph does not support networkx conversion")
            return []

        # [P158.1] 路径搜索只走**数据边** (DRIVER / CONNECTION)。
        # CLOCK / RESET / BIT_SELECT / MEMBER_SELECT 不得成为数据路径的段。
        # BIT_SELECT 仍然用于**位展开** (端点归一化), 但那在下面用 full_graph 做,
        # 不是路径上的一段。
        # edge 契约的唯一实现: sv_query.trace.core.graph.contracts
        nx_graph = self._data_graph()
        # full_graph 仍用于查边属性 (BIT_SELECT 亲子关系 / struct 成员识别)
        _full = full_graph

        # 构建候选起始点列表(包括 BIT_SELECT 子节点)
        candidates_from = [resolved_from]
        if expanded_from != resolved_from:
            candidates_from.append(expanded_from)
        # 添加 expanded_from 的 BIT_SELECT 子节点
        for child in _get_bit_select_children(expanded_from):
            if child not in candidates_from:
                candidates_from.append(child)

        # 构建候选目标点列表 (位展开: 总线 → 逐位成员)
        candidates_to = [resolved_to]
        if expanded_to != resolved_to:
            candidates_to.append(expanded_to)
        # [P158.1] 总线终点 → 逐位成员候选。
        # BIT_SELECT 边方向是 child → parent, 所以 bus 的位成员是它的**前驱**。
        # 旧实现找的是"父节点"(successors 方向), 与 BIT_SELECT 实际方向相反 →
        # 只能靠把 BIT_SELECT 当成路径的一段才能到达 bus 终点 (违反契约)。
        for member in _get_bit_select_members(expanded_to):
            if member not in candidates_to:
                candidates_to.append(member)

        # 尝试所有候选组合 — [iter_131 fix] 收集并合并所有组合的路径,
        # 而非首个非空即 return: iter_118 per-entry 后 bus→bus 查询
        # (req_i → gnt_o) 不再有直接 bus 边 (DRIVER 变成 req_i[i]→gnt_o[i]
        # per-index), 需逐个 (req_i[i], gnt_o) 组合枚举; 旧逻辑首个 req_i[0]
        # 命中即停 → 丢 req_i[1..7] (arbiter golden 40→8→1 根因, prim_arbiter
        # usage 测试暴露). 合并后 bus 查询 = 各 bit 路径聚合 (与 iter_118 前
        # bus 粒度 8 条语义一致).
        all_paths: list[list[str]] = []
        seen_paths: set[tuple[str, ...]] = set()
        stop = False
        for from_candidate in candidates_from:
            if stop:
                break
            for to_candidate in candidates_to:
                if stop:
                    break
                if from_candidate not in nx_graph.nodes():
                    continue
                if to_candidate not in nx_graph.nodes():
                    continue
                # [P158.11.2b] 有界枚举: 不再 `list(nx.all_simple_paths(...))`
                # 先物化全部路径 (分支图指数爆炸); 每考察一条出边记 1 次 work,
                # 预算/超时耗尽即停, 由 state 记录原因。
                # 先做廉价可达性预检, 避免"无路径"时遍历指数级死胡同。
                if not nx.has_path(nx_graph, from_candidate, to_candidate):
                    continue
                for p in self._bounded_simple_paths(
                    nx_graph, from_candidate, to_candidate, cutoff, state
                ):
                    if not p:
                        continue
                    # [P158.1] 端点保真: 路径必须**以用户请求的 to_signal 结尾**。
                    # 位展开得到的候选终点 (如 top.y[0]) 不是请求的终点 (top.y),
                    # 它是总线的**成员** —— 用位展开把端点接回去 (不是路径的一段)。
                    if p[-1] != resolved_to:
                        if not _is_bit_member_of(full_graph, p[-1], resolved_to):
                            continue
                        p = p + [resolved_to]
                    key = tuple(p)
                    if key in seen_paths:
                        continue
                    if len(all_paths) >= state.max_paths:
                        # 收满后**又找到一条** → 确实还有更多, 必须显式截断
                        state.note("max_paths_reached")
                        stop = True
                        break
                    seen_paths.add(key)
                    all_paths.append(p)
                if state.hard_truncated:
                    stop = True
                    break
        if all_paths:
            return all_paths
        if state.hard_truncated:
            # 预算耗尽 ≠ 没有路径: 调用方必须返回 unknown (不能 found:false)
            return []

        # [FIX] 处理 struct 成员传播的完整路径
        # 例如: data_in → pkt1.data → pkt1 → pkt2 → pkt2.data → data_out
        # 这里 pkt1.data 和 pkt2.data 是中间节点

        # 首先解析源和目标是否为 struct 成员
        src_parent, src_member = _get_struct_parent_and_member(from_signal)
        dst_parent, dst_member = _get_struct_parent_and_member(to_signal)

        # 检查是否存在 struct 赋值导致的成员传播
        # 情况1: from_signal 本身就是成员,需要查找它的父 struct 是否赋值给另一个 struct
        if src_member and src_parent in nx_graph.nodes():
            # 检查 from_signal 的父 struct 是否有 DRIVER 边到其他 struct
            for succ in full_graph.successors(src_parent):
                edge = full_graph.get_edge(src_parent, succ)
                if edge and edge.kind.name == "DRIVER":
                    # 找到了 struct 赋值: src_parent → succ
                    # 检查 succ 是否是 to_signal 的父或者能否继续传播
                    succ_parent, succ_member = _get_struct_parent_and_member(succ)
                    if succ_member is None:
                        # succ 是 struct 变量本身
                        # 检查 succ.member 是否能到达 to_signal
                        # 这里 member 应该和 src_member 相同
                        for to_candidate in candidates_to:
                            # [FIX] 确保节点存在
                            if to_candidate not in nx_graph.nodes():
                                continue
                            if nx.has_path(nx_graph, succ, to_candidate):
                                # 找到了通过 struct 传播的路径
                                # 构造: from_signal → src_parent → succ → ... → to_signal
                                # 需要找到从 succ 到 to_signal 的路径
                                # [P158.11.2b] 有界枚举，只要第一条
                                sp = self._first_bounded_path(
                                    nx_graph, succ, to_candidate, cutoff, state
                                )
                                if sp:
                                    return [[from_signal] + sp]
                                if state.hard_truncated:
                                    return []

        # 情况2: to_signal 是成员,检查是否有 struct 赋值到它的父
        if dst_member and dst_parent in nx_graph.nodes():
            # 检查是否有 struct 赋值到 dst_parent
            for pred in full_graph.predecessors(dst_parent):
                edge = full_graph.get_edge(pred, dst_parent)
                if edge and edge.kind.name == "DRIVER":
                    # 找到了 struct 赋值: pred → dst_parent
                    # 检查 from_signal 能否到达 pred
                    for from_candidate in candidates_from:
                        # [FIX] 确保节点存在
                        if from_candidate not in nx_graph.nodes():
                            continue
                        if nx.has_path(nx_graph, from_candidate, pred):
                            sp = self._first_bounded_path(
                                nx_graph, from_candidate, pred, cutoff, state
                            )
                            if sp:
                                return [sp + [dst_parent, to_signal]]
                            if state.hard_truncated:
                                return []

        # [FIX] 情况2b: to_signal 被 struct.member 表达式驱动
        # 例如: data_out 由 pkt2.data 驱动,需要追踪 pkt2 的来源
        # 检查所有到 to_signal 的边,看是否有表达式是 xxx.member 形式
        for pred in full_graph.predecessors(to_signal):
            edge = full_graph.get_edge(pred, to_signal)
            if edge and edge.expression:
                # 解析表达式中的 .member 模式
                match = re.search(r"\.([a-zA-Z_][a-zA-Z0-9_]*)$", edge.expression)
                if match:
                    match.group(1)
                    dst_struct_path = edge.expression[: match.start()]
                    # dst_struct_path 可能是相对路径如 pkt2,需要解析为完整路径
                    # 尝试解析 dst_struct_path
                    try:
                        dst_struct_resolved = dst_struct_path
                    except Exception:
                        dst_struct_resolved = dst_struct_path

                    # 确保 dst_struct_resolved 在图中
                    if dst_struct_resolved not in nx_graph.nodes():
                        # 尝试添加模块前缀
                        if pred.endswith(f".{dst_struct_path}"):
                            dst_struct_resolved = pred.rsplit(".", 1)[0] + "." + dst_struct_path

                    if dst_struct_resolved not in nx_graph.nodes():
                        continue

                    # [FIX] 情况2b扩展: 检查 from_signal 是否能通过 struct member 路径到达 dst_struct_resolved
                    # 路径: from_signal → ... → src_struct.member → src_struct → dst_struct → to_signal
                    # 例如: data_in → pkt1.data → pkt1 → pkt2 → data_out
                    #
                    # 首先检查 from_signal 是否能到达某个 struct 的 member
                    src_parent_candidate, src_member_candidate = _get_struct_parent_and_member(from_signal)

                    # 尝试所有可能的 struct 传播路径
                    # 检查 dst_struct_resolved 的前驱(struct 赋值)
                    for struct_pred in full_graph.predecessors(dst_struct_resolved):
                        struct_edge = full_graph.get_edge(struct_pred, dst_struct_resolved)
                        if struct_edge and struct_edge.kind.name == "DRIVER":
                            # 找到了 struct_pred → dst_struct_resolved
                            # 现在检查 from_signal 能否到达 struct_pred
                            if nx.has_path(nx_graph, from_signal, struct_pred):
                                sp = self._first_bounded_path(
                                    nx_graph, from_signal, struct_pred, cutoff, state
                                )
                                if sp:
                                    # 找到了! 路径: from → ... → struct_pred → dst_struct_resolved → to_signal
                                    return [sp + [struct_pred, dst_struct_resolved, to_signal]]
                                if state.hard_truncated:
                                    return []

                            # [FIX] 如果 from_signal 是 struct.member,检查是否能通过 struct 父节点传播
                            # 例如: from_signal = pkt1.data, struct_pred = pkt1
                            # 路径: pkt1.data → pkt1 → pkt2 → data_out
                            if src_member_candidate:
                                # 检查 from_signal 能否到达 struct_pred
                                if nx.has_path(nx_graph, from_signal, struct_pred):
                                    sp = self._first_bounded_path(
                                        nx_graph, from_signal, struct_pred, cutoff, state
                                    )
                                    if sp:
                                        return [sp + [dst_struct_resolved, to_signal]]
                                    if state.hard_truncated:
                                        return []

                                # 检查 from_signal 的父 struct 是否能到达 struct_pred
                                if src_parent_candidate in nx_graph.nodes():
                                    if nx.has_path(nx_graph, src_parent_candidate, struct_pred):
                                        # 路径: from_signal → src_parent_candidate → ... → struct_pred → dst_struct_resolved → to_signal
                                        return [
                                            [
                                                from_signal,
                                                src_parent_candidate,
                                                struct_pred,
                                                dst_struct_resolved,
                                                to_signal,
                                            ]
                                        ]

        # 情况3: 直接的 struct 成员路径查找 (pkt1.data → pkt2.data)
        struct_paths = _find_struct_member_paths(from_signal, to_signal)
        if struct_paths:
            return struct_paths

        # 情况4: 成员名相同的情况 (如 src.member → dst.member)
        if (
            src_member
            and dst_member
            and src_member == dst_member
            and src_parent in nx_graph.nodes()
            and dst_parent in nx_graph.nodes()
        ):
            edge = full_graph.get_edge(src_parent, dst_parent)
            if edge and edge.kind.name == "DRIVER":
                return [[from_signal, src_parent, dst_parent, to_signal]]

        return []

    def analyze(self, from_signal: str, to_signal: str, max_paths: int = 100,
                *, max_expansions: int = 200_000,
                timeout_s: float | None = None,
                max_depth: int = 50) -> DataFlowResult:
        """分析 from → to 的完整数据流路径

        主入口方法,返回完整的 DataFlowResult。

        [P158.11.2b] 有界搜索 (SEMANTIC_CONTRACTS §3):
          - `max_expansions`: work budget (考察的出边数)
          - `timeout_s`: wall-clock 上限 (None = 不限)
          - 超限时 `truncated=True` + `truncation_reason`；
            若一条路径都没找到且是**硬预算**中止 → `is_reachable=None`
            (unknown，"没查完" ≠ "没有路径")

        Args:
            from_signal: 起点信号 (完整 hierarchy path)
            to_signal: 终点信号 (完整 hierarchy path)
            max_paths: 最大路径数量限制 (收满后确认还有更多 → max_paths_reached)
            max_expansions: work budget
            timeout_s: 可选 wall-clock 秒数
            max_depth: 路径边数上限 (cutoff)

        Returns:
            DataFlowResult: 包含所有路径及分析结果

        Raises:
            ValueError: 信号在图中不存在, 错误信息包含 hint (要求 hierarchical name)
                        和前 10 个可用信号名
        """
        # [ADD 2026-06-11 Req-11] 验证信号在图中存在, 友好错误提示
        # 修复 Issue 20: 裸信号名报错 "not in digraph" 不告诉用户需 hierarchical name
        # SignalGraph 本身是 nx.DiGraph, 直接用 .nodes()
        for sig in (from_signal, to_signal):
            if sig not in self.signal_graph.nodes():
                available = sorted([n for n in self.signal_graph.nodes() if isinstance(n, str)])[:10]
                # 检测信号是否带 hierarchy, 给 hint
                hint = ""
                if "." not in sig:
                    # 尝试提供一个带 module 名的 hint
                    for n in self.signal_graph.nodes():
                        if isinstance(n, str) and "." in n:
                            module_name = n.split(".")[0]
                            hint = f"\nHint: signal name should be hierarchical, e.g. '{module_name}.{sig}'"
                            break
                raise ValueError(
                    f"Signal '{sig}' not found in graph."
                    f"{hint}\n"
                    f"Available signals (first 10): {available}"
                )

        # 1. 查找所有路径 (有界)
        deadline = None if timeout_s is None else time.monotonic() + timeout_s
        state = SearchBudget(
            max_expansions=max_expansions,
            deadline=deadline,
            max_paths=max_paths,
            max_depth=max_depth,
        )
        paths = self._find_paths(from_signal, to_signal, cutoff=max_depth, state=state)
        # Endpoint fidelity: parent/BIT_SELECT alternative targets must not be
        # reported as if they reached the requested destination.
        paths = [p for p in paths if p and p[-1] == to_signal]

        budget_fields = {
            "truncated": state.truncated,
            "truncation_reason": state.reason,
            "expansions": state.expansions,
            "elapsed_s": round(state.elapsed_s, 6),
        }

        if not paths:
            # [P158.11.2b] 硬预算/超时中止时**不能**说"不可达" —— 那是 unknown。
            return DataFlowResult(
                from_signal=from_signal,
                to_signal=to_signal,
                is_reachable=None if state.hard_truncated else False,
                paths_count=0,
                **budget_fields,
            )

        # 2. 限制路径数量 (预算已在上游收口; 这里保留防御性切片)
        paths = paths[:max_paths]

        # 3. 构建 DataFlowPath
        dataflow_paths = []
        all_intermediate: set[str] = set()
        all_conditions: list[str] = []
        has_conditional = False

        for path_id, path in enumerate(paths):
            segments = []

            # 4. 构建每条路径的 segments
            for i in range(len(path) - 1):
                seg_from = path[i]
                seg_to = path[i + 1]

                # 获取 segment(使用缓存)
                segment = self.get_segment(seg_from, seg_to)

                if segment:
                    segments.append(segment)

                    # 收集条件
                    if segment.condition:
                        all_conditions.append(segment.condition)
                        has_conditional = True

                    # 收集中间信号(排除起点和终点)
                    if i > 0:
                        all_intermediate.add(seg_from)

            # 5. 创建 DataFlowPath
            # [ADD 2026-07-04] 算 latency_cycles + is_async_crossing + stage_breakdown
            latency_cycles, is_async, latency_note, stage_breakdown = self._compute_latency_and_stages(path, segments)
            df_path = DataFlowPath(
                path_id=path_id,
                segments=segments,
                # [P158.1] distance = **数据段**数 (位展开的端点接回不算一跳)
                distance=len(segments),
                has_conditional=has_conditional,
                latency_cycles=latency_cycles,
                is_async_crossing=is_async,
                latency_note=latency_note,
            )
            df_path.stage_breakdown = stage_breakdown  # type: ignore[attr-defined]
            dataflow_paths.append(df_path)

        # 6. 收集时钟域
        clock_domain = self._extract_clock_domain(dataflow_paths)

        # 7. 评估路径风险
        timing_risk = self._evaluate_timing_risk(dataflow_paths, clock_domain)

        # 7.5 [ADD 2026-07-04] 提取主 path 的 latency summary
        primary_latency = dataflow_paths[0].latency_cycles if dataflow_paths else None
        primary_async = dataflow_paths[0].is_async_crossing if dataflow_paths else False

        return DataFlowResult(
            from_signal=from_signal,
            to_signal=to_signal,
            paths=dataflow_paths,
            is_reachable=True,
            paths_count=len(dataflow_paths),
            intermediate_signals=all_intermediate,
            all_conditions=all_conditions,
            clock_domain=clock_domain,
            timing_risk=timing_risk,
            primary_latency_cycles=primary_latency,
            primary_is_async=primary_async,
            **budget_fields,
        )

    def _compute_latency_and_stages(
        self,
        path: list[str],
        segments: list[DataFlowSegment],
    ) -> tuple[int | None, bool, str, list[dict]]:
        """[ADD 2026-07-04] 算 path 的 cycle latency + stage breakdown.

        算法:
        1. 沿 path 数 REG 节点 (每 REG = 1 cycle boundary)
        2. 检查是否跨 clk domain (segments timing 多个不同值) → async crossing
        3. 复用 detect_pipeline 算 stages, 给每个 segment 标 stage_id
        4. stage_breakdown = list of {stage_id, from_signal, to_signal, is_reg_boundary}

        Returns:
            (latency_cycles, is_async, note, stage_breakdown)
        """
        if not segments:
            return 0, False, "empty path", []

        # 1. 检查 async crossing: segments timing 多个不同
        timing_set = {s.timing for s in segments if s.timing}
        timing_set.discard(None)
        is_async = len(timing_set) > 1

        # 2. 数 path 上 REG 节点
        reg_count = 0
        for node_id in path:
            node = self.signal_graph.get_node(node_id)
            if node and node.kind.name == "REG":
                reg_count += 1

        # 3. 算 stage breakdown (复用 detect_pipeline)
        stage_breakdown = self._compute_stage_breakdown(path, segments)

        if is_async:
            return None, True, f"async crossing ({len(timing_set)} clk domains), latency not deterministic", stage_breakdown

        if reg_count == 0:
            return 0, False, "no register boundary (combinational only)", stage_breakdown
        else:
            return reg_count, False, f"{reg_count} sync stages (cycle latency)", stage_breakdown

    def _compute_stage_breakdown(
        self,
        path: list[str],
        segments: list[DataFlowSegment],
    ) -> list[dict]:
        """[ADD 2026-07-04] 算 path 跨几个 pipeline stage, 每个 segment 属于哪个 stage.

        复用 detect_pipeline + signal_classifier.
        """
        try:
            from .analyzer.pipeline_viz import detect_pipeline
            from .analyzer.signal_classifier import classify_graph
        except ImportError:
            return []

        try:
            classification = classify_graph(self.signal_graph)
            if classification is None:
                return []
            pipeline_info = detect_pipeline(self.signal_graph, classification)
        except Exception:
            return []

        if not pipeline_info.stages:
            return []

        # Build stage_id map: reg_id → stage_id
        reg_to_stage: dict[str, int] = {}
        for stage in pipeline_info.stages:
            for reg_id in stage.reg_nodes:
                reg_to_stage[reg_id] = stage.stage_id

        # 沿 path 走, 标每个 segment 的 stage
        breakdown = []
        for _i, seg in enumerate(segments):
            # 这个 segment 的 stage = to_signal (终点) 所属的 stage
            # 起点可能是 stage N, 终点可能是 stage N (组合) or stage N+1 (REG boundary)
            from_node = self.signal_graph.get_node(seg.from_signal)
            to_node = self.signal_graph.get_node(seg.to_signal)
            from_kind = from_node.kind.name if from_node else "?"
            to_kind = to_node.kind.name if to_node else "?"

            from_stage = reg_to_stage.get(seg.from_signal)
            to_stage = reg_to_stage.get(seg.to_signal)

            # 如果 from/to 都不是 REG, 标 -1 (within stage or before first stage)
            breakdown.append({
                "from_signal": seg.from_signal,
                "to_signal": seg.to_signal,
                "from_stage": from_stage,
                "to_stage": to_stage,
                "is_reg_boundary": to_kind == "REG",
                "from_kind": from_kind,
                "to_kind": to_kind,
            })

        return breakdown

    def _extract_clock_domain(self, paths: list[DataFlowPath]) -> str | None:
        """提取主时钟域

        Args:
            paths: 数据流路径列表

        Returns:
            主时钟域字符串或 None
        """
        clock_domains: dict[str, int] = {}

        for path in paths:
            for segment in path.segments:
                if segment.timing:
                    clock_domains[segment.timing] = clock_domains.get(segment.timing, 0) + 1

        if not clock_domains:
            return None

        # 返回出现最多的时钟域
        return max(clock_domains, key=clock_domains.get)

    def _evaluate_timing_risk(self, paths: list[DataFlowPath], clock_domain: str | None) -> str:
        """评估路径时序风险

        Args:
            paths: 数据流路径列表
            clock_domain: 主时钟域

        Returns:
            风险级别: safe/low/medium/high/critical
        """
        if not paths:
            return "safe"

        # 检查是否跨时钟域
        clock_domains = set()
        for path in paths:
            for segment in path.segments:
                if segment.timing:
                    clock_domains.add(segment.timing)

        if len(clock_domains) > 1:
            return "high"  # 跨时钟域

        # 检查路径长度
        max_distance = max(p.distance for p in paths)

        if max_distance > 10:
            return "medium"
        elif max_distance > 5:
            return "low"

        return "safe"

    def clear_cache(self) -> None:
        """清除段缓存"""
        self._segment_cache.clear()
        # [P158.1] 数据边视图也是缓存 (图变了必须重建)
        self._data_graph_cache = None

    def get_cache_stats(self) -> dict[str, int]:
        """获取缓存统计"""
        return {"segment_cache_size": len(self._segment_cache), "mig_mapping_size": 0}
