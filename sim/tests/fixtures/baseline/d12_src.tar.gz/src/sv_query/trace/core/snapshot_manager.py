# ==============================================================================
# snapshot_manager.py - 快照管理 (CRUD)
# [铁律13] 金标准测试优先
# ==============================================================================
# 目标: 管理快照文件 (# [iter_239 1b] 默认位置迁到缓存目录, 不再写项目目录)
#
# 快照格式:
# {
#   "version": "1.0",
#   "tag": "v1.2.3",
#   "created_at": "ISO timestamp",
#   "git_commit": "abc1234",
#   "files": ["rtl/top.sv"],
#   "node_count": 42,
#   "edge_count": 67,
#   "nodes": [...],
#   "edges": [...]
# }
# ==============================================================================

import json
import logging
import os
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from .cache.ast_cache import resolve_cache_dir  # [iter_239] 缓存目录解析

logger = logging.getLogger(__name__)
SNAPSHOT_VERSION = "1.0"


# ----------------------------------------------------------------------------
# [iter_239 1b] 快照目录解析 (单一真相源)
#   顺序: 显式参数 > $SVQ_SNAPSHOT_DIR > <cache_dir>/snapshots
#   cache_dir 复用 resolve_cache_dir(): $SVQ_CACHE_DIR > $XDG_CACHE_HOME/svq > ~/.svq/cache
#
# 为什么改: 旧默认是**相对 cwd 的 `.svq/snapshots`** —— 测试与日常使用会把快照写进
# 项目目录 (实测仓库根累积 5035 个 / 137MB, 其中 ~4998 个是测试残留)。
# 迁移: 旧目录不会被自动读取 (不做 silent fallback); 需要旧快照请用 SVQ_SNAPSHOT_DIR
#      指过去, 或把它们拷到新目录。见 docs/task_tree/iterations/iter_239_*.md。
# ----------------------------------------------------------------------------
ENV_SNAPSHOT_DIR = "SVQ_SNAPSHOT_DIR"
ENV_SNAPSHOT_MAX_MB = "SVQ_SNAPSHOT_MAX_MB"
DEFAULT_SNAPSHOT_MAX_MB = 64.0
#: 历史默认位置 (仅用于提示/迁移, 不再作为默认写入目标)
LEGACY_SNAPSHOT_DIR = ".svq/snapshots"


def resolve_snapshot_dir(explicit: str | os.PathLike | None = None) -> Path:
    """快照目录解析: 显式 > $SVQ_SNAPSHOT_DIR > <cache_dir>/snapshots。"""
    if explicit:
        return Path(explicit).expanduser()
    env_dir = os.environ.get(ENV_SNAPSHOT_DIR)
    if env_dir:
        return Path(env_dir).expanduser()
    return resolve_cache_dir() / "snapshots"


class SnapshotManager:
    """[Golden] 快照管理器 - CRUD 操作

    金标准操作:
    - save: 保存新快照
    - list: 列出所有快照
    - show: 查看快照详情
    - delete: 删除快照
    - compare: 对比两个快照
    """

    def __init__(self, base_dir: str | None = None):
        # [iter_239 1b] 默认位置 = resolve_snapshot_dir() (缓存目录), 不再是 cwd 下的 .svq/
        self.base_dir = resolve_snapshot_dir(base_dir)
        try:
            self.max_bytes = int(float(os.environ.get(
                ENV_SNAPSHOT_MAX_MB, DEFAULT_SNAPSHOT_MAX_MB)) * 1024 * 1024)
        except ValueError as e:
            raise ValueError(
                f"{ENV_SNAPSHOT_MAX_MB} must be numeric MB, got "
                f"{os.environ.get(ENV_SNAPSHOT_MAX_MB)!r}"
            ) from e
        try:
            self.base_dir.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            # [iter_239] 受限环境 (沙箱/只读 home/CI) 下给**可操作**提示, 而不是裸 Errno
            raise OSError(
                f"快照目录不可写: {self.base_dir} ({e}). "
                f"用 {ENV_SNAPSHOT_DIR}=<可写目录> 覆盖 (如 {ENV_SNAPSHOT_DIR}=$PWD/.svq-snapshots)"
            ) from e

    def _snapshot_path(self, tag: str) -> Path:
        """根据 tag 获取快照文件路径"""
        # tag 作为文件名，安全处理
        safe_tag = tag.replace("/", "_").replace("\\", "_").replace("..", "_")
        return self.base_dir / f"{safe_tag}.json"

    def _list_snapshots(self) -> list[dict]:
        """[Golden] 列出所有快照元数据（不加载完整图）。

        [P158.7] 文件名是 tag 的唯一权威；文件体里的 tag 只用于检测 mismatch。
        损坏文件必须作为**可见的 error entry** 返回，不能拖垮整个列表。
        """
        snapshots = []
        for path in sorted(self.base_dir.glob("*.json")):
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                if not isinstance(data, dict):
                    raise ValueError("snapshot root is not an object")
                mig = data.get("module_graph") or {}
                mig_instances = mig.get("instances") or {}
                entry = {
                    "tag": path.stem,
                    "file": str(path),
                    "created_at": data.get("created_at", ""),
                    "git_commit": data.get("git_commit", ""),
                    "files": data.get("files", []),
                    "node_count": data.get("node_count", 0),
                    "edge_count": data.get("edge_count", 0),
                    "file_size_bytes": path.stat().st_size,
                    "module_graph_present": bool(mig_instances),
                    "module_graph_instances": len(mig_instances),
                    "module_graph_ports": sum(len(i.get("ports") or {})
                                              for i in mig_instances.values()),
                }
                body_tag = data.get("tag")
                if body_tag is not None and body_tag != path.stem:
                    entry["tag_mismatch"] = str(body_tag)
                snapshots.append(entry)
            except (OSError, ValueError, TypeError, AttributeError, json.JSONDecodeError) as e:
                logger.warning("Failed to read snapshot %s: %s", path, e)
                snapshots.append({
                    "tag": path.stem,
                    "file": str(path),
                    "error": f"invalid snapshot: {e}",
                    "node_count": 0,
                    "edge_count": 0,
                    "module_graph_present": False,
                })
        return snapshots

    def save(self, tag: str, graph_data: dict, git_commit: str = "", files: list[str] = None) -> str:
        """[Golden] 保存快照

        Args:
            tag: 快照标签（如 "v1.2.3"）
            graph_data: SignalGraph.to_dict() 的结果
            git_commit: Git commit hash
            files: 相关的源文件列表

        Returns:
            快照文件路径

        金标准:
        - tag 唯一，重复保存会覆盖
        - 保存前记录 created_at
        """
        path = self._snapshot_path(tag)

        data = dict(graph_data)  # 拷贝
        data.setdefault("version", SNAPSHOT_VERSION)
        data["tag"] = tag
        data["git_commit"] = git_commit
        data["files"] = files or []
        data["created_at"] = datetime.now(UTC).isoformat()

        payload = json.dumps(data, indent=2, ensure_ascii=False)
        size_bytes = len(payload.encode("utf-8"))
        if self.max_bytes > 0 and size_bytes > self.max_bytes:
            raise ValueError(
                f"snapshot too large: {size_bytes} bytes > "
                f"{self.max_bytes} bytes ({ENV_SNAPSHOT_MAX_MB}); "
                "not written (set a larger limit explicitly if intended)"
            )

        tmp_path: str | None = None
        try:
            fd, tmp_path = tempfile.mkstemp(
                dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp")
            os.close(fd)
            with open(tmp_path, "w", encoding="utf-8") as f:
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, path)
            tmp_path = None
        finally:
            if tmp_path:
                try:
                    Path(tmp_path).unlink()
                except OSError as cleanup_err:
                    logger.debug("snapshot temp cleanup failed: %s", cleanup_err)

        logger.info(f"Snapshot saved: {tag} -> {path}")
        return str(path)

    def load(self, tag: str) -> dict | None:
        """[Golden] 加载快照完整数据。

        Raises:
            ValueError: 文件存在但 JSON/根对象损坏（显式失败，不返回假图）。
        """
        path = self._snapshot_path(tag)
        if not path.exists():
            logger.warning(f"Snapshot not found: {tag}")
            return None

        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError, UnicodeDecodeError) as e:
            raise ValueError(f"invalid snapshot {tag}: {e}") from e
        if not isinstance(data, dict):
            raise ValueError(f"invalid snapshot {tag}: root is not an object")
        return data

    def delete(self, tag: str) -> bool:
        """[Golden] 删除快照

        Args:
            tag: 快照标签

        Returns:
            True if deleted, False if not found
        """
        path = self._snapshot_path(tag)
        if not path.exists():
            return False

        path.unlink()
        logger.info(f"Snapshot deleted: {tag}")
        return True

    def exists(self, tag: str) -> bool:
        """检查快照是否存在"""
        return self._snapshot_path(tag).exists()

    def list_tags(self) -> list[str]:
        """[Golden] 列出所有可读快照标签（损坏文件不进入 tag 列表）。"""
        return [s["tag"] for s in self._list_snapshots() if "error" not in s]

    def list_summary(self) -> list[dict]:
        """[Golden] 列出所有快照摘要"""
        return self._list_snapshots()

    def show(self, tag: str) -> dict | None:
        """[Golden] 查看快照详情（不加载完整图）。

        损坏文件返回 `{tag, error}` 而不是裸 traceback；文件名是 tag 权威。
        """
        try:
            data = self.load(tag)
        except ValueError as e:
            return {"tag": tag, "file": str(self._snapshot_path(tag)),
                    "error": str(e), "node_count": 0, "edge_count": 0,
                    "module_graph_present": False}
        if data is None:
            return None

        mig = data.get("module_graph") or {}
        mig_instances = mig.get("instances") or {}
        info = {
            "tag": tag,
            "version": data.get("version", SNAPSHOT_VERSION),
            "created_at": data.get("created_at", ""),
            "git_commit": data.get("git_commit", ""),
            "files": data.get("files", []),
            "node_count": data.get("node_count", 0),
            "edge_count": data.get("edge_count", 0),
            "file_size_bytes": self._snapshot_path(tag).stat().st_size,
            "module_graph_present": bool(mig_instances),
            "module_graph_instances": len(mig_instances),
            "module_graph_ports": sum(len(i.get("ports") or {})
                                      for i in mig_instances.values()),
        }
        body_tag = data.get("tag")
        if body_tag is not None and body_tag != tag:
            info["tag_mismatch"] = str(body_tag)
        return info

    def compare(self, tag1: str, tag2: str) -> dict | None:
        """[Golden] 对比两个快照

        Args:
            tag1: 旧快照标签
            tag2: 新快照标签

        Returns:
            包含 diff 结果的字典，或 None（如果任一快照不存在）
        """
        data1 = self.load(tag1)
        data2 = self.load(tag2)

        if data1 is None or data2 is None:
            return None

        # 使用 SignalGraph 的序列化/反序列化
        from sv_query.trace.core.graph.models import SignalGraph

        G1 = SignalGraph.from_dict(data1)
        G2 = SignalGraph.from_dict(data2)

        # 使用 diff_with_health 进行完整对比
        from sv_query.trace.core.graph.diff import diff_with_health

        result = diff_with_health(G1, G2)

        # 序列化 GraphDiff 对象
        diff_result = result["graph_diff"]

        return {
            "tag1": tag1,
            "tag2": tag2,
            "stable_core": result["stable_core"],
            "health_score_old": result["health_score_old"],
            "health_score_new": result["health_score_new"],
            "health_delta": result["health_delta"],
            "coupling_warning": result["coupling_warning"],
            "added_nodes": diff_result.added_nodes,
            "removed_nodes": diff_result.removed_nodes,
            "added_edges": [list(e) for e in diff_result.added_edges],
            "removed_edges": [list(e) for e in diff_result.removed_edges],
            "identical": diff_result.identical,
        }
