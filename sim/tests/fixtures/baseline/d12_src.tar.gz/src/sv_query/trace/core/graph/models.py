# ==============================================================================
# graph_models.py - 信号关系图模型
# ==============================================================================

from dataclasses import asdict, dataclass, field
from dataclasses import fields as dc_fields
from datetime import UTC
from enum import Enum, auto
from typing import Any

import networkx as nx

# [Stage 1] TraceEdge.source_location 字段用 SourceLocation
# coverage_models 不反向依赖 graph.models, 无循环 import 风险
from ..coverage_models import SourceLocation


def _filter_json_safe(d: dict | None) -> dict:
    """[P158.9.2] 只保留 JSON 可序列化的 extra 值。

    extra 是自由形态 metadata, 不承诺全量持久化: 不可序列化的值
    (运行期对象/AST) 被显式丢弃而非报错 — 损失面在 snapshot surface
    矩阵中声明 (docs/dev/SNAPSHOT_SURFACE.md)。
    """
    import json as _json

    if not d:
        return {}
    out: dict = {}
    for k, v in d.items():
        try:
            _json.dumps(v)
        except (TypeError, ValueError):
            continue
        out[k] = v
    return out


# [Stage 1] TraceEdge.source_location 字段用 SourceLocation


@dataclass
class SignalSource:
    """[V6.5 2026-07-28] [V6.6 renamed from DriverSource] 结构化信号源

    driver 和 load 共享 — 表达驱动源或负载源的位精确信息:
    - 实际信号名 (如 a, b, data)
    - 位范围 (MSB/LSB 分别存储为 int, 而非 "[7:0]" 字符串)
    - 表达式上下文 (左/右操作数, 运算符类型)
    - 包装转换 (如 $signed, $unsigned)

    Example:
        assign y = $signed(a) >>> b[4:0];
        → SignalSource(
            signal="a",
            full_expression="$signed(a) >>> b[4:0]",
            op=">>>",
            operand_side="left",
            casts=["$signed"],
            is_decomposed=True,
        )
        → SignalSource(
            signal="b",
            bit_start=4, bit_end=0,
            full_expression="$signed(a) >>> b[4:0]",
            op=">>>",
            operand_side="right",
            is_decomposed=True,
        )
    """

    signal: str  # 实际信号名 (如 "a", "b", "data")
    bit_start: int | None = None  # MSB (高位)
    bit_end: int | None = None  # LSB (低位)
    full_expression: str = ""  # 完整表达式 (向后兼容/显示用)
    op: str = ""  # 二元运算符 (如 "+", "&", ">>>")
    operand_side: str = ""  # "left" / "right" / ""
    casts: list[str] = field(default_factory=list)  # 类型转换列表 (如 ["$signed"])
    is_decomposed: bool = False  # 是否分解后的片段 (非原始完整表达式)
    # [V6.9 datapath] 嵌套 OP 链 — 闭式表达式分解后的附加运算符列表
    # 例: (sum_ac + 128) >>> 8 → signal=sum_ac, op=">>>", inner_ops={"+128"}
    inner_ops: list[str] = field(default_factory=list)

    @property
    def bit_slice(self) -> str:
        """位选择字符串, e.g. "[7:0]", "[3]", """
        if self.bit_start is not None and self.bit_end is not None:
            if self.bit_start == self.bit_end:
                return f"[{self.bit_start}]"
            return f"[{self.bit_start}:{self.bit_end}]"
        return ""

    @property
    def display_str(self) -> str:
        """可读显示字符串: 包含 casts + signal + bit_slice 的紧凑形式"""
        parts = []
        name = self.signal
        bs = self.bit_slice
        if bs:
            name = f"{self.signal}{bs}"
        if self.casts:
            for c in self.casts:
                name = f"{c}({name})"
        parts.append(name)
        if self.op:
            side = f" ({self.operand_side})" if self.operand_side else ""
            parts.append(f"→ op: {self.op}{side}")
        if self.is_decomposed:
            parts.append("(decomposed)")
        return " ".join(parts)


class NodeKind(Enum):
    # ═══ 核心: 硬件信号 (≈80% 引用) ═══
    SIGNAL = auto()
    WIRE = auto()
    REG = auto()
    PORT_IN = auto()
    PORT_OUT = auto()
    PORT_INOUT = auto()
    CONST = auto()

    # ═══ 核心: 架构节点 ═══
    PARAM = auto()
    INSTANTIATED_MODULE = auto()  # 实例节点 (top.inst)
    GENERATE_BLOCK = auto()  # generate 块节点 (top.GEN)

    # ═══ 扩展: Class / Constraint 节点 (Phase1a) ═══
    CLASS = auto()  # class 定义节点 (packet)
    CLASS_INSTANCE = auto()  # class 实例 (top.p = new())
    CLASS_INSTANCE_PROPERTY = auto()  # class 实例成员 (top.p.addr)
    CLASS_PROPERTY = auto()  # class 成员变量 (packet.addr, rand 变量)
    CONSTRAINT_BLOCK = auto()  # constraint c { ... } 命名块
    CONSTRAINT_EXPR = auto()  # 单条表达式约束
    CONSTRAINT_IF = auto()  # if 分支
    CONSTRAINT_ELSE = auto()  # else 分支
    CONSTRAINT_IMPLIES = auto()  # implication 左部 (en -> ...)
    CONSTRAINT_UNIQUE = auto()  # unique { ... }
    CONSTRAINT_SOLVE = auto()  # solve A before B
    CONSTRAINT_FOREACH = auto()  # foreach 循环
    CONSTRAINT_RANGE = auto()  # inside {0,1,2} 的集合

    # ═══ 实验: 表达式级节点 ═══
    EXPRESSION = auto()  # 表达式节点 (a + b, a & b)
    FUNCTION_CALL = auto()  # 函数调用节点

    # ═══ [FIX 2026-08-21 Plan B] 条件分支节点 (三目 + case) ═══
    # 之前 ?: (sel) / case (sel) 是 ELK-only 合成节点, 内部 graph 没有,
    # 导致 lint 误报 orphan + trace 看不到条件分支.  现在作为真实节点 emit.
    OP_TERNARY = auto()  # 条件三目节点 (? : ), name='?: (sel)'
    OP_CASE = auto()     # case 块 ( case (sel) { ... } ), name='case (sel)'


class EdgeKind(Enum):
    # ═══ 核心: 硬件信号边 (≈90% 引用) ═══
    DRIVER = auto()  # 数据驱动 (q <= d)
    CLOCK = auto()  # 时钟触发 (clk -> q)
    RESET = auto()  # 异步复位 (rst_n -> q)
    CONNECTION = auto()  # 模块端口连接
    BIT_SELECT = auto()  # 位选择聚合

    # ═══ 扩展: Class / Constraint 边 (Phase1a) ═══
    CONSTRAINS = auto()  # CLASS_PROPERTY ← 约束管控
    HAS_CONDITION = auto()  # CONSTRAINT_IF → CLASS_PROPERTY (条件变量)
    HAS_CONSEQUENT = auto()  # CONSTRAINT_IF → CONSTRAINT_EXPR (if 结果)
    HAS_ALTERNATE = auto()  # CONSTRAINT_ELSE → CONSTRAINT_EXPR (else 结果)
    HAS_LHS = auto()  # CONSTRAINT_EXPR → operand (左操作数)
    HAS_RHS = auto()  # CONSTRAINT_EXPR → operand (右操作数)
    HAS_MEMBER = auto()  # CONSTRAINT_UNIQUE → CLASS_PROPERTY (集合成员)
    HAS_LOOP_VAR = auto()  # CONSTRAINT_FOREACH → CLASS_PROPERTY (循环变量)
    HAS_BEFORE = auto()  # CONSTRAINT_SOLVE → CLASS_PROPERTY (before)
    HAS_AFTER = auto()  # CONSTRAINT_SOLVE → CLASS_PROPERTY (after)
    CONTAINS_MEMBER = auto()  # CLASS → CLASS_PROPERTY (组合/成员变量)
    IS_INSTANCE_OF = auto()  # CLASS_PROPERTY → CLASS (成员变量的类型引用)
    SUPER_CALL = auto()  # CONSTRAINT_EXPR → 被调用的父类约束
    MEMBER_SELECT = auto()  # 实例成员访问: top.p.addr → top.p

    # ═══ [FIX 2026-08-21 Plan B] 条件分支边 (三目 + case) ═══
    # 供 trace 默认走 DRIVER + CONDITIONAL, coverage 统计条件分支.
    BRANCH_CONDITION = auto()  # cond_signal → OP_TERNARY (条件选选信号)
    BRANCH_TRUE = auto()       # true_expr → OP_TERNARY (true 分支输出)
    BRANCH_FALSE = auto()      # false_expr → OP_TERNARY (false 分支输出)
    BRANCH_RESULT = auto()     # OP_TERNARY → dst_signal (三目表达式结果)
    CASE_SELECT = auto()       # sel_signal → OP_CASE (case 选选信号)
    CASE_ITEM = auto()         # case_item_src → OP_CASE (case 各项驱动)
    CASE_RESULT = auto()       # OP_CASE → dst_signal (case 表达式结果)


# [铁律16] 注意:ENABLE/DATA 不作为独立边类型
# - ENABLE: 用 TraceEdge.condition 属性替代,语义更清晰
# - DATA: 与 DRIVER 重复,保留 DRIVER 即可


# SignalSource 的合法构造字段集合 (from_dict 反序列化时过滤未知键)
_SIGNAL_SOURCE_FIELDS = frozenset(f.name for f in dc_fields(SignalSource))


def _parse_node_kind(node_dict: dict) -> NodeKind:
    """[P183.1/D4] 严格解析 node.kind — 未知/缺失/非字符串显式失败。"""
    node_id = node_dict.get("id")
    if "kind" not in node_dict:
        raise ValueError(
            f"SignalGraph.from_dict: node {node_id!r} is missing 'kind'; "
            "refusing to assume SIGNAL"
        )
    kind_raw = node_dict["kind"]
    try:
        return NodeKind[kind_raw]
    except (KeyError, TypeError):
        raise ValueError(
            f"SignalGraph.from_dict: unknown NodeKind {kind_raw!r} for node "
            f"{node_id!r}; refusing to guess (snapshot may use a newer schema)"
        ) from None


def _parse_edge_kind(edge_dict: dict) -> EdgeKind:
    """[P183.1] 严格解析 edge.kind — 未知/缺失一律显式失败。

    禁止静默回退 DRIVER: 新 schema 或损坏快照里的控制边/结构边若被当成
    数据边, 会违反 SEMANTIC_CONTRACTS §2 (data = DRIVER + CONNECTION)。
    """
    src = edge_dict.get("src")
    dst = edge_dict.get("dst")
    if "kind" not in edge_dict:
        raise ValueError(
            f"SignalGraph.from_dict: edge {src!r} -> {dst!r} is missing 'kind'; "
            "refusing to assume DRIVER"
        )
    kind_raw = edge_dict["kind"]
    try:
        return EdgeKind[kind_raw]
    except (KeyError, TypeError):
        raise ValueError(
            f"SignalGraph.from_dict: unknown EdgeKind {kind_raw!r} for edge "
            f"{src!r} -> {dst!r}; refusing to guess (snapshot may use a newer schema)"
        ) from None


@dataclass
class TraceNode:
    id: str
    name: str
    module: str
    kind: NodeKind
    width: tuple[int, int]
    bit_range: str | None = None
    file: str = ""
    line: int = 0
    is_clock: bool = False
    is_reset: bool = False
    is_enable: bool = False
    is_port: bool = False
    parent: str | None = None  # 方案C: 父节点ID (位选择→完整信号)
    parent_bit_start: int | None = None  # 位选在父节点中的起始位
    parent_bit_end: int | None = None  # 位选在父节点中的结束位
    modport_dir: str | None = None  # P0-3: modport direction (input/output/inout)
    # [FIX 2026-07-05] ExpressionBuilder 需要存 metadata (expression/function_name/operands/signals)
    # 因为 TraceNode 不接受这些 kwargs. 用 dict[str, Any] 存任意 metadata, 向后兼容
    extra: dict[str, Any] = field(default_factory=dict)
    # [iter_297 / PLAN P9.1] 声明是否有符号 (None = 未知/未建模)
    # 影响加宽时的扩展方向：signed → 符号位扩展；False → 零扩展；None → 保守（不承诺）
    is_signed: bool | None = None


@dataclass
class TraceEdge:
    src: str
    dst: str
    kind: EdgeKind
    assign_type: str = ""
    condition: str = ""
    effective_condition: str = ""  # 判断清除后的条件（只保留直接相关的条件）
    condition_ast: Any | None = None  # [V6.9] 条件表达式 AST 节点 (供 semantic_adapter 解析)
    clock_domain: str = ""
    modport_dir: str | None = None  # P0-3: modport direction (input/output/inout)
    confidence: str = "high"
    expression: str = ""  # 驱动表达式 (如 "sreg_d", "a + b")
    bit_slice: str = ""  # 位选择 (如 "[8:1]")
    # [Stage 1] 源码位置 (条件表达式位置, 后续 stage 扩展为 assignment + enclosing scope)
    source_location: SourceLocation | None = None  # noqa: F821 -- forward ref
    # [FIX 2026-07-05] function_return: True 表示这是函数调用返回值 (result <- func)
    function_return: bool = False
    is_function_call: bool = False
    # [V6.5 2026-07-28] [V6.6 renamed from driver_source] 结构化信号源
    # driver 和 load 共享 — 当 source 非 None 时, expression/bit_slice 应保持同步
    source: SignalSource | None = None
    # [V7.0 2026-08-03] 嵌套条件累积链 (外层→内层, AND 语义)
    # 例: ["sel_d == 2'd0", "sel_e == 2'd0"]
    # 互斥关系由渲染器自动推导: 按 (dst, chain[:-1]) 分组, >=2 条边 → mux/case
    condition_chain: list[str] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class DriverInfo:
    """驱动信息 - 包含驱动节点及其驱动条件

    [方案C] 从 TraceNode 分离出来,因为 condition 是边的属性而非节点属性
    [V6.6] source 字段替代 expression/bit_slice，使其变为 derived property
    [Plan F2.4.1 2026-08-13] expression_tree 字段 — 从 SignalGraph._expr_trees[signal_id]
    注入结构化 driver 表达式 AST (由 driver_extractor 构建)。跟 string-based
    `expression` 字段并存: string 给向后兼容/显示用, tree 给静态分析/checker 用.
    """

    node: TraceNode  # 驱动节点
    source: SignalSource | None = None  # [V6.6] 位精确信号源 (驱动源或负载源)
    condition: str = ""  # 驱动条件 (来自 if 语句)
    expression_tree: dict | None = None  # [Plan F2.4.1] 结构化 driver 表达式 AST (None = 未注入/无)
    reset_condition: str = ""  # 复位条件 (来自 if (!rst_ni))
    clock_domain: str = ""  # 时钟域
    assign_type: str = ""  # always_ff / always_comb / continuous / blocking / nonblocking
    distance: int = 1  # 驱动距离 (层级深度)
    # [V6.6] expression/bit_slice 改为 @property，从 source 派生
    _expression_override: str = ""  # 覆盖 source.full_expression（特殊场景下使用）
    target_signal: str = ""  # 目标信号 (被驱动的信号)

    @property
    def id(self) -> str:
        return self.node.id

    @property
    def expression(self) -> str:
        """驱动表达式 — 从 source 派生，或使用 _expression_override"""
        if self._expression_override:
            return self._expression_override
        if self.source:
            return self.source.full_expression
        return ""

    @property
    def bit_slice(self) -> str:
        """位选择 — 从 source 派生"""
        if self.source:
            return self.source.bit_slice
        return ""

    @property
    def full_statement(self) -> str:
        """组装完整的驱动语句 (debug 用)

        例如: if (cond) sreg_d <= {rx, sreg_q[10:1]};
        """
        # 获取 LHS (目标信号)
        lhs = self.target_signal if self.target_signal else (self.node.id if hasattr(self, "node") else "?")

        # 组装条件
        cond = self.condition if self.condition else self.reset_condition
        if cond:
            stmt = f"if ({cond}) {lhs} "
        else:
            stmt = f"{lhs} "

        # 添加 assign_type
        assign_map = {
            "nonblocking": "<=",
            "blocking": "=",
            "continuous": "=",
        }
        assign_op = assign_map.get(self.assign_type, self.assign_type or "=")
        stmt += f"{assign_op} "

        # 添加表达式
        expr = self.expression if self.expression else "?"
        stmt += f"{expr};"

        # 添加时钟域注释
        if self.clock_domain:
            stmt += f" // @{self.clock_domain}"

        return stmt


class SignalGraph(nx.DiGraph):
    def __init__(self):
        super().__init__()
        self._node_data: dict[str, TraceNode] = {}
        # [FIX] 支持同一 (src, dst) 的多条边 (不同 condition)
        self._edge_data: dict[tuple[str, str], list[TraceEdge]] = {}
        # [REFACTOR 2026-08-07 A计划] 表达式树/常量/函数信息 — 从 semantic AST 构建，消灭 viz 层源码重读
        self._expr_trees: dict[str, dict] = {}      # {dst_key → tree_dict}
        self._const_map: dict[str, list] = {}       # {dst_short → [const_str,...]}
        self._func_info: dict[str, tuple | None] = {}  # {func_name → (msb,lsb)|None}
        # [V16.11 2026-08-18] generate block real-label map (pyslang native API)
        # {dst_signal_short_name → GenerateBlockArray.name (e.g. 'buf1' → 'gen_stage1', 'acc' → 'gen_accum')}
        # 替代 V16.10.3 的启发式 (_parse_gen_block): 直接从源码读取真实 label, 适用于任意命名
        self._gen_block_map: dict[str, str] = {}
        # [V16.14 2026-08-19 F-N3 redesign] 配套 iter map: 区分 per-LHS-element vs base name.
        # case27 顶层: 'acc[1]','acc[2]','acc[3]','acc[4]' → entry_idx (0,1,2,3) — per-element 拆分
        # case29 顶层: 'chain_out' (只一个 dst short) → entry_idx (0) — 全局 setdefault
        # elk_bridge 顶层 lookup 会按 _dst_short (tree key 短名) 查, 拿 per-element key.
        self._gen_iter_map: dict[str, int] = {}
        # [iter_310 / PLAN P16] 动态索引传播标记（运行期决定 → unknown）
        self._dynamic_nodes: set[str] = set()
        # [iter_313 / PLAN P18.2] 函数调用结果节点（诚实标记，不 inline）
        self._function_nodes: set[str] = set()
        # [iter_322 / PLAN P26.2] 运行期系统调用结果节点（$random 等）
        self._runtime_system_nodes: set[str] = set()

    def add_trace_node(self, node: TraceNode) -> None:
        self._node_data[node.id] = node
        super().add_node(node.id)

    def add_trace_edge(self, edge: TraceEdge) -> None:
        # [铁律4] 不允许创建孤儿节点:如果目标节点不存在则创建 placeholder
        # [FIX] 字面量节点(如 4'b1011, 8'h42)创建为 CONST 类型节点
        def _is_literal(node_id: str) -> bool:
            """检查是否为字面量常量

            [Phase 8 / Fix F 2026-7-14] Detect plain integer literals too:
            '0', '1', '2', etc. (single digit integers without '.')
            These are RHS values from `q <= 0` style assignments.
            """
            if not node_id:
                return False
            # 匹配 4'b0, 1'b1, 4'b1011, 8'hFF, 11'd0, -4'sd1 (signed 规范化) 等
            if (len(node_id) >= 3 and "'" in node_id
                    and (node_id[0].isdigit()
                         or (node_id[0] == "-" and node_id[1:2].isdigit()))):
                return True
            # [Phase 8 / Fix F] Plain integer literals: '0', '1', ..., '42'
            # No '.' means not a scoped signal name
            if "." not in node_id and node_id.lstrip("0123456789") == "":
                return True
            return False

        for node_id in [edge.src, edge.dst]:
            if node_id not in self._node_data:
                if _is_literal(node_id):
                    # 字面量创建为 CONST 类型节点
                    parts = node_id.split(".", 1)
                    module = parts[0] if len(parts) > 1 else ""
                    name = parts[1] if len(parts) > 1 else node_id
                    literal_node = TraceNode(id=node_id, name=name, module=module, kind=NodeKind.CONST, width=(0, 0))
                    self._node_data[node_id] = literal_node
                    super().add_node(node_id)
                else:
                    parts = node_id.split(".", 1)
                    module = parts[0] if len(parts) > 0 else ""
                    name = parts[1] if len(parts) > 1 else node_id

                    placeholder = TraceNode(
                        id=node_id,
                        name=name,
                        module=module,
                        kind=NodeKind.SIGNAL,
                        width=(0, 0),
                        extra={
                            "placeholder": True,
                            "placeholder_reason": "edge endpoint not declared",
                            "kind_origin": "edge_placeholder",
                        },
                    )
                    self._node_data[node_id] = placeholder
                    super().add_node(node_id)

        # [FIX] 支持同一 (src, dst) 多条边：append 到列表，不去重
        # 只要 (src, dst, kind, condition) 完全相同才去重
        key = (edge.src, edge.dst)

        if key not in self._edge_data:
            self._edge_data[key] = []

        # 检查是否完全重复（所有属性都相同）
        for existing_edge in self._edge_data[key]:
            if (
                existing_edge.kind == edge.kind
                and existing_edge.condition == edge.condition
                and existing_edge.assign_type == edge.assign_type
                and existing_edge.expression == edge.expression
            ):
                return  # 完全重复，跳过

        # 添加新边到列表
        self._edge_data[key].append(edge)
        # [V8.1 fix] 同步 TraceEdge 属性到 networkx 边, 供 viz_data_builder 使用
        # 注意: expression 可能包含大段源码 (三目等场景), 不传以避免膨胀
        super().add_edge(edge.src, edge.dst,
            source_op=edge.source.op if edge.source else '',
            condition=edge.condition,
            condition_chain=edge.condition_chain,
            assign_type=edge.assign_type,
        )

        # 自动计算 effective_condition
        if edge.condition and not edge.effective_condition:
            edge.effective_condition = SignalGraph.compute_effective_condition(edge.condition)

    def set_node_modport_dir(self, node_id: str, modport_dir: str) -> None:
        """[P0-3] 设置已有节点的 modport_dir 属性"""
        if node_id in self._node_data:
            self._node_data[node_id].modport_dir = modport_dir

    def get_node(self, node_id: str) -> TraceNode | None:
        return self._node_data.get(node_id)

    def get_edge(self, src: str, dst: str) -> TraceEdge | None:
        """获取 (src, dst) 的第一条边（向后兼容，按优先级排序）"""
        edges = self._edge_data.get((src, dst), [])
        if not edges:
            return None
        # 返回排序后的第一条（优先级最高）
        return self._sort_edges(edges)[0]

    def get_edges(self, src: str, dst: str) -> list[TraceEdge]:
        """获取 (src, dst) 的所有边（按优先级排序）"""
        edges = self._edge_data.get((src, dst), [])
        return self._sort_edges(edges)

    @staticmethod
    def compute_effective_condition(condition: str) -> str:
        """计算判断清除后的条件

        从嵌套条件中提取直接相关的条件。
        例如:
            - '!!rst_n && state == DONE' -> 'state == DONE'
            - 'en && a' -> 'a'
            - 'state == IDLE' -> 'state == IDLE'

        规则:
            1. 如果 condition 中包含 '&&' 或 '||'
            2. 提取最后一个逻辑单元（通常是状态判断或信号本身）
            3. 忽略简单的 reset 条件（如 '!rst_n'）
        """
        if not condition or "&&" not in condition:
            return condition

        import re

        # 移除空格
        stripped = condition.replace(" ", "")

        # 分割 && 部分
        parts = stripped.split("&&")

        # 找最后一个包含 == 或 =~ 或信号引用的部分
        for part in reversed(parts):
            part = part.strip()
            # 跳过 reset 条件
            if re.match(r"^(!|~~|~)rst", part, re.IGNORECASE):
                continue
            if re.match(r"^(!|~~|~)reset", part, re.IGNORECASE):
                continue
            # 保留其他部分
            return part

        return condition

    def set_lifo_order(self, state_values: list[str]) -> None:
        """设置 LIFO 顺序的状态值列表，用于边排序

        Args:
            state_values: 状态值列表，按语义优先级升序排列
                         后面的状态优先级更高 (LIFO)
                         例如: ['REQ', 'DONE', 'IDLE'] 表示 IDLE 优先级最高
        """
        self._lifo_priority = {sv: i for i, sv in enumerate(state_values)}

    def _sort_edges(self, edges: list[TraceEdge]) -> list[TraceEdge]:
        """边排序：reset 条件优先，然后按 LIFO 顺序（from_state 优先级）"""
        lifo_priority = getattr(self, "_lifo_priority", {})

        def edge_priority(e: TraceEdge) -> tuple:
            # reset 条件 = 不包含 && 或 || 且包含 rst/reset
            is_reset = False
            if e.condition:
                stripped = e.condition.replace(" ", "")
                has_logical = "&&" in stripped or "||" in stripped
                has_reset = "rst" in stripped.lower() or "reset" in stripped.lower()
                is_reset = has_reset and not has_logical

            # 提取 from_state (从 condition 中找 state == X)
            from_state = None
            if e.condition and not is_reset:
                import re

                m = re.search(r"state\s*(?:==|===)\s*(\w+)", e.condition)
                if m:
                    from_state = m.group(1)

            # LIFO 优先级：from_state 在预定义列表中的位置
            # 列表后面的状态优先级更高 (LIFO)
            state_priority = len(lifo_priority)  # 默认最低（不在列表中）
            if from_state in lifo_priority:
                pos = lifo_priority[from_state]
                state_priority = len(lifo_priority) - pos  # 逆序：后面的优先级高

            # (是否是 reset, LIFO 优先级, condition 长度, condition 字符串)
            return (not is_reset, state_priority, len(e.condition or ""), e.condition or "")

        return sorted(edges, key=edge_priority)

    def find_drivers(self, signal_id: str) -> list[TraceNode]:
        return [self.get_node(n) for n in self.predecessors(signal_id)]

    def find_loads(self, signal_id: str) -> list[TraceNode]:
        return [self.get_node(n) for n in self.successors(signal_id)]

    def find_path(self, src_id: str, dst_id: str) -> list[str]:
        try:
            return nx.shortest_path(self, src_id, dst_id)
        except nx.NetworkXNoPath:
            return []

    def find_all_paths(self, src_id: str, dst_id: str, max_depth: int = 10) -> list[list[str]]:
        try:
            return list(nx.all_simple_paths(self, src_id, dst_id, cutoff=max_depth))
        except Exception:
            return []

    def detect_cycles(self) -> list[list[str]]:
        try:
            return list(nx.simple_cycles(self))
        except Exception:
            return []

    def stats(self) -> dict:
        return {
            "nodes": self.number_of_nodes(),
            "edges": self.number_of_edges(),
        }

    # ==============================================================================
    # Snapshot 序列化 - 支持完整 SignalGraph 持久化
    # [铁律13] 金标准测试优先
    # ==============================================================================

    def to_dict(self) -> dict:
        """[Golden] 完整序列化 SignalGraph 为可 JSON 化的字典

        金标准输出格式:
        {
            "version": "1.0",
            "created_at": "ISO timestamp",
            "node_count": int,
            "edge_count": int,
            "nodes": [
                {"id": str, "name": str, "module": str, "kind": str, ...},
                ...
            ],
            "edges": [
                {"src": str, "dst": str, "kind": str, ...},
                ...
            ]
        }
        """
        nodes_data = []
        for node_id in self.nodes():
            node = self._node_data.get(node_id)
            if node:
                # [iter_087] width 可为 None (宽度提取失败的合法 sentinel, graph_builder
                # 显式传 width=None 的内存位选等节点) — list(None) 会 TypeError,
                # 序列化必须显式保留 None, 不得伪造 (0,0).
                nodes_data.append(
                    {
                        "id": node.id,
                        "name": node.name,
                        "module": node.module,
                        "kind": node.kind.name if isinstance(node.kind, NodeKind) else str(node.kind),
                        "width": list(node.width) if node.width is not None else None,
                        "bit_range": node.bit_range,
                        "file": node.file,
                        "line": node.line,
                        "is_clock": node.is_clock,
                        "is_reset": node.is_reset,
                        "is_enable": node.is_enable,
                        "is_port": node.is_port,
                        "is_signed": node.is_signed,
                        "parent": node.parent,
                        "parent_bit_start": node.parent_bit_start,
                        "parent_bit_end": node.parent_bit_end,
                        "modport_dir": node.modport_dir,
                        # [P158.9.2] extra: 仅 JSON-safe 值 (direction/width 等),
                        # 不可序列化值显式丢弃 — 见 _filter_json_safe 声明
                        "extra": _filter_json_safe(node.extra),
                    }
                )

        edges_data = []
        for src, dst in self.edges():
            edges = self._edge_data.get((src, dst), [])
            for edge in edges:
                edges_data.append(
                    {
                        "src": edge.src,
                        "dst": edge.dst,
                        "kind": edge.kind.name if isinstance(edge.kind, EdgeKind) else str(edge.kind),
                        "assign_type": edge.assign_type,
                        "condition": edge.condition,
                        "clock_domain": edge.clock_domain,
                        "modport_dir": edge.modport_dir,
                        "confidence": edge.confidence,
                        "expression": edge.expression,
                        "bit_slice": edge.bit_slice,
                        "source_location": (
                            edge.source_location.to_dict()
                            if edge.source_location is not None else None
                        ),
                        # [P158.9.2] 补齐缺失字段 (arch_eval P0.2: 不许中间态):
                        # condition_chain 被 dataflow 条件提取回退消费, 丢失即
                        # snapshot 与 live 查询分叉; source 喂 DriverInfo 派生
                        # property; function 标记喂函数调用语义。
                        # effective_condition 由 add_trace_edge 重算恢复 (实测 72/72),
                        # 无需序列化; condition_ast 是运行期 AST, 显式不保证。
                        "condition_chain": list(edge.condition_chain),
                        "function_return": edge.function_return,
                        "is_function_call": edge.is_function_call,
                        "source": asdict(edge.source) if edge.source is not None else None,
                        "extra": _filter_json_safe(edge.extra),
                    }
                )

        return {
            "version": "1.0",
            "created_at": "",  # 由调用方填充
            "node_count": len(nodes_data),
            "edge_count": len(edges_data),
            "nodes": nodes_data,
            "edges": edges_data,
            # [REFACTOR 2026-08-07 A计划] 持久化表达式树/常量/函数信息
            "dynamic_nodes": sorted(self._dynamic_nodes),
            "function_nodes": sorted(self._function_nodes),
            "runtime_system_nodes": sorted(self._runtime_system_nodes),
            "expr_trees": dict(self._expr_trees),
            "const_map": dict(self._const_map),
            "func_info": dict(self._func_info),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SignalGraph":
        """[Golden] 从字典反序列化重建 SignalGraph

        金标准:
        - 遍历 nodes 重建 TraceNode
        - 遍历 edges 重建 TraceEdge
        """
        graph = cls()

        # 恢复节点
        for node_dict in data.get("nodes", []):
            kind = _parse_node_kind(node_dict)

            # [iter_087] width 显式 null → 恢复 None (to_dict 现在会写 null);
            # 旧格式缺 width 键 → 保持原 (0,0) 回退, 不改变历史行为.
            if "width" in node_dict and node_dict["width"] is None:
                _width: tuple[int, int] | None = None
            else:
                _width = tuple(node_dict.get("width", [0, 0]))

            node = TraceNode(
                id=node_dict["id"],
                name=node_dict.get("name", ""),
                module=node_dict.get("module", ""),
                kind=kind,
                width=_width,
                bit_range=node_dict.get("bit_range"),
                file=node_dict.get("file", ""),
                line=node_dict.get("line", 0),
                is_clock=node_dict.get("is_clock", False),
                is_reset=node_dict.get("is_reset", False),
                is_enable=node_dict.get("is_enable", False),
                is_port=node_dict.get("is_port", False),
                is_signed=node_dict.get("is_signed"),
                parent=node_dict.get("parent"),
                parent_bit_start=node_dict.get("parent_bit_start"),
                parent_bit_end=node_dict.get("parent_bit_end"),
                modport_dir=node_dict.get("modport_dir"),
                # [P158.9.2] 恢复 extra (仅含 to_dict 序列化时保留下来的 JSON-safe 值)
                extra=dict(node_dict.get("extra") or {}),
            )
            graph.add_trace_node(node)

        # [iter_310 / PLAN P16] 恢复动态索引传播标记
        for nid in data.get("dynamic_nodes", []) or []:
            node = graph.get_node(nid)
            if node is not None:
                node.extra["dynamic"] = True
                graph._dynamic_nodes.add(nid)

        # [iter_313 / PLAN P18.2] 恢复函数调用标记
        for nid in data.get("function_nodes", []) or []:
            node = graph.get_node(nid)
            if node is not None:
                node.extra["function_call"] = True
                graph._function_nodes.add(nid)

        # [iter_322 / PLAN P26.2] 恢复运行期系统调用标记
        for nid in data.get("runtime_system_nodes", []) or []:
            node = graph.get_node(nid)
            if node is not None:
                node.extra["runtime_system_call"] = True
                graph._runtime_system_nodes.add(nid)

        # 恢复边
        for edge_dict in data.get("edges", []):
            kind = _parse_edge_kind(edge_dict)

            loc_data = edge_dict.get("source_location")
            source_location = None
            if isinstance(loc_data, dict):
                source_location = SourceLocation(
                    file=loc_data.get("file", ""),
                    line_start=loc_data.get("line_start", 0),
                    line_end=loc_data.get("line_end", 0),
                    column=loc_data.get("column", 0),
                )
            src_data = edge_dict.get("source")
            source = None
            if isinstance(src_data, dict):
                # 过滤未知键, 前向兼容 (新格式多出的键不至于炸旧 reader 的构造)
                known = {k: v for k, v in src_data.items() if k in _SIGNAL_SOURCE_FIELDS}
                source = SignalSource(**known) if known else None
            edge = TraceEdge(
                src=edge_dict["src"],
                dst=edge_dict["dst"],
                kind=kind,
                assign_type=edge_dict.get("assign_type", ""),
                condition=edge_dict.get("condition", ""),
                clock_domain=edge_dict.get("clock_domain", ""),
                modport_dir=edge_dict.get("modport_dir"),
                confidence=edge_dict.get("confidence", "high"),
                expression=edge_dict.get("expression", ""),
                bit_slice=edge_dict.get("bit_slice", ""),
                source_location=source_location,
                # [P158.9.2] 补齐字段恢复 (与 to_dict 对称; 旧快照缺键 → 默认值)
                condition_chain=list(edge_dict.get("condition_chain") or []),
                function_return=bool(edge_dict.get("function_return", False)),
                is_function_call=bool(edge_dict.get("is_function_call", False)),
                source=source,
                extra=dict(edge_dict.get("extra") or {}),
            )
            graph.add_trace_edge(edge)

        # [REFACTOR 2026-08-07 A计划] 恢复表达式树/常量/函数信息
        # 旧 snapshot 可能没有这些字段，get 默认空保持兼容
        graph._expr_trees = dict(data.get("expr_trees", {}) or {})
        graph._const_map = dict(data.get("const_map", {}) or {})
        graph._func_info = dict(data.get("func_info", {}) or {})

        return graph

    def to_json(self, indent: int = 2) -> str:
        """[Golden] 序列化为 JSON 字符串"""
        import json

        data = self.to_dict()
        return json.dumps(data, indent=indent, ensure_ascii=False)

    @classmethod
    def from_json(cls, json_str: str) -> "SignalGraph":
        """[Golden] 从 JSON 字符串反序列化"""
        import json

        data = json.loads(json_str)
        return cls.from_dict(data)

    def save_snapshot(self, path: str, tag: str = "", git_commit: str = "", files: list | None = None) -> None:
        """[Golden] 保存快照到文件

        Args:
            path: 快照文件路径
            tag: 快照标签(如 "v1.2.3" 或 "feature-x")
            git_commit: Git commit hash
            files: 相关的源文件列表
        """
        import json
        from datetime import datetime

        data = self.to_dict()
        data["tag"] = tag
        data["git_commit"] = git_commit
        data["files"] = files or []
        data["created_at"] = datetime.now(UTC).isoformat()

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    @classmethod
    def load_snapshot(cls, path: str) -> "SignalGraph":
        """[Golden] 从文件加载快照"""
        import json

        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)
