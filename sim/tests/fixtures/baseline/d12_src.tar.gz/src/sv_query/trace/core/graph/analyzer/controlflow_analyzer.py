# ControlFlow Analyzer - 控制流分析器
# 基于 SignalGraph 的边 condition 信息进行控制流分析

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from ...graph_builder import GraphBuilder
from ..dataflow import DataFlowResult
from ..models import TraceEdge


@dataclass
class ConditionInfo:
    """条件信息"""

    expr: str  # 条件表达式 "rst_n && en"
    edge: TraceEdge  # 对应的边

    @property
    def signals(self) -> list[str]:
        """提取条件中的信号"""
        # 简化: 用字符串提取变量名
        # 后续可以用 SignalExpressionVisitor
        signals = []
        current = ""
        for c in self.expr:
            if c.isalnum() or c == "_":
                current += c
            else:
                if current and current not in ("0", "1"):
                    signals.append(current)
                current = ""
        if current and current not in ("0", "1"):
            signals.append(current)
        return signals


@dataclass
class ConditionedDriver:
    """同一目标的多个条件驱动边"""

    to_node: str  # 目标节点 "top.q"
    edges: list[TraceEdge]  # 所有到达该节点的边

    @property
    def conditions(self) -> list[ConditionInfo]:
        """获取所有条件"""
        return [ConditionInfo(expr=e.condition, edge=e) for e in self.edges if e.condition]

    @property
    def has_branches(self) -> bool:
        """是否有多个分支"""
        return len([e for e in self.edges if e.condition]) > 1

    def get_coverage_info(self) -> dict[str, Any]:
        """获取覆盖信息"""
        conds = self.conditions
        return {
            "total_branches": len(conds),
            "conditions": [c.expr for c in conds],
        }


@dataclass
class ControlFlowAnalysis:
    """控制流分析结果"""

    signal: str

    # 条件驱动信息
    conditioned_drivers: list[ConditionedDriver] = field(default_factory=list)

    # 分析警告
    warnings: list[str] = field(default_factory=list)
    # [P77] complete = 有数据边且 control 已知；unknown = 无边/未建模
    condition_status: str = "unknown"


class ControlFlowAnalyzer:
    """控制流分析器 - 直接从 SignalGraph 读取"""

    def __init__(self, graph_builder: GraphBuilder | None = None):
        self.graph_builder = graph_builder

    def analyze(self, signal: str) -> ControlFlowAnalysis:
        """
        分析信号的控制流

        Args:
            signal: 信号名，如 "top.q"

        Returns:
            ControlFlowAnalysis: 控制流分析结果
        """
        result = ControlFlowAnalysis(signal=signal)

        if self.graph_builder is None or self.graph_builder.graph is None:
            return result

        graph = self.graph_builder.graph

        # 1. 找到所有指向该信号的边
        incoming_edges = self._get_incoming_edges(graph, signal)

        if not incoming_edges:
            return result
        result.condition_status = "complete"

        # 2. 按源节点分组，找条件驱动
        by_source: dict[str, list[TraceEdge]] = defaultdict(list)
        for edge in incoming_edges:
            by_source[edge.src].append(edge)

        # 3. 构建 ConditionedDriver
        for _to_node, edges in by_source.items():
            # 检查是否有条件
            conditional_edges = [e for e in edges if e.condition]
            if conditional_edges:
                result.conditioned_drivers.append(ConditionedDriver(to_node=signal, edges=conditional_edges))

        # [P76] 端口连接里的 ternary 可能被折叠成无 condition 的 wrapper edge。
        self._mark_unmodeled_control(incoming_edges, result)

        # 4. 检查警告
        self._check_warnings(result)

        return result

    def analyze_dataflow_conditions(self, df_result: DataFlowResult) -> ControlFlowAnalysis:
        """
        从 DataFlow 结果中提取控制流信息

        Args:
            df_result: DataFlow 分析结果

        Returns:
            ControlFlowAnalysis: 控制流分析结果
        """
        result = ControlFlowAnalysis(signal=df_result.from_signal)

        # 从 DataFlowResult 中提取条件
        # df_result.all_conditions 是 List[str]
        if hasattr(df_result, "all_conditions"):
            for cond in df_result.all_conditions:
                if cond:
                    result.warnings.append(f"路径条件: {cond}")

        # 从 segments 中提取条件
        if hasattr(df_result, "segments"):
            for seg in df_result.segments:
                if hasattr(seg, "condition") and seg.condition:
                    result.warnings.append(f"段条件: {seg.condition}")

        return result

    def find_conditioned_signals(self, module: str | None = None) -> list[str]:
        """
        找出模块中所有有条件驱动的信号

        Args:
            module: 模块名

        Returns:
            List[str]: 有条件驱动的信号列表
        """
        if self.graph_builder is None or self.graph_builder.graph is None:
            return []

        graph = self.graph_builder.graph
        conditioned_signals = set()

        # 遍历所有边，找有 condition 的边
        # [FIX] 使用 get_edges 获取所有边（可能有多个不同 condition）
        for u, v in graph.edges():
            edges = graph.get_edges(u, v)
            for edge in edges:
                if edge and hasattr(edge, "condition") and edge.condition:
                    conditioned_signals.add(v)

        return sorted(conditioned_signals)

    def get_conditions_for_signal(self, signal: str) -> list[str]:
        """
        获取信号的所有条件

        Args:
            signal: 信号名

        Returns:
            List[str]: 条件列表
        """
        if self.graph_builder is None or self.graph_builder.graph is None:
            return []

        graph = self.graph_builder.graph
        conditions = []

        # 找所有指向该信号的边
        # [FIX] 使用 get_edges 获取所有边
        for u, v in graph.edges():
            if v == signal:
                edges = graph.get_edges(u, v)
                for edge in edges:
                    if edge and hasattr(edge, "condition") and edge.condition:
                        conditions.append(edge.condition)

        return conditions

    @staticmethod
    def _mark_unmodeled_control(incoming_edges, result) -> None:
        """[P76] 无 condition 的 wrapper edge 不能当成“无条件”。"""
        for edge in incoming_edges:
            if (getattr(edge, "assign_type", "") == "wrapper_passthrough"
                    and not getattr(edge, "condition", "")):
                result.condition_status = "unknown"
                result.warnings.append(
                    "unmodeled_control: wrapper_passthrough edge has no condition; "
                    "port-expression ternary/CONTROL may be flattened (source check required)"
                )
                return

    def _get_incoming_edges(self, graph, signal: str) -> list[TraceEdge]:
        """获取所有指向信号的边"""
        edges = []
        for u, v in graph.edges():
            if v == signal:
                # [FIX] 使用 get_edges 获取所有边
                edge_list = graph.get_edges(u, v)
                if edge_list:
                    edges.extend(edge_list)
        return edges

    def _check_warnings(self, result: ControlFlowAnalysis):
        """检查警告

        [ADD 2026-06-11 Req-13 Issue 21] if/else 互斥分支是合法设计, 不能报"矛盾".
        区分两种情况:
        1. if/else mutex: 两个 negation 且都是简单标识符 (a vs !a) → 标记 [Mutex] 不报警
        2. 真正矛盾: 多个同向条件互斥 (a vs !a 但还有 b vs !b) → 报警

        启发式: 如果该 signal 只有 2 个条件且互为 negation, 当作 mutex
                否则当作真矛盾报灖
        """
        for cd in result.conditioned_drivers:
            conds = cd.conditions
            if len(conds) != 2:
                # 不止 2 个条件, 全部都检查 negation
                for i, c1 in enumerate(conds):
                    for c2 in conds[i + 1 :]:
                        if self._is_negation(c1.expr, c2.expr):
                            result.warnings.append(f"矛盾条件检测: {c1.expr} vs {c2.expr}")
            else:
                # 正好 2 个条件且互为 negation → if/else mutex, 不是矛盾
                c1, c2 = conds
                if self._is_negation(c1.expr, c2.expr) and self._is_simple_identifier_pair(c1.expr, c2.expr):
                    result.warnings.append(
                        f"[Mutex] if/else 互斥分支: {c1.expr} vs {c2.expr} (合法设计, 非矛盾)"
                    )
                else:
                    # 2 个条件但不互为 negation, 或不是简单标识符对
                    # 走原始检查
                    if self._is_negation(c1.expr, c2.expr):
                        result.warnings.append(f"矛盾条件检测: {c1.expr} vs {c2.expr}")

    def _is_simple_identifier_pair(self, expr1: str, expr2: str) -> bool:
        """检查两个表达式是否都是简单标识符 (a vs !a 形式)

        过滤 'a && b' vs '!a' 这种不是 if/else mutex 的情况.
        """
        def extract_identifier(expr: str) -> str | None:
            expr = expr.strip()
            # !a → a
            if expr.startswith("!"):
                expr = expr[1:]
            # 必须是单个标识符 (字母数字下划线, 不含 &&, ||, ==, != 等)
            if "&&" in expr or "||" in expr or "==" in expr or "!=" in expr or "+" in expr or "-" in expr:
                return None
            if expr.isidentifier() or (expr.replace("_", "").replace("0", "").replace("1", "").replace("2", "").replace("3", "").replace("4", "").replace("5", "").replace("6", "").replace("7", "").replace("8", "").replace("9", "").isalnum()):
                return expr
            return None

        id1 = extract_identifier(expr1)
        id2 = extract_identifier(expr2)
        return id1 is not None and id2 is not None and id1 == id2

    def _is_negation(self, expr1: str, expr2: str) -> bool:
        """检查两个表达式是否互为否定"""

        # 简化检测: a vs !a
        def normalize(expr: str) -> str:
            return expr.replace("!", "").replace(" ", "")

        n1 = normalize(expr1)
        n2 = normalize(expr2)

        # 检查 !a vs a 或 a vs !a
        if expr1.startswith("!") and n1 == n2:
            return True
        if expr2.startswith("!") and n2 == n1:
            return True

        return False
